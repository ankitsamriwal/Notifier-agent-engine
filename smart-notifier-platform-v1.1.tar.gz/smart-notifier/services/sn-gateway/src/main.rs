//! Smart Notifier API Gateway
//! Responsibilities:
//!   - JWT verification (Ed25519, via Vault transit or local key)
//!   - Rate limiting (Redis sliding window)
//!   - Request routing to downstream services
//!   - Correlation ID injection
//!   - OpenTelemetry traces

use axum::{
    Router,
    middleware as axum_middleware,
    response::IntoResponse,
    http::StatusCode,
};
use std::{net::SocketAddr, sync::Arc};
use tokio::net::TcpListener;
use tower_http::{
    cors::{CorsLayer, Any},
    trace::TraceLayer,
    request_id::{MakeRequestUuid, SetRequestIdLayer, PropagateRequestIdLayer},
};
use tracing::info;

mod config;
mod error;
mod middleware;
mod proxy;
mod routes;
mod telemetry;

use config::GatewayConfig;

#[derive(Clone)]
pub struct AppState {
    pub config: Arc<GatewayConfig>,
    pub redis: redis::aio::ConnectionManager,
    pub http_client: reqwest::Client,
}

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    // Load config
    let cfg = GatewayConfig::from_env()?;
    telemetry::init(&cfg.otel_endpoint, "sn-gateway")?;

    info!(version = env!("CARGO_PKG_VERSION"), "Smart Notifier Gateway starting");

    // Redis connection manager (auto-reconnect)
    let redis_client = redis::Client::open(cfg.redis_url.clone())?;
    let redis_mgr = redis::aio::ConnectionManager::new(redis_client).await?;

    // HTTP client for proxying (connection pool)
    let http_client = reqwest::Client::builder()
        .timeout(std::time::Duration::from_secs(30))
        .pool_max_idle_per_host(20)
        .build()?;

    let state = AppState {
        config: Arc::new(cfg.clone()),
        redis: redis_mgr,
        http_client,
    };

    // Build router
    let app = build_router(state);

    let addr: SocketAddr = format!("0.0.0.0:{}", cfg.port).parse()?;
    info!(addr = %addr, "Gateway listening");

    let listener = TcpListener::bind(addr).await?;
    axum::serve(listener, app).await?;
    Ok(())
}

fn build_router(state: AppState) -> Router {
    use axum::http::HeaderName;

    // Request ID header
    let x_request_id = HeaderName::from_static("x-request-id");

    let cors = CorsLayer::new()
        .allow_origin(Any)
        .allow_methods(Any)
        .allow_headers(Any)
        .expose_headers([x_request_id.clone()]);

    Router::new()
        // Health — no auth required
        .route("/health", axum::routing::get(routes::health::health_check))
        // Public CTA redirect (no auth — recipients click from email)
        .route("/cta/:token", axum::routing::get(proxy::cta_redirect))
        // All other routes require JWT auth
        .nest("/api/v1", api_router(state.clone()))
        // Middleware stack (applied outer-to-inner)
        .layer(
            tower::ServiceBuilder::new()
                .layer(SetRequestIdLayer::new(x_request_id.clone(), MakeRequestUuid))
                .layer(PropagateRequestIdLayer::new(x_request_id))
                .layer(TraceLayer::new_for_http())
                .layer(cors),
        )
        .with_state(state)
        .fallback(not_found)
}

fn api_router(state: AppState) -> Router<AppState> {
    Router::new()
        // Jobs service
        .nest("/jobs", proxy::jobs_router())
        // Connectors
        .nest("/connectors", proxy::connectors_router())
        // Scheduler
        .nest("/scheduler", proxy::scheduler_router())
        // AI
        .nest("/ai", proxy::ai_router())
        // Approvals
        .nest("/approvals", proxy::approvals_router())
        // Audit
        .nest("/audit", proxy::audit_router())
        // Effectiveness
        .nest("/effectiveness", proxy::effectiveness_router())
        // Admin (BFF)
        .nest("/admin", proxy::admin_router())
        // Notification log
        .nest("/runs", proxy::runs_router())
        // Auth middleware on all /api/v1 routes
        .layer(axum_middleware::from_fn_with_state(
            state.clone(),
            middleware::auth::require_auth,
        ))
        // Rate limiting
        .layer(axum_middleware::from_fn_with_state(
            state,
            middleware::rate_limit::rate_limit,
        ))
}

async fn not_found() -> impl IntoResponse {
    (
        StatusCode::NOT_FOUND,
        axum::Json(serde_json::json!({
            "error": "not_found",
            "message": "The requested endpoint does not exist"
        })),
    )
}
