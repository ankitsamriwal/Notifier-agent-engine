// ── Health Checks ────────────────────────────────────────────────
//
//  /health      — lightweight liveness check (always 200 if running)
//  /health/deep — checks Redis + all upstream services
//  /ready       — K8s readiness probe

use axum::{
    extract::State,
    http::StatusCode,
    response::{IntoResponse, Json},
};
use redis::AsyncCommands;
use serde::{Deserialize, Serialize};
use serde_json::json;
use std::time::Instant;
use tokio::time::{timeout, Duration};
use tracing::warn;

use crate::AppState;

// ── Response types ────────────────────────────────────────────────

#[derive(Serialize)]
pub struct HealthResponse {
    pub status: &'static str,
    pub service: &'static str,
    pub version: &'static str,
    pub timestamp: String,
}

#[derive(Serialize)]
pub struct DeepHealthResponse {
    pub status: &'static str,
    pub service: &'static str,
    pub version: &'static str,
    pub timestamp: String,
    pub checks: Vec<HealthCheck>,
    pub total_latency_ms: u128,
}

#[derive(Serialize)]
pub struct HealthCheck {
    pub name: String,
    pub status: &'static str,
    pub latency_ms: u128,
    pub error: Option<String>,
}

// ── Handler: /health ─────────────────────────────────────────────

pub async fn health_handler() -> impl IntoResponse {
    Json(HealthResponse {
        status: "ok",
        service: "sn-gateway",
        version: env!("CARGO_PKG_VERSION"),
        timestamp: chrono::Utc::now().to_rfc3339(),
    })
}

// ── Handler: /ready ──────────────────────────────────────────────

pub async fn readiness_handler(State(state): State<AppState>) -> impl IntoResponse {
    // Check Redis (critical dependency)
    let mut conn = state.rate_limiter.redis_conn.clone();
    match redis::cmd("PING").query_async::<_, String>(&mut conn).await {
        Ok(_) => (StatusCode::OK, Json(json!({"status": "ready"}))),
        Err(_) => (
            StatusCode::SERVICE_UNAVAILABLE,
            Json(json!({"status": "not_ready", "reason": "redis_unavailable"})),
        ),
    }
}

// ── Handler: /health/deep ────────────────────────────────────────

pub async fn deep_health_handler(State(state): State<AppState>) -> impl IntoResponse {
    let start = Instant::now();
    let mut checks = Vec::new();

    // Check Redis
    checks.push(check_redis(&state).await);

    // Check all upstream services
    let services = [
        ("sn-connector",       &state.config.connector_service_url),
        ("sn-job-registry",    &state.config.job_registry_url),
        ("sn-scheduler",       &state.config.scheduler_url),
        ("sn-ai-service",      &state.config.ai_service_url),
        ("sn-approval-gate",   &state.config.approval_gate_url),
        ("sn-audit-service",   &state.config.audit_service_url),
        ("sn-effectiveness",   &state.config.effectiveness_url),
        ("sn-admin-api",       &state.config.admin_api_url),
        ("sn-notification-log",&state.config.notification_log_url),
    ];

    let upstream_checks: Vec<_> = services
        .iter()
        .map(|(name, url)| check_upstream(name, url))
        .collect();

    let results = futures::future::join_all(upstream_checks).await;
    checks.extend(results);

    let total_latency_ms = start.elapsed().as_millis();

    let all_ok = checks.iter().all(|c| c.status == "ok");

    let response = DeepHealthResponse {
        status: if all_ok { "ok" } else { "degraded" },
        service: "sn-gateway",
        version: env!("CARGO_PKG_VERSION"),
        timestamp: chrono::Utc::now().to_rfc3339(),
        checks,
        total_latency_ms,
    };

    let status_code = if all_ok {
        StatusCode::OK
    } else {
        StatusCode::SERVICE_UNAVAILABLE
    };

    (status_code, Json(response))
}

async fn check_redis(state: &AppState) -> HealthCheck {
    let start = Instant::now();
    let mut conn = state.rate_limiter.redis_conn.clone();

    match timeout(
        Duration::from_secs(2),
        redis::cmd("PING").query_async::<_, String>(&mut conn),
    )
    .await
    {
        Ok(Ok(_)) => HealthCheck {
            name: "redis".into(),
            status: "ok",
            latency_ms: start.elapsed().as_millis(),
            error: None,
        },
        Ok(Err(e)) => HealthCheck {
            name: "redis".into(),
            status: "error",
            latency_ms: start.elapsed().as_millis(),
            error: Some(e.to_string()),
        },
        Err(_) => HealthCheck {
            name: "redis".into(),
            status: "timeout",
            latency_ms: 2000,
            error: Some("Connection timed out".into()),
        },
    }
}

async fn check_upstream(name: &str, base_url: &str) -> HealthCheck {
    let start = Instant::now();
    let url = format!("{base_url}/health");

    match timeout(
        Duration::from_secs(3),
        reqwest::get(&url),
    )
    .await
    {
        Ok(Ok(res)) if res.status().is_success() => HealthCheck {
            name: name.into(),
            status: "ok",
            latency_ms: start.elapsed().as_millis(),
            error: None,
        },
        Ok(Ok(res)) => HealthCheck {
            name: name.into(),
            status: "error",
            latency_ms: start.elapsed().as_millis(),
            error: Some(format!("HTTP {}", res.status())),
        },
        Ok(Err(e)) => {
            warn!(service = name, error = %e, "Health check failed");
            HealthCheck {
                name: name.into(),
                status: "error",
                latency_ms: start.elapsed().as_millis(),
                error: Some(e.to_string()),
            }
        }
        Err(_) => HealthCheck {
            name: name.into(),
            status: "timeout",
            latency_ms: 3000,
            error: Some("Health check timed out".into()),
        },
    }
}

// Shared health checker (used by readiness probe)
pub struct HealthChecker {
    redis_conn: redis::aio::ConnectionManager,
}

impl HealthChecker {
    pub fn new(
        _config: &crate::config::AppConfig,
        redis_conn: redis::aio::ConnectionManager,
    ) -> Self {
        Self { redis_conn }
    }
}
