// ── Gateway Middleware ────────────────────────────────────────────
//
//  auth_middleware:           Extract Bearer token → verify JWT → inject headers
//  rate_limit_middleware:     Sliding window rate limiting per tenant via Redis
//  correlation_id_middleware: Ensure every request has X-Correlation-ID

use axum::{
    extract::{Request, State},
    http::{HeaderName, HeaderValue, StatusCode},
    middleware::Next,
    response::{IntoResponse, Response},
    Json,
};
use redis::AsyncCommands;
use serde_json::json;
use std::time::{SystemTime, UNIX_EPOCH};
use tracing::{debug, warn};
use uuid::Uuid;

use crate::{
    auth::{check_token_revocation, AuthError, JwtVerifier},
    AppState,
};

// ── Auth Middleware ──────────────────────────────────────────────

pub async fn auth_middleware(
    State(state): State<AppState>,
    mut req: Request,
    next: Next,
) -> Response {
    // Extract Bearer token from Authorization header
    let token = match extract_bearer_token(req.headers()) {
        Ok(t) => t,
        Err(e) => return auth_error_response(e),
    };

    // Load verifier (cached in state, lazy-init from PEM file)
    let verifier = match get_jwt_verifier(&state) {
        Ok(v) => v,
        Err(_) => return (
            StatusCode::SERVICE_UNAVAILABLE,
            Json(json!({"error": "Auth service unavailable"})),
        ).into_response(),
    };

    // Verify JWT signature and claims
    let claims = match verifier.verify(token) {
        Ok(c) => c,
        Err(e) => return auth_error_response(e),
    };

    // Check token revocation via Redis
    let mut redis_conn = state.rate_limiter.redis_conn.clone();
    if let Err(e) = check_token_revocation(&mut redis_conn, &claims).await {
        return auth_error_response(e);
    }

    // Inject tenant context headers for downstream services
    // These are trusted because they come from the verified JWT
    let headers = req.headers_mut();

    headers.insert(
        HeaderName::from_static("x-tenant-id"),
        HeaderValue::from_str(&claims.tenant_id.to_string()).unwrap(),
    );
    headers.insert(
        HeaderName::from_static("x-user-id"),
        HeaderValue::from_str(&claims.sub).unwrap(),
    );
    headers.insert(
        HeaderName::from_static("x-user-roles"),
        HeaderValue::from_str(&claims.roles.join(",")).unwrap(),
    );
    if claims.is_super_admin() {
        headers.insert(
            HeaderName::from_static("x-is-super-admin"),
            HeaderValue::from_static("true"),
        );
    }

    debug!(
        tenant_id = %claims.tenant_id,
        user_id = %claims.sub,
        roles = ?claims.roles,
        "Request authenticated"
    );

    next.run(req).await
}

fn extract_bearer_token(headers: &axum::http::HeaderMap) -> Result<&str, AuthError> {
    let auth_header = headers
        .get(axum::http::header::AUTHORIZATION)
        .ok_or(AuthError::MissingToken)?
        .to_str()
        .map_err(|_| AuthError::InvalidFormat)?;

    if !auth_header.starts_with("Bearer ") {
        return Err(AuthError::InvalidFormat);
    }

    Ok(&auth_header[7..])
}

fn get_jwt_verifier(state: &AppState) -> anyhow::Result<JwtVerifier> {
    JwtVerifier::from_pem_file(
        &state.config.jwt_public_key_path,
        &state.config.jwt_audience,
        &state.config.jwt_issuer,
    )
}

fn auth_error_response(e: AuthError) -> Response {
    let status = StatusCode::from_u16(e.status_code()).unwrap_or(StatusCode::UNAUTHORIZED);
    (status, Json(json!({"error": e.to_string(), "code": format!("{:?}", e)}))).into_response()
}

// ── Rate Limit Middleware ────────────────────────────────────────
//
//  Sliding window algorithm using Redis ZSET.
//  Key: "rl:{tenant_id}" → sorted set of request timestamps
//  Window: 60 seconds, limit: config.rate_limit_rpm

pub async fn rate_limit_middleware(
    state: AppState,
    req: Request,
    next: Next,
) -> Response {
    // Extract tenant ID (injected by auth middleware)
    let tenant_id = req
        .headers()
        .get("x-tenant-id")
        .and_then(|v| v.to_str().ok())
        .unwrap_or("anonymous");

    match state.rate_limiter.check_rate_limit(tenant_id).await {
        Ok(true) => next.run(req).await,
        Ok(false) => {
            warn!(tenant_id, "Rate limit exceeded");
            (
                StatusCode::TOO_MANY_REQUESTS,
                [
                    ("Retry-After", "60"),
                    ("X-RateLimit-Limit", &state.config.rate_limit_rpm.to_string()),
                ],
                Json(json!({
                    "error": "Rate limit exceeded",
                    "message": "Too many requests. Please retry after 60 seconds.",
                    "retry_after_seconds": 60
                })),
            ).into_response()
        }
        Err(e) => {
            warn!(error = %e, "Rate limiter error — allowing request");
            next.run(req).await  // Fail open — don't block if Redis is down
        }
    }
}

// ── Correlation ID Middleware ────────────────────────────────────
//
//  Ensures every request has X-Correlation-ID.
//  If client provides one, it's validated and forwarded.
//  If not, a new UUID v4 is generated.
//  The same ID is echoed in the response.

pub async fn correlation_id_middleware(mut req: Request, next: Next) -> Response {
    let correlation_id = req
        .headers()
        .get("x-correlation-id")
        .and_then(|v| v.to_str().ok())
        .filter(|s| !s.is_empty())
        .map(String::from)
        .unwrap_or_else(|| Uuid::new_v4().to_string());

    // Inject into request for downstream services
    req.headers_mut().insert(
        HeaderName::from_static("x-correlation-id"),
        HeaderValue::from_str(&correlation_id).unwrap(),
    );

    let mut response = next.run(req).await;

    // Echo correlation ID in response for client tracing
    response.headers_mut().insert(
        HeaderName::from_static("x-correlation-id"),
        HeaderValue::from_str(&correlation_id).unwrap(),
    );

    response
}
