// ── Rate Limiter — Redis Sliding Window ─────────────────────────
//
//  Algorithm: sorted set per tenant.
//  ZREMRANGEBYSCORE to remove old entries.
//  ZCARD to count current window.
//  ZADD NX to add current timestamp.
//  EXPIRE to set TTL on the key.

use anyhow::Result;
use redis::{aio::ConnectionManager, AsyncCommands};
use std::time::{SystemTime, UNIX_EPOCH};
use tracing::debug;

#[derive(Clone)]
pub struct RateLimiter {
    pub redis_conn: ConnectionManager,
    /// Maximum requests per 60-second window
    limit: u32,
}

impl RateLimiter {
    pub fn new(redis_conn: ConnectionManager, limit: u32) -> Self {
        Self { redis_conn, limit }
    }

    /// Returns true if request is allowed, false if rate limited.
    pub async fn check_rate_limit(&self, tenant_id: &str) -> Result<bool> {
        let mut conn = self.redis_conn.clone();
        let key = format!("rl:{tenant_id}");
        let now_ms = SystemTime::now()
            .duration_since(UNIX_EPOCH)?
            .as_millis() as f64;
        let window_start = now_ms - 60_000.0; // 60-second window

        // Atomic sliding window via Redis pipeline
        let (_, count, _, _): (i64, i64, i64, bool) = redis::pipe()
            .atomic()
            // Remove entries outside the window
            .cmd("ZREMRANGEBYSCORE")
                .arg(&key)
                .arg("-inf")
                .arg(window_start)
            // Count requests in current window
            .cmd("ZCARD").arg(&key)
            // Add current request
            .cmd("ZADD")
                .arg(&key)
                .arg("NX")
                .arg(now_ms)
                .arg(format!("{now_ms}"))
            // Set expiry (auto-cleanup)
            .cmd("EXPIRE").arg(&key).arg(120u64)
            .query_async(&mut conn)
            .await?;

        let allowed = count < self.limit as i64;

        debug!(
            tenant_id,
            current_count = count,
            limit = self.limit,
            allowed,
            "Rate limit check"
        );

        Ok(allowed)
    }
}
