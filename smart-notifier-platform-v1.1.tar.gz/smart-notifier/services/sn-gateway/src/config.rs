use serde::Deserialize;
use anyhow::{Context, Result};

#[derive(Debug, Clone, Deserialize)]
pub struct GatewayConfig {
    #[serde(default = "default_port")]
    pub port: u16,

    pub redis_url: String,

    pub jwt_issuer: String,
    pub jwt_audience: String,

    // Ed25519 public key (base64) for JWT verification
    // In production: fetched from Vault transit/keys/sn-jwt-key
    pub jwt_public_key_b64: Option<String>,

    #[serde(default = "default_rate_limit")]
    pub rate_limit_rpm: u32,

    pub otel_endpoint: String,

    // Downstream service URLs
    pub sn_job_registry_url: String,
    pub sn_connector_url: String,
    pub sn_scheduler_url: String,
    pub sn_ai_service_url: String,
    pub sn_approval_gate_url: String,
    pub sn_cta_processor_url: String,
    pub sn_audit_service_url: String,
    pub sn_effectiveness_url: String,
    pub sn_admin_api_url: String,
    pub sn_notification_log_url: String,
}

fn default_port() -> u16 { 8080 }
fn default_rate_limit() -> u32 { 100 }

impl GatewayConfig {
    pub fn from_env() -> Result<Self> {
        dotenvy::dotenv().ok();
        let cfg = config::Config::builder()
            .add_source(config::Environment::default().separator("_").try_parsing(true))
            .build()
            .context("Failed to build config")?;
        cfg.try_deserialize::<Self>()
           .context("Failed to deserialise gateway config")
    }
}
