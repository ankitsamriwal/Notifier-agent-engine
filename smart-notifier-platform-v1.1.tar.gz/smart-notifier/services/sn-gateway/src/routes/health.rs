use axum::{Json, extract::State};
use serde_json::{json, Value};
use redis::AsyncCommands;
use crate::AppState;

pub async fn health_check(State(state): State<AppState>) -> Json<Value> {
    let redis_ok = {
        let mut conn = state.redis.clone();
        let r: Result<String, _> = redis::cmd("PING").query_async(&mut conn).await;
        r.is_ok()
    };
    Json(json!({
        "service": "sn-gateway",
        "version": env!("CARGO_PKG_VERSION"),
        "status": if redis_ok { "healthy" } else { "degraded" },
        "checks": {
            "redis": if redis_ok { "ok" } else { "error" }
        }
    }))
}
