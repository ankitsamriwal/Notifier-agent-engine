// ── Service Proxy — HTTP reverse proxy to upstream microservices ─
//
//  Each handler extracts path + method + headers from the incoming
//  request and forwards it to the appropriate upstream service.
//  Response is streamed back transparently.
//
//  Headers forwarded to upstreams (from auth middleware):
//    X-Tenant-ID, X-User-ID, X-User-Roles, X-Correlation-ID

use axum::{
    body::Body,
    extract::{Path, Request, State},
    http::{HeaderMap, HeaderName, HeaderValue, Method, StatusCode, Uri},
    response::{IntoResponse, Response},
};
use reqwest::Client;
use std::{sync::Arc, time::Duration};
use tracing::{debug, warn};

use crate::{config::AppConfig, AppState};

// ── Service Proxy ────────────────────────────────────────────────

#[derive(Clone)]
pub struct ServiceProxy {
    client: Client,
    config: Arc<AppConfig>,
}

impl ServiceProxy {
    pub fn new(config: &Arc<AppConfig>) -> anyhow::Result<Self> {
        let client = Client::builder()
            .timeout(Duration::from_secs(config.upstream_timeout_secs))
            .pool_max_idle_per_host(20)
            .pool_idle_timeout(Duration::from_secs(90))
            .tcp_keepalive(Duration::from_secs(60))
            .connection_verbose(false)
            .build()?;

        Ok(Self {
            client,
            config: config.clone(),
        })
    }

    /// Forward request to an upstream URL, preserving method, headers, and body.
    pub async fn forward(&self, upstream_base: &str, req: Request) -> Response {
        // Build upstream URL
        let path_and_query = req
            .uri()
            .path_and_query()
            .map(|pq| pq.as_str())
            .unwrap_or("/");

        // Strip /api/v1/... prefix and rebuild for upstream
        let upstream_path = strip_gateway_prefix(path_and_query);
        let upstream_url = format!("{upstream_base}{upstream_path}");

        debug!(upstream_url, method = %req.method(), "Proxying request");

        // Build reqwest request
        let method = reqwest::Method::from_bytes(req.method().as_str().as_bytes())
            .unwrap_or(reqwest::Method::GET);

        let mut upstream_req = self.client.request(method, &upstream_url);

        // Forward safe headers (block hop-by-hop headers)
        for (name, value) in req.headers() {
            let name_str = name.as_str();
            if is_forwarded_header(name_str) {
                if let Ok(header_name) = reqwest::header::HeaderName::from_bytes(name.as_ref()) {
                    if let Ok(header_value) = reqwest::header::HeaderValue::from_bytes(value.as_bytes()) {
                        upstream_req = upstream_req.header(header_name, header_value);
                    }
                }
            }
        }

        // Forward body
        let body = axum::body::to_bytes(req.into_body(), 50 * 1024 * 1024)
            .await
            .unwrap_or_default();

        if !body.is_empty() {
            upstream_req = upstream_req.body(body.to_vec());
        }

        // Execute and convert response
        match upstream_req.send().await {
            Ok(upstream_res) => {
                let status = StatusCode::from_u16(upstream_res.status().as_u16())
                    .unwrap_or(StatusCode::INTERNAL_SERVER_ERROR);

                let mut response_headers = HeaderMap::new();
                for (name, value) in upstream_res.headers() {
                    if let (Ok(n), Ok(v)) = (
                        HeaderName::from_bytes(name.as_ref()),
                        HeaderValue::from_bytes(value.as_bytes()),
                    ) {
                        response_headers.insert(n, v);
                    }
                }

                let body = upstream_res.bytes().await.unwrap_or_default();

                (status, response_headers, body).into_response()
            }
            Err(e) => {
                warn!(error = %e, upstream_url, "Upstream request failed");
                if e.is_timeout() {
                    (
                        StatusCode::GATEWAY_TIMEOUT,
                        axum::Json(serde_json::json!({
                            "error": "Upstream service timed out",
                            "service": upstream_url,
                        })),
                    ).into_response()
                } else {
                    (
                        StatusCode::BAD_GATEWAY,
                        axum::Json(serde_json::json!({
                            "error": "Upstream service unavailable",
                        })),
                    ).into_response()
                }
            }
        }
    }
}

// ── Route handlers — one per upstream service ────────────────────

pub async fn connector_handler(State(state): State<AppState>, req: Request) -> Response {
    state.proxy.forward(&state.config.connector_service_url, req).await
}

pub async fn job_registry_handler(State(state): State<AppState>, req: Request) -> Response {
    state.proxy.forward(&state.config.job_registry_url, req).await
}

pub async fn scheduler_handler(State(state): State<AppState>, req: Request) -> Response {
    state.proxy.forward(&state.config.scheduler_url, req).await
}

pub async fn ai_service_handler(State(state): State<AppState>, req: Request) -> Response {
    state.proxy.forward(&state.config.ai_service_url, req).await
}

pub async fn approval_handler(State(state): State<AppState>, req: Request) -> Response {
    state.proxy.forward(&state.config.approval_gate_url, req).await
}

pub async fn audit_handler(State(state): State<AppState>, req: Request) -> Response {
    state.proxy.forward(&state.config.audit_service_url, req).await
}

pub async fn effectiveness_handler(State(state): State<AppState>, req: Request) -> Response {
    state.proxy.forward(&state.config.effectiveness_url, req).await
}

pub async fn admin_api_handler(State(state): State<AppState>, req: Request) -> Response {
    state.proxy.forward(&state.config.admin_api_url, req).await
}

pub async fn notification_log_handler(State(state): State<AppState>, req: Request) -> Response {
    state.proxy.forward(&state.config.notification_log_url, req).await
}

/// CTA clicks are public routes — forward to cta-processor without auth headers
pub async fn cta_click_handler(State(state): State<AppState>, req: Request) -> Response {
    state.proxy.forward(&state.config.cta_processor_url, req).await
}

// ── Helpers ──────────────────────────────────────────────────────

fn strip_gateway_prefix(path: &str) -> &str {
    // /api/v1/connectors/... → /connectors/...
    // /api/v1/jobs/...       → /jobs/...
    if let Some(stripped) = path.strip_prefix("/api/v1") {
        stripped
    } else if let Some(stripped) = path.strip_prefix("/cta") {
        stripped
    } else {
        path
    }
}

/// Only forward these headers to upstream services.
/// Block hop-by-hop and sensitive headers.
fn is_forwarded_header(name: &str) -> bool {
    !matches!(
        name,
        "connection" | "keep-alive" | "proxy-authenticate"
            | "proxy-authorization" | "te" | "trailers"
            | "transfer-encoding" | "upgrade" | "host"
    )
}
