// ── JWT Authentication — Ed25519 verification ────────────────────
//
//  Verifies JWT tokens signed with Ed25519.
//  Checks token revocation via Redis (token_version field).
//  Claims extracted and forwarded to upstreams as X-Tenant-ID,
//  X-User-ID, X-User-Roles headers.

use anyhow::{Context, Result};
use jsonwebtoken::{decode, decode_header, Algorithm, DecodingKey, Validation};
use redis::aio::ConnectionManager;
use serde::{Deserialize, Serialize};
use std::fs;
use tracing::{debug, warn};
use uuid::Uuid;

// ── JWT Claims structure ─────────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Claims {
    /// Subject — user UUID
    pub sub: String,
    /// Tenant UUID
    pub tenant_id: Uuid,
    /// Roles array: ["operator", "viewer"]
    pub roles: Vec<String>,
    /// Issued at (Unix timestamp)
    pub iat: i64,
    /// Expiry (Unix timestamp)
    pub exp: i64,
    /// JWT ID (for revocation)
    pub jti: String,
    /// Token version (must match DB user.token_version)
    pub token_version: i32,
    /// Issuer
    pub iss: String,
    /// Audience
    pub aud: String,
}

impl Claims {
    pub fn user_id(&self) -> Result<Uuid> {
        Uuid::parse_str(&self.sub).context("Invalid user_id in JWT sub claim")
    }

    pub fn has_role(&self, role: &str) -> bool {
        self.roles.iter().any(|r| r == role)
    }

    pub fn is_super_admin(&self) -> bool {
        self.has_role("super_admin")
    }
}

// ── JWT Verifier ─────────────────────────────────────────────────

#[derive(Clone)]
pub struct JwtVerifier {
    decoding_key: DecodingKey,
    validation: Validation,
}

impl JwtVerifier {
    pub fn from_pem_file(path: &str, audience: &str, issuer: &str) -> Result<Self> {
        let pem = fs::read_to_string(path)
            .with_context(|| format!("Failed to read JWT public key from {path}"))?;

        let decoding_key = DecodingKey::from_ed_pem(pem.as_bytes())
            .context("Failed to parse Ed25519 public key")?;

        let mut validation = Validation::new(Algorithm::EdDSA);
        validation.set_audience(&[audience]);
        validation.set_issuer(&[issuer]);
        validation.validate_exp = true;
        validation.leeway = 10; // 10 second clock skew tolerance

        Ok(Self { decoding_key, validation })
    }

    /// Verify JWT and return parsed claims.
    pub fn verify(&self, token: &str) -> Result<Claims, AuthError> {
        let token_data = decode::<Claims>(token, &self.decoding_key, &self.validation)
            .map_err(|e| {
                debug!(error = %e, "JWT verification failed");
                match e.kind() {
                    jsonwebtoken::errors::ErrorKind::ExpiredSignature => AuthError::TokenExpired,
                    jsonwebtoken::errors::ErrorKind::InvalidAudience => AuthError::InvalidAudience,
                    jsonwebtoken::errors::ErrorKind::InvalidIssuer => AuthError::InvalidIssuer,
                    _ => AuthError::InvalidToken(e.to_string()),
                }
            })?;

        Ok(token_data.claims)
    }
}

// ── Token revocation check via Redis ────────────────────────────

/// Check if the JWT has been revoked by comparing token_version
/// against the cached user token_version in Redis.
///
/// Redis key: "token_version:{user_id}" → stored version number
/// If token.token_version < stored_version → token is revoked
pub async fn check_token_revocation(
    redis: &mut ConnectionManager,
    claims: &Claims,
) -> Result<bool, AuthError> {
    let key = format!("token_version:{}", claims.sub);

    let stored_version: Option<i32> = redis::cmd("GET")
        .arg(&key)
        .query_async(redis)
        .await
        .map_err(|e| {
            warn!(error = %e, "Redis error during token revocation check");
            AuthError::ServiceUnavailable
        })?;

    match stored_version {
        Some(version) if claims.token_version < version => {
            debug!(
                user_id = %claims.sub,
                token_version = claims.token_version,
                stored_version = version,
                "Token revoked — version mismatch"
            );
            Err(AuthError::TokenRevoked)
        }
        _ => Ok(true), // Not revoked (or no version stored — accept)
    }
}

// ── Auth errors ──────────────────────────────────────────────────

#[derive(Debug, thiserror::Error)]
pub enum AuthError {
    #[error("No Authorization header provided")]
    MissingToken,

    #[error("Authorization header must be 'Bearer <token>'")]
    InvalidFormat,

    #[error("Token has expired")]
    TokenExpired,

    #[error("Invalid audience")]
    InvalidAudience,

    #[error("Invalid issuer")]
    InvalidIssuer,

    #[error("Invalid token: {0}")]
    InvalidToken(String),

    #[error("Token has been revoked")]
    TokenRevoked,

    #[error("Auth service temporarily unavailable")]
    ServiceUnavailable,

    #[error("Insufficient permissions")]
    Forbidden,
}

impl AuthError {
    pub fn status_code(&self) -> u16 {
        match self {
            AuthError::MissingToken      => 401,
            AuthError::InvalidFormat     => 401,
            AuthError::TokenExpired      => 401,
            AuthError::InvalidAudience   => 401,
            AuthError::InvalidIssuer     => 401,
            AuthError::InvalidToken(_)   => 401,
            AuthError::TokenRevoked      => 401,
            AuthError::ServiceUnavailable => 503,
            AuthError::Forbidden         => 403,
        }
    }
}
