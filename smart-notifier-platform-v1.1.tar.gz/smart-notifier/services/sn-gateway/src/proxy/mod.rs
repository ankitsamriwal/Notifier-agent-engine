//! Reverse proxy — forwards authenticated requests to downstream services
//! Injects: X-Tenant-Id, X-User-Id, X-Roles, X-Correlation-Id headers

use axum::{
    Router,
    routing::any,
    extract::{State, Request, Path},
    response::{Response, IntoResponse},
    http::{HeaderMap, HeaderName, HeaderValue, StatusCode},
    body::Body,
};
use crate::{AppState, error::GatewayError, middleware::auth::AuthClaims};

/// Build a proxy route that forwards all methods to a target service
fn proxy_router(path_prefix: &str, target_url_fn: fn(&AppState) -> &str) -> Router<AppState> {
    Router::new()
        .route("/", any(forward_request))
        .route("/*path", any(forward_request))
}

pub fn jobs_router()        -> Router<AppState> { build_proxy_routes("sn_job_registry_url") }
pub fn connectors_router()  -> Router<AppState> { build_proxy_routes("sn_connector_url") }
pub fn scheduler_router()   -> Router<AppState> { build_proxy_routes("sn_scheduler_url") }
pub fn ai_router()          -> Router<AppState> { build_proxy_routes("sn_ai_service_url") }
pub fn approvals_router()   -> Router<AppState> { build_proxy_routes("sn_approval_gate_url") }
pub fn audit_router()       -> Router<AppState> { build_proxy_routes("sn_audit_service_url") }
pub fn effectiveness_router()-> Router<AppState>{ build_proxy_routes("sn_effectiveness_url") }
pub fn admin_router()       -> Router<AppState> { build_proxy_routes("sn_admin_api_url") }
pub fn runs_router()        -> Router<AppState> { build_proxy_routes("sn_notification_log_url") }

fn build_proxy_routes(service_key: &'static str) -> Router<AppState> {
    Router::new()
        .route("/", any(move |s, r| proxy_to(s, r, service_key, "")))
        .route("/*path", any(move |s, req: Request, Path(path): Path<String>| {
            proxy_to(s, req, service_key, &path)
        }))
}

async fn proxy_to(
    State(state): State<AppState>,
    req: Request,
    service_key: &str,
    sub_path: &str,
) -> Result<Response, GatewayError> {
    let base = get_service_url(&state, service_key)
        .ok_or_else(|| GatewayError::ServiceUnavailable(format!("{service_key} not configured")))?;

    let uri_str = req.uri().to_string();
    let target = format!("{base}/{sub_path}?{}", req.uri().query().unwrap_or(""));
    let target = target.trim_end_matches('?').to_string();

    let method = req.method().clone();
    let mut headers = req.headers().clone();

    // Inject internal auth headers from JWT claims
    if let Some(claims) = req.extensions().get::<AuthClaims>() {
        headers.insert(
            HeaderName::from_static("x-tenant-id"),
            HeaderValue::from_str(&claims.tenant_id.to_string()).unwrap(),
        );
        headers.insert(
            HeaderName::from_static("x-user-id"),
            HeaderValue::from_str(&claims.sub.to_string()).unwrap(),
        );
        headers.insert(
            HeaderName::from_static("x-roles"),
            HeaderValue::from_str(&claims.roles.join(",")).unwrap(),
        );
    }

    // Forward correlation ID
    if let Some(corr_id) = req.headers().get("x-request-id") {
        headers.insert(HeaderName::from_static("x-correlation-id"), corr_id.clone());
    }

    // Strip external auth header before forwarding (services trust x-tenant-id/x-user-id)
    headers.remove(axum::http::header::AUTHORIZATION);

    let body_bytes = axum::body::to_bytes(req.into_body(), usize::MAX)
        .await
        .map_err(|e| GatewayError::BadGateway(e.to_string()))?;

    let upstream = state.http_client
        .request(method, &target)
        .headers(headers)
        .body(body_bytes)
        .send()
        .await
        .map_err(|e| GatewayError::ServiceUnavailable(e.to_string()))?;

    // Stream response back
    let status = upstream.status();
    let headers = upstream.headers().clone();
    let body = upstream.bytes().await
        .map_err(|e| GatewayError::BadGateway(e.to_string()))?;

    let mut resp = Response::builder().status(status);
    for (k, v) in headers.iter() {
        resp = resp.header(k, v);
    }
    Ok(resp.body(Body::from(body))
        .map_err(|e| GatewayError::Internal(anyhow::anyhow!("{e}")))?)
}

/// CTA redirect — no auth, proxied to cta-processor
pub async fn cta_redirect(
    State(state): State<AppState>,
    Path(token): Path<String>,
    req: Request,
) -> Result<Response, GatewayError> {
    let target = format!("{}/cta/{}", state.config.sn_cta_processor_url, token);
    let upstream = state.http_client.get(&target).send().await
        .map_err(|e| GatewayError::ServiceUnavailable(e.to_string()))?;
    let status = upstream.status();
    let headers = upstream.headers().clone();
    let body = upstream.bytes().await
        .map_err(|e| GatewayError::BadGateway(e.to_string()))?;
    let mut resp = Response::builder().status(status);
    for (k, v) in headers.iter() { resp = resp.header(k, v); }
    Ok(resp.body(Body::from(body))
        .map_err(|e| GatewayError::Internal(anyhow::anyhow!("{e}")))?)
}

async fn forward_request(State(state): State<AppState>, req: Request) -> impl IntoResponse {
    (StatusCode::NOT_FOUND, "Route not matched")
}

fn get_service_url<'a>(state: &'a AppState, key: &str) -> Option<&'a str> {
    match key {
        "sn_job_registry_url"    => Some(&state.config.sn_job_registry_url),
        "sn_connector_url"       => Some(&state.config.sn_connector_url),
        "sn_scheduler_url"       => Some(&state.config.sn_scheduler_url),
        "sn_ai_service_url"      => Some(&state.config.sn_ai_service_url),
        "sn_approval_gate_url"   => Some(&state.config.sn_approval_gate_url),
        "sn_cta_processor_url"   => Some(&state.config.sn_cta_processor_url),
        "sn_audit_service_url"   => Some(&state.config.sn_audit_service_url),
        "sn_effectiveness_url"   => Some(&state.config.sn_effectiveness_url),
        "sn_admin_api_url"       => Some(&state.config.sn_admin_api_url),
        "sn_notification_log_url"=> Some(&state.config.sn_notification_log_url),
        _ => None,
    }
}
