use axum::{response::{IntoResponse, Response}, http::StatusCode, Json};
use serde_json::json;
use thiserror::Error;

#[derive(Debug, Error)]
pub enum GatewayError {
    #[error("Unauthorized: {0}")]
    Unauthorized(String),

    #[error("Rate limit exceeded")]
    RateLimited,

    #[error("Service unavailable: {0}")]
    ServiceUnavailable(String),

    #[error("Bad gateway: {0}")]
    BadGateway(String),

    #[error("Internal error: {0}")]
    Internal(#[from] anyhow::Error),
}

impl IntoResponse for GatewayError {
    fn into_response(self) -> Response {
        let (status, code, msg) = match &self {
            Self::Unauthorized(m)      => (StatusCode::UNAUTHORIZED,            "unauthorized",       m.clone()),
            Self::RateLimited          => (StatusCode::TOO_MANY_REQUESTS,       "rate_limited",       "Rate limit exceeded. Retry after 60 seconds.".into()),
            Self::ServiceUnavailable(m)=> (StatusCode::SERVICE_UNAVAILABLE,     "service_unavailable", m.clone()),
            Self::BadGateway(m)        => (StatusCode::BAD_GATEWAY,             "bad_gateway",        m.clone()),
            Self::Internal(e)          => (StatusCode::INTERNAL_SERVER_ERROR,   "internal_error",     e.to_string()),
        };
        (status, Json(json!({"error": code, "message": msg}))).into_response()
    }
}
