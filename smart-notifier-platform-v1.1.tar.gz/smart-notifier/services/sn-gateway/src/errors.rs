// ── Centralised error types and HTTP error responses ─────────────

use axum::{http::StatusCode, response::{IntoResponse, Json}};
use serde_json::json;
use thiserror::Error;

#[derive(Debug, Error)]
pub enum GatewayError {
    #[error("Service unavailable: {0}")]
    ServiceUnavailable(String),

    #[error("Bad gateway: {0}")]
    BadGateway(String),

    #[error("Configuration error: {0}")]
    Config(String),
}

impl IntoResponse for GatewayError {
    fn into_response(self) -> axum::response::Response {
        let (status, code) = match &self {
            GatewayError::ServiceUnavailable(_) => (StatusCode::SERVICE_UNAVAILABLE, "SERVICE_UNAVAILABLE"),
            GatewayError::BadGateway(_)         => (StatusCode::BAD_GATEWAY, "BAD_GATEWAY"),
            GatewayError::Config(_)             => (StatusCode::INTERNAL_SERVER_ERROR, "CONFIG_ERROR"),
        };
        (status, Json(json!({"error": self.to_string(), "code": code}))).into_response()
    }
}
