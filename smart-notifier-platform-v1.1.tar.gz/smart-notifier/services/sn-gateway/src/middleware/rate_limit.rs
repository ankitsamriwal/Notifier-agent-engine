use axum::{extract::{State, Request}, middleware::Next, response::Response};
use redis::AsyncCommands;
use chrono::Utc;
use crate::{AppState, error::GatewayError, middleware::auth::AuthClaims};

pub async fn rate_limit(
    State(state): State<AppState>,
    req: Request,
    next: Next,
) -> Result<Response, GatewayError> {
    let tenant_id = req.extensions()
        .get::<AuthClaims>()
        .map(|c| c.tenant_id.to_string())
        .unwrap_or_else(|| "anon".into());

    let window = Utc::now().timestamp() / 60;
    let key = format!("sn:rl:{}:{}", tenant_id, window);
    let mut conn = state.redis.clone();

    let count: u32 = redis::pipe()
        .atomic()
        .incr(&key, 1u32)
        .expire(&key, 90i64)
        .ignore()
        .query_async(&mut conn)
        .await
        .map_err(|e| GatewayError::Internal(anyhow::anyhow!("Redis: {e}")))?;

    if count > state.config.rate_limit_rpm {
        return Err(GatewayError::RateLimited);
    }
    Ok(next.run(req).await)
}
