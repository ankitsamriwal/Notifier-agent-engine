use axum::{
    extract::{State, Request},
    middleware::Next,
    response::Response,
    http::header::AUTHORIZATION,
};
use jsonwebtoken::{decode, DecodingKey, Validation, Algorithm};
use redis::AsyncCommands;
use serde::{Deserialize, Serialize};
use uuid::Uuid;
use crate::{AppState, error::GatewayError};

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct Claims {
    pub sub: Uuid,
    pub tenant_id: Uuid,
    pub roles: Vec<String>,
    pub iss: String,
    pub aud: Vec<String>,
    pub exp: u64,
    pub iat: u64,
    pub jti: String,
}
pub type AuthClaims = Claims;

pub async fn require_auth(
    State(state): State<AppState>,
    mut req: Request,
    next: Next,
) -> Result<Response, GatewayError> {
    let token = req.headers()
        .get(AUTHORIZATION)
        .and_then(|v| v.to_str().ok())
        .and_then(|v| v.strip_prefix("Bearer "))
        .ok_or_else(|| GatewayError::Unauthorized("Missing Authorization header".into()))?;

    let mut validation = Validation::new(Algorithm::EdDSA);
    validation.set_issuer(&[&state.config.jwt_issuer]);
    validation.set_audience(&[&state.config.jwt_audience]);
    validation.validate_exp = true;
    validation.leeway = 5;

    // Dev mode: skip signature if no key configured
    let claims = if let Some(key_b64) = &state.config.jwt_public_key_b64 {
        let key_bytes = base64::Engine::decode(
            &base64::engine::general_purpose::STANDARD, key_b64
        ).map_err(|_| GatewayError::Unauthorized("Invalid key".into()))?;
        let key = DecodingKey::from_ed_der(&key_bytes);
        decode::<Claims>(token, &key, &validation)
            .map_err(|e| GatewayError::Unauthorized(format!("Invalid token: {e}")))?
            .claims
    } else {
        // Dev: decode without verification — NEVER use in prod
        tracing::warn!("JWT signature verification disabled (dev mode)");
        validation.insecure_disable_signature_validation();
        let key = DecodingKey::from_secret(b"dev-secret");
        decode::<Claims>(token, &key, &validation)
            .map_err(|e| GatewayError::Unauthorized(format!("Malformed token: {e}")))?
            .claims
    };

    // Check token revocation
    let rev_key = format!("sn:revoked:{}", claims.jti);
    let mut conn = state.redis.clone();
    let revoked: bool = conn.exists(&rev_key).await
        .map_err(|e| GatewayError::Internal(anyhow::anyhow!("Redis: {e}")))?;
    if revoked {
        return Err(GatewayError::Unauthorized("Token revoked".into()));
    }

    req.extensions_mut().insert(claims);
    Ok(next.run(req).await)
}
