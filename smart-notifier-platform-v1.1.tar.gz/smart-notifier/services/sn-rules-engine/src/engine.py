"""
Rules Engine — stateless AND/OR criteria evaluator against pandas DataFrames.
Zero Python loops over rows: all evaluation is vectorised via pandas.
"""
from __future__ import annotations
import logging
import re
from datetime import datetime
from typing import Any

import pandas as pd
import numpy as np

logger = logging.getLogger(__name__)


# ── Operator implementations (vectorised) ─────────────────────────────────────

def _op_greater_than(series: pd.Series, value: Any) -> pd.Series:
    try:
        return pd.to_numeric(series, errors='coerce') > float(value)
    except (TypeError, ValueError):
        return pd.Series([False] * len(series))


def _op_less_than(series: pd.Series, value: Any) -> pd.Series:
    try:
        return pd.to_numeric(series, errors='coerce') < float(value)
    except (TypeError, ValueError):
        return pd.Series([False] * len(series))


def _op_equals(series: pd.Series, value: Any) -> pd.Series:
    # Try numeric comparison first
    numeric = pd.to_numeric(series, errors='coerce')
    try:
        num_val = float(value)
        num_match = numeric == num_val
        # String fallback where numeric conversion failed
        str_match = series.astype(str).str.strip() == str(value).strip()
        return num_match.fillna(False) | (numeric.isna() & str_match)
    except (TypeError, ValueError):
        return series.astype(str).str.strip() == str(value).strip()


def _op_not_equals(series: pd.Series, value: Any) -> pd.Series:
    return ~_op_equals(series, value)


def _op_contains(series: pd.Series, value: Any) -> pd.Series:
    return series.astype(str).str.contains(str(value), case=False, na=False, regex=False)


def _op_not_contains(series: pd.Series, value: Any) -> pd.Series:
    return ~_op_contains(series, value)


def _op_is_empty(series: pd.Series, _: Any) -> pd.Series:
    return series.isna() | (series.astype(str).str.strip() == '')


def _op_is_not_empty(series: pd.Series, _: Any) -> pd.Series:
    return ~_op_is_empty(series, _)


def _op_regex(series: pd.Series, value: Any) -> pd.Series:
    try:
        return series.astype(str).str.match(str(value), na=False)
    except re.error:
        logger.warning("Invalid regex pattern: %s", value)
        return pd.Series([False] * len(series))


def _op_date_before(series: pd.Series, value: Any) -> pd.Series:
    parsed = pd.to_datetime(series, errors='coerce', utc=True)
    try:
        threshold = pd.to_datetime(value, utc=True)
        return parsed < threshold
    except Exception:
        return pd.Series([False] * len(series))


def _op_date_after(series: pd.Series, value: Any) -> pd.Series:
    parsed = pd.to_datetime(series, errors='coerce', utc=True)
    try:
        threshold = pd.to_datetime(value, utc=True)
        return parsed > threshold
    except Exception:
        return pd.Series([False] * len(series))


OPERATORS: dict[str, Any] = {
    'greater_than':  _op_greater_than,
    'less_than':     _op_less_than,
    'equals':        _op_equals,
    'not_equals':    _op_not_equals,
    'contains':      _op_contains,
    'not_contains':  _op_not_contains,
    'is_empty':      _op_is_empty,
    'is_not_empty':  _op_is_not_empty,
    'regex':         _op_regex,
    'date_before':   _op_date_before,
    'date_after':    _op_date_after,
}


# ── Evaluation result ─────────────────────────────────────────────────────────

class EvaluationResult:
    __slots__ = ('matched', 'unmatched', 'match_count', 'total_count', 'evaluation_ms')

    def __init__(
        self,
        matched: pd.DataFrame,
        unmatched: pd.DataFrame,
        evaluation_ms: int,
    ):
        self.matched      = matched
        self.unmatched    = unmatched
        self.match_count  = len(matched)
        self.total_count  = len(matched) + len(unmatched)
        self.evaluation_ms = evaluation_ms


# ── Main evaluator ────────────────────────────────────────────────────────────

class RulesEvaluator:
    """
    Stateless rules evaluator. Evaluate criteria JSON against a DataFrame.
    All evaluation is vectorised — no Python row-iteration.
    """

    def evaluate(self, df: pd.DataFrame, criteria: dict[str, Any]) -> EvaluationResult:
        import time
        t0 = time.monotonic()

        if df.empty:
            return EvaluationResult(
                matched=df.copy(), unmatched=df.copy(),
                evaluation_ms=0,
            )

        logic      = criteria.get('logic', 'AND').upper()
        conditions = criteria.get('conditions', [])

        if not conditions:
            # No criteria → all rows match
            return EvaluationResult(
                matched=df.copy(), unmatched=pd.DataFrame(columns=df.columns),
                evaluation_ms=0,
            )

        # Evaluate each condition → boolean Series
        masks = [self._evaluate_condition(df, cond) for cond in conditions]

        # Combine masks
        if logic == 'AND':
            combined = masks[0]
            for m in masks[1:]:
                combined = combined & m
        elif logic == 'OR':
            combined = masks[0]
            for m in masks[1:]:
                combined = combined | m
        else:
            raise ValueError(f"Unknown logic operator: {logic}")

        matched   = df[combined].copy().reset_index(drop=True)
        unmatched = df[~combined].copy().reset_index(drop=True)

        elapsed_ms = int((time.monotonic() - t0) * 1000)
        logger.info(
            "Evaluated %d rows → %d matched (%dms)",
            len(df), len(matched), elapsed_ms
        )

        return EvaluationResult(
            matched=matched, unmatched=unmatched, evaluation_ms=elapsed_ms
        )

    def _evaluate_condition(self, df: pd.DataFrame, condition: dict[str, Any]) -> pd.Series:
        field = condition.get('field', '')
        op    = condition.get('op', '')
        value = condition.get('value')

        if field not in df.columns:
            logger.warning("Field '%s' not found in DataFrame columns: %s", field, list(df.columns))
            return pd.Series([False] * len(df))

        op_fn = OPERATORS.get(op)
        if op_fn is None:
            logger.warning("Unknown operator: %s", op)
            return pd.Series([False] * len(df))

        try:
            result = op_fn(df[field], value)
            # Ensure bool dtype, handle NaN → False
            return result.fillna(False).astype(bool)
        except Exception as exc:
            logger.error("Condition evaluation error (field=%s op=%s): %s", field, op, exc)
            return pd.Series([False] * len(df))
