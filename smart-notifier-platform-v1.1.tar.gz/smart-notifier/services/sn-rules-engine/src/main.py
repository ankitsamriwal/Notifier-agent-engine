"""
Smart Notifier — Rules Engine Service
Stateless AMQP worker: consumes data.fetched, evaluates criteria, emits rules.matched
"""
import asyncio, json, logging, os
import uvicorn
from fastapi import FastAPI
from contextlib import asynccontextmanager
import aio_pika
import pandas as pd
from .engine import RulesEvaluator

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
logger = logging.getLogger(__name__)

evaluator = RulesEvaluator()


@asynccontextmanager
async def lifespan(app: FastAPI):
    task = asyncio.create_task(consume_loop())
    yield
    task.cancel()
    try: await task
    except asyncio.CancelledError: pass


app = FastAPI(title="sn-rules-engine", version="1.0.0", lifespan=lifespan)


@app.get("/health")
async def health():
    return {"service": "sn-rules-engine", "status": "healthy", "operators": 11}


async def consume_loop():
    rabbitmq_url = os.environ["RABBITMQ_URL"]
    while True:
        try:
            conn = await aio_pika.connect_robust(rabbitmq_url)
            async with conn:
                ch = await conn.channel()
                await ch.set_qos(prefetch_count=int(os.getenv("WORKER_CONCURRENCY", "4")))
                exchange = await ch.get_exchange("sn.events")
                queue = await ch.declare_queue("sn.rules.evaluate", durable=True, passive=True)
                async with queue.iterator() as q:
                    async for msg in q:
                        async with msg.process(requeue=True):
                            await handle(msg.body, exchange)
        except Exception as e:
            logger.error("Consumer error, retry in 5s: %s", e)
            await asyncio.sleep(5)


async def handle(body: bytes, exchange):
    try:
        payload = json.loads(body)
        run_id    = payload["run_id"]
        job_id    = payload["job_id"]
        tenant_id = payload["tenant_id"]
        criteria  = payload.get("job_config", {}).get("criteria", {"logic": "AND", "conditions": []})
        rows      = payload.get("rows", [])
        columns   = payload.get("columns", [])

        # Reconstruct DataFrame
        df = pd.DataFrame(rows, columns=columns) if rows else pd.DataFrame()

        result = evaluator.evaluate(df, criteria)

        # Serialise matched rows (limit columns for PII safety if needed)
        matched_rows = result.matched.to_dict(orient="records")

        event = {
            "event":       "rules.matched",
            "run_id":      run_id,
            "job_id":      job_id,
            "tenant_id":   tenant_id,
            "match_count": result.match_count,
            "total_count": result.total_count,
            "matched_rows": matched_rows,
            "evaluation_ms": result.evaluation_ms,
            "job_config":  payload.get("job_config", {}),
        }

        if result.match_count == 0:
            # Nothing matched — publish skipped event
            event["event"] = "rules.no_match"
            routing_key = "rules.no_match"
        else:
            routing_key = "rules.matched"

        await exchange.publish(
            aio_pika.Message(
                body=json.dumps(event).encode(),
                content_type="application/json",
                delivery_mode=aio_pika.DeliveryMode.PERSISTENT,
            ),
            routing_key=routing_key,
        )
        logger.info("run=%s matched=%d/%d", run_id, result.match_count, result.total_count)

    except Exception as exc:
        logger.error("Rule evaluation failed: %s", exc)
        raise


if __name__ == "__main__":
    uvicorn.run("src.main:app", host="0.0.0.0", port=int(os.getenv("PORT", "8004")))
