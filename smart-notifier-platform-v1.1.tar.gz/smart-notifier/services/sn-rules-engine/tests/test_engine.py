"""Unit tests for the vectorised rules engine — no AMQP, no DB required."""
import pytest
import pandas as pd
from src.engine import RulesEvaluator

@pytest.fixture
def evaluator():
    return RulesEvaluator()

@pytest.fixture
def ar_df():
    """Realistic AR ageing DataFrame matching our demo data."""
    return pd.DataFrame({
        "Account Description": ["Al Futtaim", "ADNOC", "Emaar", "Flydubai", "DP World"],
        "Days Past Due":       [45,           32,      0,       18,          0],
        "Amount Due":          [125000,       255000,  210000,  82000,       125000],
        "Ageing Bucket":       ["31-60 Days", "31-60 Days", "Current", "31-60 Days", "Current"],
        "Currency":            ["AED",        "USD",   "AED",   "AED",       "USD"],
    })


class TestGreaterThan:
    def test_matches_overdue_gt_30(self, evaluator, ar_df):
        criteria = {"logic": "AND", "conditions": [{"field": "Days Past Due", "op": "greater_than", "value": 30}]}
        result = evaluator.evaluate(ar_df, criteria)
        assert result.match_count == 2
        assert set(result.matched["Account Description"]) == {"Al Futtaim", "ADNOC"}

    def test_no_match_high_threshold(self, evaluator, ar_df):
        criteria = {"logic": "AND", "conditions": [{"field": "Days Past Due", "op": "greater_than", "value": 100}]}
        result = evaluator.evaluate(ar_df, criteria)
        assert result.match_count == 0

    def test_amount_threshold(self, evaluator, ar_df):
        criteria = {"logic": "AND", "conditions": [{"field": "Amount Due", "op": "greater_than", "value": 200000}]}
        result = evaluator.evaluate(ar_df, criteria)
        assert result.match_count == 2  # ADNOC + Emaar


class TestEquals:
    def test_match_ageing_bucket(self, evaluator, ar_df):
        criteria = {"logic": "AND", "conditions": [{"field": "Ageing Bucket", "op": "equals", "value": "Current"}]}
        result = evaluator.evaluate(ar_df, criteria)
        assert result.match_count == 2
        assert set(result.matched["Account Description"]) == {"Emaar", "DP World"}

    def test_days_zero(self, evaluator, ar_df):
        criteria = {"logic": "AND", "conditions": [{"field": "Days Past Due", "op": "equals", "value": 0}]}
        result = evaluator.evaluate(ar_df, criteria)
        assert result.match_count == 2


class TestAndLogic:
    def test_overdue_and_high_amount(self, evaluator, ar_df):
        criteria = {
            "logic": "AND",
            "conditions": [
                {"field": "Days Past Due", "op": "greater_than", "value": 30},
                {"field": "Amount Due",    "op": "greater_than", "value": 100000},
            ]
        }
        result = evaluator.evaluate(ar_df, criteria)
        assert result.match_count == 2  # Al Futtaim + ADNOC


class TestOrLogic:
    def test_current_or_high_amount(self, evaluator, ar_df):
        criteria = {
            "logic": "OR",
            "conditions": [
                {"field": "Ageing Bucket", "op": "equals", "value": "Current"},
                {"field": "Amount Due",    "op": "greater_than", "value": 200000},
            ]
        }
        result = evaluator.evaluate(ar_df, criteria)
        assert result.match_count == 3  # Emaar + DP World + ADNOC


class TestEdgeCases:
    def test_empty_dataframe(self, evaluator):
        df = pd.DataFrame(columns=["Days Past Due", "Amount Due"])
        criteria = {"logic": "AND", "conditions": [{"field": "Days Past Due", "op": "greater_than", "value": 30}]}
        result = evaluator.evaluate(df, criteria)
        assert result.match_count == 0
        assert result.total_count == 0

    def test_missing_field_returns_no_match(self, evaluator, ar_df):
        criteria = {"logic": "AND", "conditions": [{"field": "NONEXISTENT_FIELD", "op": "equals", "value": "x"}]}
        result = evaluator.evaluate(ar_df, criteria)
        assert result.match_count == 0

    def test_no_conditions_all_match(self, evaluator, ar_df):
        criteria = {"logic": "AND", "conditions": []}
        result = evaluator.evaluate(ar_df, criteria)
        assert result.match_count == len(ar_df)

    def test_contains_operator(self, evaluator, ar_df):
        criteria = {"logic": "AND", "conditions": [{"field": "Ageing Bucket", "op": "contains", "value": "Days"}]}
        result = evaluator.evaluate(ar_df, criteria)
        assert result.match_count == 3  # All "31-60 Days" rows

    def test_is_not_empty(self, evaluator):
        df = pd.DataFrame({"field": ["value", None, "", "another"]})
        criteria = {"logic": "AND", "conditions": [{"field": "field", "op": "is_not_empty", "value": None}]}
        result = evaluator.evaluate(df, criteria)
        assert result.match_count == 2
