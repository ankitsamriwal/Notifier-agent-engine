"""
Audit Service — DESC ISR 12.4 compliant append-only audit log.
Consumes ALL events from sn.audit.write queue (routing key: #).
Writes to audit_events table — immutable via DB trigger.
"""
import asyncio, json, logging, os, hashlib
from contextlib import asynccontextmanager
import uvicorn
from fastapi import FastAPI, Header, Query as QParam
from pydantic import BaseModel, Field
from typing import Any
import aio_pika
import asyncpg

logger = logging.getLogger(__name__)
DB_URL = os.environ.get("DATABASE_URL", "").replace("postgresql+asyncpg://", "postgresql://")


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.pool = await asyncpg.create_pool(DB_URL, min_size=2, max_size=10)
    task = asyncio.create_task(consume_loop(app.state.pool))
    yield
    task.cancel()
    try: await task
    except asyncio.CancelledError: pass
    await app.state.pool.close()


app = FastAPI(title="sn-audit-service", version="1.0.0", lifespan=lifespan)


@app.get("/health")
async def health():
    return {"service": "sn-audit-service", "status": "healthy"}


@app.get("/audit")
async def list_audit(
    x_tenant_id: str = Header(...),
    action: str | None = None,
    actor_id: str | None = None,
    limit: int = QParam(default=50, le=500),
    offset: int = 0,
):
    pool = app.state.pool
    conditions = ["($1::text IS NULL OR tenant_id = $1::uuid)"]
    params: list[Any] = [x_tenant_id]

    if action:
        conditions.append(f"action = ${len(params)+1}")
        params.append(action)
    if actor_id:
        conditions.append(f"actor_id = ${len(params)+1}")
        params.append(actor_id)

    where = " AND ".join(conditions)
    rows = await pool.fetch(
        f"SELECT * FROM audit_events WHERE {where} ORDER BY created_at DESC LIMIT ${len(params)+1} OFFSET ${len(params)+2}",
        *params, limit, offset
    )
    return {"data": [dict(r) for r in rows], "limit": limit, "offset": offset}


# ── AMQP consumer ─────────────────────────────────────────────────────────────

async def consume_loop(pool: asyncpg.Pool):
    rabbitmq_url = os.environ["RABBITMQ_URL"]
    while True:
        try:
            conn = await aio_pika.connect_robust(rabbitmq_url)
            async with conn:
                ch = await conn.channel()
                await ch.set_qos(prefetch_count=20)
                queue = await ch.declare_queue("sn.audit.write", durable=True, passive=True)
                async with queue.iterator() as q:
                    async for msg in q:
                        async with msg.process(requeue=False):  # audit: never requeue — accept all
                            await write_audit(pool, msg.body)
        except Exception as e:
            logger.error("Audit consumer error: %s", e)
            await asyncio.sleep(3)


def _hash_ip(ip: str | None) -> str | None:
    if not ip: return None
    return hashlib.sha256(ip.encode()).hexdigest()[:16]


async def write_audit(pool: asyncpg.Pool, body: bytes) -> None:
    try:
        payload = json.loads(body)
        event   = payload.get("event", "unknown")
        # Map event → action name
        action  = event if "." in event else f"system.{event}"
        await pool.execute(
            """INSERT INTO audit_events
               (tenant_id, actor_id, actor_ip_hash, action, resource_type,
                resource_id, outcome, details, correlation_id, service_name)
               VALUES ($1::uuid, $2, $3, $4, $5, $6, $7, $8, $9, $10)""",
            payload.get("tenant_id"),
            payload.get("actor_id", "system"),
            _hash_ip(payload.get("actor_ip")),
            action,
            payload.get("resource_type", event.split(".")[0] if "." in event else "system"),
            str(payload.get("resource_id") or payload.get("job_id") or payload.get("run_id") or ""),
            payload.get("outcome", "success"),
            json.dumps({k: v for k, v in payload.items()
                        if k not in ("tenant_id","actor_id","actor_ip","event","outcome")}),
            payload.get("correlation_id"),
            payload.get("service_name", "unknown"),
        )
    except Exception as e:
        logger.error("Audit write failed: %s | body=%s", e, body[:200])
        # Never raise — audit failures must not affect the pipeline

if __name__ == "__main__":
    logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
    uvicorn.run("src.main:app", host="0.0.0.0", port=int(os.getenv("PORT", "8009")))
