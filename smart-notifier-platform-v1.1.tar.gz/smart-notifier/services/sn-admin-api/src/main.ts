/**
 * Smart Notifier — Admin API (Backend-for-Frontend)
 * Aggregates dashboard data, tenant management, RBAC, cross-service calls.
 * Single endpoint that the Angular console calls — avoids N calls from browser.
 */
import Fastify from 'fastify'
import cors from '@fastify/cors'
import { Pool } from 'pg'
import Redis from 'ioredis'
import axios from 'axios'

const PORT = parseInt(process.env.PORT ?? '8011', 10)
const db   = new Pool({ connectionString: process.env.DATABASE_URL })
const redis = new Redis(process.env.REDIS_URL!, { maxRetriesPerRequest: 3 })

const SVC = {
  jobRegistry:      process.env.SN_JOB_REGISTRY_URL!,
  notificationLog:  process.env.SN_NOTIFICATION_LOG_URL!,
  effectiveness:    process.env.SN_EFFECTIVENESS_URL!,
  audit:            process.env.SN_AUDIT_SERVICE_URL!,
  connector:        process.env.SN_CONNECTOR_URL!,
}

const app = Fastify({ logger: { level: process.env.LOG_LEVEL ?? 'info' }, trustProxy: true })
await app.register(cors, { origin: '*' })

app.get('/health', async () => ({ service: 'sn-admin-api', status: 'healthy' }))

// ── Dashboard KPIs ────────────────────────────────────────────────────────

app.get('/dashboard', async (req) => {
  const tenantId = req.headers['x-tenant-id'] as string
  const cacheKey = `sn:dash:${tenantId}`

  // Try cache first (5-minute TTL)
  const cached = await redis.get(cacheKey)
  if (cached) return JSON.parse(cached)

  const now = new Date()
  const d30 = new Date(now.getTime() - 30 * 86400_000).toISOString()

  const [kpis, volume, tones] = await Promise.all([
    db.query(`
      SELECT
        COUNT(*) FILTER (WHERE status IN ('sent','draft_saved')) as total_sent,
        COUNT(*) FILTER (WHERE status = 'failed') as total_failed,
        COUNT(*) FILTER (WHERE status = 'skipped') as total_skipped,
        ROUND(COUNT(*) FILTER (WHERE status IN ('sent','draft_saved'))::numeric /
              NULLIF(COUNT(*),0) * 100, 1) as delivery_rate
      FROM notification_runs
      WHERE tenant_id = $1::uuid AND triggered_at >= $2::timestamptz`, [tenantId, d30]),

    db.query(`
      SELECT DATE(triggered_at AT TIME ZONE 'Asia/Dubai') as day,
             COUNT(*) FILTER (WHERE status IN ('sent','draft_saved')) as sent,
             COUNT(*) FILTER (WHERE status = 'failed') as failed
      FROM notification_runs
      WHERE tenant_id = $1::uuid AND triggered_at >= $2::timestamptz
      GROUP BY day ORDER BY day`, [tenantId, d30]),

    db.query(`
      SELECT j.tone, COUNT(r.run_id) as runs,
             COUNT(cs.signal_id) as cta_clicks
      FROM notification_runs r
      JOIN jobs j ON j.job_id = r.job_id
      LEFT JOIN cta_signals cs ON cs.run_id = r.run_id
      WHERE r.tenant_id = $1::uuid AND r.triggered_at >= $2::timestamptz
      GROUP BY j.tone ORDER BY runs DESC`, [tenantId, d30]),
  ])

  // CTA stats from effectiveness service
  let ctaStats = { response_rate: 0, outcome_rate: 0 }
  try {
    const eff = await axios.get(`${SVC.effectiveness}/effectiveness/summary`,
      { headers: { 'x-tenant-id': tenantId }, timeout: 3000 })
    const top = eff.data.top_performers?.[0]
    if (top) { ctaStats.response_rate = top.cta_pct; ctaStats.outcome_rate = top.outcome_pct }
  } catch {}

  const result = {
    kpis: { ...kpis.rows[0], ...ctaStats },
    volume_chart: volume.rows,
    tone_breakdown: tones.rows,
    computed_at: new Date().toISOString(),
  }

  await redis.setex(cacheKey, 300, JSON.stringify(result))
  return result
})

// ── Tenant management ─────────────────────────────────────────────────────

app.get('/tenants', async (req) => {
  const roles = (req.headers['x-roles'] as string ?? '').split(',')
  if (!roles.includes('super_admin')) return { error: 'forbidden', data: [] }
  const { rows } = await db.query('SELECT * FROM tenants ORDER BY created_at DESC')
  return { data: rows }
})

app.post('/tenants', async (req, reply) => {
  const roles = (req.headers['x-roles'] as string ?? '').split(',')
  if (!roles.includes('super_admin')) return reply.code(403).send({ error: 'forbidden' })
  const { name, slug, branding, llm_model } = req.body as any
  const { rows } = await db.query(
    `INSERT INTO tenants (name, slug, branding, llm_model)
     VALUES ($1, $2, $3, $4) RETURNING *`,
    [name, slug, branding ?? '{}', llm_model ?? 'claude-sonnet-4-20250514']
  )
  reply.code(201)
  return rows[0]
})

app.put('/tenants/:id', async (req, reply) => {
  const roles = (req.headers['x-roles'] as string ?? '').split(',')
  if (!roles.includes('super_admin')) return reply.code(403).send({ error: 'forbidden' })
  const { id } = req.params as { id: string }
  const { status, branding, enabled_channels, llm_model } = req.body as any
  const { rows } = await db.query(
    `UPDATE tenants SET
       status = COALESCE($1, status),
       branding = COALESCE($2::jsonb, branding),
       enabled_channels = COALESCE($3, enabled_channels),
       llm_model = COALESCE($4, llm_model),
       updated_at = NOW()
     WHERE tenant_id = $5::uuid RETURNING *`,
    [status, branding ? JSON.stringify(branding) : null, enabled_channels, llm_model, id]
  )
  if (!rows.length) return reply.code(404).send({ error: 'not_found' })
  return rows[0]
})

// ── Users & RBAC ──────────────────────────────────────────────────────────

app.get('/users', async (req) => {
  const tenantId = req.headers['x-tenant-id'] as string
  const { rows } = await db.query(
    `SELECT user_id, email, display_name, roles, mfa_enabled, status, created_at, last_login_at
     FROM users WHERE tenant_id = $1::uuid ORDER BY created_at DESC`, [tenantId]
  )
  return { data: rows }
})

app.put('/users/:userId/roles', async (req, reply) => {
  const { userId } = req.params as { userId: string }
  const tenantId   = req.headers['x-tenant-id'] as string
  const roles      = (req.headers['x-roles'] as string ?? '').split(',')
  if (!roles.some(r => ['super_admin','tenant_admin'].includes(r))) {
    return reply.code(403).send({ error: 'forbidden' })
  }
  const { new_roles } = req.body as { new_roles: string[] }
  const { rows } = await db.query(
    `UPDATE users SET roles = $1 WHERE user_id = $2::uuid AND tenant_id = $3::uuid RETURNING *`,
    [new_roles, userId, tenantId]
  )
  if (!rows.length) return reply.code(404).send({ error: 'not_found' })
  return rows[0]
})

// ── Connector types (pass-through with cache) ─────────────────────────────

app.get('/connector-types', async () => {
  const cacheKey = 'sn:connector_types'
  const cached = await redis.get(cacheKey)
  if (cached) return JSON.parse(cached)
  try {
    const r = await axios.get(`${SVC.connector}/connectors/types`, { timeout: 3000 })
    await redis.setex(cacheKey, 3600, JSON.stringify(r.data))
    return r.data
  } catch {
    return { types: ['file_upload','sharepoint','google_drive','d365_fo','custom_rest'] }
  }
})

// ── Channel health summary ────────────────────────────────────────────────

app.get('/channels/health', async (req) => {
  const tenantId = req.headers['x-tenant-id'] as string
  const { rows } = await db.query(`
    SELECT channel,
           COUNT(*) FILTER (WHERE triggered_at >= NOW() - INTERVAL '24h') as runs_24h,
           COUNT(*) FILTER (WHERE status='sent' AND triggered_at >= NOW() - INTERVAL '24h') as sent_24h,
           COUNT(*) FILTER (WHERE status='failed' AND triggered_at >= NOW() - INTERVAL '24h') as failed_24h,
           MAX(triggered_at) as last_run
    FROM notification_runs
    WHERE tenant_id = $1::uuid
    GROUP BY channel`, [tenantId]
  )
  return { data: rows }
})

await app.listen({ port: PORT, host: '0.0.0.0' })
app.log.info(`sn-admin-api on :${PORT}`)
