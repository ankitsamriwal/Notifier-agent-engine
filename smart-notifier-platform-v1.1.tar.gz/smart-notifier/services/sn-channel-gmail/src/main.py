"""
Gmail Channel Adapter Worker
Consumes: sn.channel.gmail (routing key: dispatch.gmail)
Publishes: delivery.sent / delivery.failed → sn.events
"""
import asyncio, json, logging, os
from contextlib import asynccontextmanager
import uvicorn
from fastapi import FastAPI
import aio_pika
from .adapter import GmailAdapter

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    task = asyncio.create_task(consume_loop())
    yield
    task.cancel()
    try: await task
    except asyncio.CancelledError: pass


app = FastAPI(title="sn-channel-gmail", version="1.0.0", lifespan=lifespan)

@app.get("/health")
async def health():
    return {"service": "sn-channel-gmail", "status": "healthy", "channel": "gmail"}


async def consume_loop():
    url = os.environ["RABBITMQ_URL"]
    while True:
        try:
            conn = await aio_pika.connect_robust(url)
            async with conn:
                ch = await conn.channel()
                await ch.set_qos(prefetch_count=int(os.getenv("WORKER_CONCURRENCY", "2")))
                exchange = await ch.get_exchange("sn.events")
                queue = await ch.declare_queue("sn.channel.gmail", durable=True, passive=True)
                async with queue.iterator() as q:
                    async for msg in q:
                        async with msg.process(requeue=True):
                            await handle(msg.body, exchange)
        except Exception as e:
            logger.error("Gmail consumer error, retry 5s: %s", e)
            await asyncio.sleep(5)


async def handle(body: bytes, exchange):
    payload     = json.loads(body)
    run_id      = payload["run_id"]
    job_id      = payload["job_id"]
    tenant_id   = payload["tenant_id"]
    approval_mode = payload.get("job_config", {}).get("approval_mode", "manual")
    message     = payload.get("message", {})

    adapter = GmailAdapter(tenant_id)

    if approval_mode == "draft":
        result = await adapter.draft(message)
        routing_key = "delivery.draft_saved"
    else:
        result = await adapter.send(message)
        routing_key = "delivery.sent" if result.get("status") == "sent" else "delivery.failed"

    event = {
        "event":      routing_key.split(".")[-1],
        "run_id":     run_id,
        "job_id":     job_id,
        "tenant_id":  tenant_id,
        "channel":    "gmail",
        "delivery_id": result.get("delivery_id"),
        "draft_id":   result.get("draft_id"),
        "status":     result.get("status"),
        "error":      result.get("error"),
    }
    await exchange.publish(
        aio_pika.Message(body=json.dumps(event).encode(), content_type="application/json",
                         delivery_mode=aio_pika.DeliveryMode.PERSISTENT),
        routing_key=routing_key,
    )
    logger.info("Gmail dispatch complete: run=%s status=%s", run_id, result.get("status"))


if __name__ == "__main__":
    uvicorn.run("src.main:app", host="0.0.0.0", port=8007)
