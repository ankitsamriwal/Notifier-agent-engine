"""Shared channel adapter base — mirrors the ChannelAdapter ABC from the PRD."""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field


@dataclass
class Attachment:
    name: str
    content: bytes
    mime_type: str


@dataclass
class CtaButton:
    label: str
    key: str
    url: str


@dataclass
class Message:
    run_id: str
    job_id: str
    tenant_id: str
    to: list[str]
    cc: list[str]
    subject: str
    html_body: str
    text_body: str
    bcc: list[str] = field(default_factory=list)
    attachments: list[Attachment] = field(default_factory=list)
    cta_buttons: list[CtaButton] = field(default_factory=list)


@dataclass
class DeliveryResult:
    delivery_id: str
    status: str           # sent | queued | failed
    provider_ref: str | None = None
    error: str | None = None


@dataclass
class DraftResult:
    draft_id: str
    provider_ref: str | None = None
    preview_url: str | None = None


class ChannelAdapter(ABC):
    @classmethod
    @abstractmethod
    def channel_type(cls) -> str: ...

    @abstractmethod
    async def send(self, message: Message) -> DeliveryResult: ...

    @abstractmethod
    async def draft(self, message: Message) -> DraftResult: ...

    @abstractmethod
    async def status(self, delivery_id: str) -> str: ...
