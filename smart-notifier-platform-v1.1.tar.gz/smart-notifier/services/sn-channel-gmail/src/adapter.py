"""
Gmail Channel Adapter — SourceConnector pattern applied to delivery.
Implements ChannelAdapter ABC: send(), draft(), status()
Credentials from Vault at: secret/channels/gmail/{tenant_id}
"""
from __future__ import annotations
import base64, json, logging, os
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from typing import Any

from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

logger = logging.getLogger(__name__)


class GmailAdapter:
    """
    Gmail delivery adapter.
    Credential flow: OAuth2 refresh token stored in Vault → exchanged at runtime.
    Supports: send (immediate), draft (save to Gmail drafts), status (check delivery).
    """

    def __init__(self, tenant_id: str):
        self._tenant_id  = tenant_id
        self._service    = None

    async def _get_service(self):
        if self._service:
            return self._service
        creds_json = await self._load_credentials()
        creds = Credentials(
            token=creds_json.get("access_token"),
            refresh_token=creds_json.get("refresh_token"),
            token_uri="https://oauth2.googleapis.com/token",
            client_id=creds_json["client_id"],
            client_secret=creds_json["client_secret"],
            scopes=["https://www.googleapis.com/auth/gmail.send",
                    "https://www.googleapis.com/auth/gmail.compose"],
        )
        if creds.expired and creds.refresh_token:
            creds.refresh(Request())
        self._service = build("gmail", "v1", credentials=creds, cache_discovery=False)
        return self._service

    async def _load_credentials(self) -> dict[str, Any]:
        """Load OAuth2 credentials from Vault."""
        from ...secrets.vault import VaultSecretStore
        store = VaultSecretStore()
        path = f"channels/gmail/{self._tenant_id}"
        return await store.get_json(path)

    def _build_message(self, to: str, cc: str, subject: str,
                       html_body: str, text_body: str) -> dict:
        """Build Gmail API message from email components."""
        msg = MIMEMultipart("alternative")
        msg["to"]      = to
        msg["cc"]      = cc
        msg["subject"] = subject
        msg.attach(MIMEText(text_body, "plain", "utf-8"))
        msg.attach(MIMEText(html_body, "html",  "utf-8"))
        raw = base64.urlsafe_b64encode(msg.as_bytes()).decode()
        return {"raw": raw}

    async def send(self, message: dict[str, Any]) -> dict[str, Any]:
        """Send email immediately via Gmail API."""
        svc = await self._get_service()
        api_msg = self._build_message(
            to=message["to"],
            cc=message.get("cc", ""),
            subject=message["subject"],
            html_body=message["html_body"],
            text_body=message["text_body"],
        )
        try:
            sent = svc.users().messages().send(userId="me", body=api_msg).execute()
            logger.info("Gmail sent: messageId=%s to=%s", sent["id"], message["to"])
            return {"delivery_id": sent["id"], "status": "sent", "provider": "gmail"}
        except HttpError as exc:
            logger.error("Gmail send failed: %s", exc)
            return {"status": "failed", "error": str(exc)}

    async def draft(self, message: dict[str, Any]) -> dict[str, Any]:
        """Save email as Gmail draft (approval mode = draft)."""
        svc = await self._get_service()
        api_msg = self._build_message(
            to=message["to"],
            cc=message.get("cc", ""),
            subject=message["subject"],
            html_body=message["html_body"],
            text_body=message["text_body"],
        )
        try:
            draft = svc.users().drafts().create(userId="me", body={"message": api_msg}).execute()
            draft_id = draft["id"]
            logger.info("Gmail draft saved: draftId=%s to=%s", draft_id, message["to"])
            return {
                "draft_id":   draft_id,
                "status":     "draft_saved",
                "provider":   "gmail",
                "preview_url": f"https://mail.google.com/mail/u/0/#drafts?compose={draft_id}",
            }
        except HttpError as exc:
            logger.error("Gmail draft failed: %s", exc)
            return {"status": "failed", "error": str(exc)}

    async def status(self, delivery_id: str) -> str:
        """Check delivery status of a sent message."""
        svc = await self._get_service()
        try:
            msg = svc.users().messages().get(userId="me", id=delivery_id, format="minimal").execute()
            labels = msg.get("labelIds", [])
            if "SENT" in labels:
                return "sent"
            return "unknown"
        except HttpError:
            return "not_found"
