import json, os
import hvac

class VaultSecretStore:
    def __init__(self):
        self._client = hvac.Client(url=os.environ.get("VAULT_ADDR","http://vault:8200"),
                                   token=os.environ.get("VAULT_TOKEN",""))
    async def get(self, path: str) -> str:
        r = self._client.secrets.kv.v2.read_secret_version(path=path, mount_point="secret")
        data = r["data"]["data"]
        return next(iter(data.values())) if len(data)==1 else json.dumps(data)
    async def get_json(self, path: str) -> dict:
        raw = await self.get(path)
        return json.loads(raw) if isinstance(raw,str) else raw
    async def set(self, path: str, data: dict) -> None:
        self._client.secrets.kv.v2.create_or_update_secret(path=path, secret=data, mount_point="secret")
