/**
 * Smart Notifier — Notification Log Service
 * Stores and serves the full run history for every notification job.
 * Consumes: delivery.sent, delivery.failed, delivery.draft_saved, rules.no_match
 */
import Fastify from 'fastify'
import cors from '@fastify/cors'
import amqplib from 'amqplib'
import { Pool } from 'pg'

const PORT = parseInt(process.env.PORT ?? '8012', 10)
const db   = new Pool({ connectionString: process.env.DATABASE_URL })
let amqpCh: amqplib.Channel

const app = Fastify({ logger: { level: process.env.LOG_LEVEL ?? 'info' }, trustProxy: true })
await app.register(cors, { origin: '*' })

app.get('/health', async () => ({ service: 'sn-notification-log', status: 'healthy' }))

// GET /runs — paginated run list for tenant
app.get('/runs', async (req) => {
  const tenantId = req.headers['x-tenant-id'] as string
  const { status, job_id, channel, limit = '50', offset = '0' } = req.query as Record<string, string>

  const conditions: string[] = ['tenant_id = $1::uuid']
  const params: (string|number)[] = [tenantId]

  if (status)  { conditions.push(`status = $${params.length+1}`);  params.push(status)  }
  if (job_id)  { conditions.push(`job_id = $${params.length+1}::uuid`); params.push(job_id)  }
  if (channel) { conditions.push(`channel = $${params.length+1}`); params.push(channel) }

  const where = conditions.join(' AND ')
  const { rows } = await db.query(
    `SELECT run_id, job_id, tenant_id, trigger_type, status, match_count,
            channel, recipient_to, recipient_cc, delivery_id, draft_id,
            error_message, triggered_at, dispatched_at, completed_at
     FROM notification_runs
     WHERE ${where}
     ORDER BY triggered_at DESC
     LIMIT $${params.length+1} OFFSET $${params.length+2}`,
    [...params, parseInt(limit), parseInt(offset)]
  )

  const { rows: countRows } = await db.query(
    `SELECT COUNT(*) as total FROM notification_runs WHERE ${where}`, params
  )

  return { data: rows, total: parseInt(countRows[0].total), limit: parseInt(limit), offset: parseInt(offset) }
})

// GET /runs/:runId — full run detail
app.get('/runs/:runId', async (req, reply) => {
  const { runId }   = req.params as { runId: string }
  const tenantId    = req.headers['x-tenant-id'] as string
  const { rows }    = await db.query(
    'SELECT * FROM notification_runs WHERE run_id = $1::uuid AND tenant_id = $2::uuid',
    [runId, tenantId]
  )
  if (!rows.length) return reply.code(404).send({ error: 'not_found' })
  return rows[0]
})

// ── AMQP consumer ─────────────────────────────────────────────────────────

async function startConsumer() {
  const conn = await amqplib.connect(process.env.RABBITMQ_URL!)
  amqpCh = await conn.createChannel()
  await amqpCh.assertExchange('sn.events', 'topic', { durable: true })
  const q = await amqpCh.assertQueue('sn.notification.log', { durable: true })

  // Bind all delivery-result events
  for (const key of ['delivery.sent','delivery.failed','delivery.draft_saved','rules.no_match','job.triggered']) {
    await amqpCh.bindQueue(q.queue, 'sn.events', key)
  }

  amqpCh.prefetch(10)
  amqpCh.consume(q.queue, async (msg) => {
    if (!msg) return
    try {
      await handleEvent(JSON.parse(msg.content.toString()))
      amqpCh.ack(msg)
    } catch (e) {
      amqpCh.nack(msg, false, false)
    }
  })
}

async function handleEvent(payload: Record<string, any>) {
  const event     = payload.event as string
  const runId     = payload.run_id
  const tenantId  = payload.tenant_id
  const jobId     = payload.job_id

  if (event === 'job.triggered') {
    // Create initial run record
    await db.query(`
      INSERT INTO notification_runs
        (run_id, job_id, tenant_id, trigger_type, status, channel, triggered_at)
      VALUES ($1::uuid, $2::uuid, $3::uuid, $4, 'triggered', $5, NOW())
      ON CONFLICT (run_id) DO NOTHING`,
      [runId, jobId, tenantId, payload.trigger_type ?? 'manual', payload.channel ?? 'unknown']
    )
    return
  }

  // Map event → status
  const statusMap: Record<string, string> = {
    'delivery.sent':         'sent',
    'delivery.failed':       'failed',
    'delivery.draft_saved':  'draft_saved',
    'rules.no_match':        'skipped',
  }
  const newStatus = statusMap[event] ?? 'unknown'

  await db.query(`
    UPDATE notification_runs
    SET status       = $1,
        delivery_id  = COALESCE($2, delivery_id),
        draft_id     = COALESCE($3, draft_id),
        match_count  = COALESCE($4, match_count),
        error_message= COALESCE($5, error_message),
        completed_at = NOW()
    WHERE run_id = $6::uuid AND tenant_id = $7::uuid`,
    [
      newStatus,
      payload.delivery_id ?? null,
      payload.draft_id    ?? null,
      payload.match_count ?? null,
      payload.error       ?? null,
      runId, tenantId,
    ]
  )
}

await startConsumer()
await app.listen({ port: PORT, host: '0.0.0.0' })
app.log.info(`sn-notification-log on :${PORT}`)
