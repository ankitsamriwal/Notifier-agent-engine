"""
AI Service AMQP consumer.
Listens: sn.ai.compose (routing key: rules.matched)
Publishes: email.composed → sn.events
"""
import asyncio, json, logging
import aio_pika
import pandas as pd
from ..pii.redactor import PIIRedactor
from ..composition.composer import NotificationComposer

logger = logging.getLogger(__name__)
redactor  = PIIRedactor()
composer  = NotificationComposer()


class AIServiceConsumer:
    def __init__(self, rabbitmq_url: str):
        self._url = rabbitmq_url

    async def start(self):
        while True:
            try:
                await self._consume()
            except Exception as e:
                logger.error("Consumer error, retry 5s: %s", e)
                await asyncio.sleep(5)

    async def _consume(self):
        conn = await aio_pika.connect_robust(self._url)
        async with conn:
            ch = await conn.channel()
            await ch.set_qos(prefetch_count=2)
            exchange = await ch.get_exchange("sn.events")
            queue = await ch.declare_queue("sn.ai.compose", durable=True, passive=True)
            async with queue.iterator() as q:
                async for msg in q:
                    async with msg.process(requeue=True):
                        await self._handle(msg.body, exchange)

    async def _handle(self, body: bytes, exchange):
        try:
            payload    = json.loads(body)
            run_id     = payload["run_id"]
            job_id     = payload["job_id"]
            tenant_id  = payload["tenant_id"]
            job_config = payload.get("job_config", {})
            rows       = payload.get("matched_rows", [])
            columns    = list(rows[0].keys()) if rows else []

            logger.info("Composing email for run=%s match_count=%d", run_id, len(rows))

            # 1. PII redaction before LLM
            if rows:
                df = pd.DataFrame(rows)
                df_redacted, pii_result = redactor.redact_dataframe(df)
                rows_clean = df_redacted.to_dict(orient="records")
                pii_fields = pii_result.redacted_fields
            else:
                rows_clean = []
                pii_fields = []

            # 2. Compose via LLM
            email = await composer.compose(
                job_config=job_config,
                matched_rows=rows_clean,
                schema_fields=columns,
                pii_redacted_fields=pii_fields,
            )

            # 3. Publish email.composed event
            event = {
                "event":      "email.composed",
                "run_id":     run_id,
                "job_id":     job_id,
                "tenant_id":  tenant_id,
                "job_config": job_config,
                "matched_rows": rows,        # original (non-redacted) rows for email table
                "match_count":  len(rows),
                "composed": {
                    "subject":     email.subject,
                    "html_body":   email.html_body,
                    "text_body":   email.text_body,
                    "cta_buttons": email.cta_buttons,
                },
                "pii_redacted_fields": pii_fields,
            }

            # Route to approval gate (always — approval_mode decides draft/send/auto)
            await exchange.publish(
                aio_pika.Message(
                    body=json.dumps(event).encode(),
                    content_type="application/json",
                    delivery_mode=aio_pika.DeliveryMode.PERSISTENT,
                ),
                routing_key="email.composed",
            )
            logger.info("Published email.composed for run=%s", run_id)

        except Exception as exc:
            logger.error("AI compose failed run=%s: %s", payload.get("run_id"), exc)
            raise
