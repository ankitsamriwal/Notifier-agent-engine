"""
AI Compose Service — drafts notification emails using Claude/Ollama.
PII is redacted before prompt construction.
LLM output validated via Pydantic before entering the pipeline.
"""
from __future__ import annotations
import json, logging, os
from typing import Any
import anthropic
from pydantic import BaseModel, field_validator

logger = logging.getLogger(__name__)


class ComposedEmail(BaseModel):
    subject: str
    html_body: str
    text_body: str
    cta_buttons: list[dict[str, str]]

    @field_validator("subject")
    @classmethod
    def subject_not_empty(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("Subject cannot be empty")
        return v.strip()

    @field_validator("html_body")
    @classmethod
    def html_not_empty(cls, v: str) -> str:
        if len(v.strip()) < 50:
            raise ValueError("HTML body too short")
        return v

    @field_validator("cta_buttons")
    @classmethod
    def cta_valid(cls, v: list[dict]) -> list[dict]:
        for btn in v:
            if "label" not in btn or "key" not in btn:
                raise ValueError("CTA button must have label and key")
        return v


_TONE_GUIDE = {
    "Professional": "Clear, business-appropriate, respectful. Action-oriented.",
    "Urgent":       "URGENT framing. Immediate action required. Consequences of inaction mentioned.",
    "Friendly":     "Warm, approachable. Use first names. Soften the ask.",
    "Formal":       "Formal language, full titles, passive voice acceptable. No contractions.",
    "Firm":         "Direct, no ambiguity. Clear deadline. No softening language.",
    "Concise":      "3 sentences max body. One clear action. No filler.",
}

_CTA_TEMPLATES = {
    "finance_ar":      [{"label": "Payment made",     "key": "payment_made"},
                        {"label": "Pay by Friday",    "key": "pay_by_friday"},
                        {"label": "Query raised",     "key": "query_raised"},
                        {"label": "Escalate",         "key": "escalate"},
                        {"label": "Dispute",          "key": "dispute"}],
    "finance_ap":      [{"label": "Approved to pay",  "key": "approved_pay"},
                        {"label": "On hold",          "key": "on_hold"},
                        {"label": "Query to vendor",  "key": "query_vendor"}],
    "compliance":      [{"label": "Renewal started",  "key": "renewal_started"},
                        {"label": "Already renewed",  "key": "already_renewed"},
                        {"label": "Extension needed", "key": "extension_needed"},
                        {"label": "Escalate",         "key": "escalate"}],
    "hr":              [{"label": "Acknowledged",     "key": "acknowledged"},
                        {"label": "HR contacted",     "key": "hr_contacted"},
                        {"label": "Action taken",     "key": "action_taken"}],
    "default":         [{"label": "Action taken",     "key": "action_taken"},
                        {"label": "Not applicable",   "key": "not_applicable"},
                        {"label": "Escalate",         "key": "escalate"}],
}


class NotificationComposer:
    def __init__(self):
        self._client = anthropic.Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY", ""))
        self._model  = os.environ.get("LLM_MODEL", "claude-sonnet-4-20250514")
        self._backend = os.environ.get("LLM_BACKEND", "anthropic")

    async def compose(
        self,
        job_config: dict[str, Any],
        matched_rows: list[dict],
        schema_fields: list[str],
        pii_redacted_fields: list[str],
    ) -> ComposedEmail:
        tone      = job_config.get("tone", "Professional")
        channel   = job_config.get("channel", "email")
        subject_t = job_config.get("template", {}).get("subject", "")
        body_hint = job_config.get("template", {}).get("body_hint", "")
        job_name  = job_config.get("name", "Notification")

        # Determine CTA template from job type
        cta_type = self._infer_cta_type(job_name, job_config.get("criteria", {}))
        cta_buttons = _CTA_TEMPLATES.get(cta_type, _CTA_TEMPLATES["default"])

        # Build table summary (max 10 rows for prompt)
        table_summary = self._build_table_summary(matched_rows[:10], schema_fields)

        prompt = self._build_prompt(
            tone=tone,
            subject_template=subject_t,
            body_hint=body_hint,
            table_summary=table_summary,
            match_count=len(matched_rows),
            cta_buttons=cta_buttons,
            pii_note=f"Fields redacted for privacy: {pii_redacted_fields}" if pii_redacted_fields else "",
        )

        raw = await self._call_llm(prompt)
        return self._parse_response(raw, subject_t, matched_rows, cta_buttons)

    def _infer_cta_type(self, job_name: str, criteria: dict) -> str:
        name_lower = job_name.lower()
        if any(w in name_lower for w in ["ar", "receivable", "overdue", "invoice", "payment"]):
            return "finance_ar"
        if any(w in name_lower for w in ["ap", "payable", "vendor", "supplier"]):
            return "finance_ap"
        if any(w in name_lower for w in ["compliance", "licence", "visa", "expir", "renewal"]):
            return "compliance"
        if any(w in name_lower for w in ["hr", "employee", "contract", "probation"]):
            return "hr"
        return "default"

    def _build_table_summary(self, rows: list[dict], fields: list[str]) -> str:
        if not rows:
            return "(no matched rows)"
        header = " | ".join(str(f) for f in fields[:8])  # max 8 columns
        lines  = [header, "-" * len(header)]
        for row in rows[:10]:
            line = " | ".join(str(row.get(f, ""))[:30] for f in fields[:8])
            lines.append(line)
        return "\n".join(lines)

    def _build_prompt(self, **ctx) -> str:
        tone_guide = _TONE_GUIDE.get(ctx["tone"], _TONE_GUIDE["Professional"])
        cta_labels = ", ".join(b["label"] for b in ctx["cta_buttons"])
        return f"""You are a Finance Notification Agent for an enterprise platform.
Draft a notification email with these specifications:

Tone: {ctx["tone"]} — {tone_guide}
Subject template: {ctx["subject_template"]}
Body instruction: {ctx["body_hint"]}
Matched records: {ctx["match_count"]}
{ctx["pii_note"]}

Data summary (redacted sample):
{ctx["table_summary"]}

CTA buttons available: {cta_labels}

Respond with ONLY valid JSON in this exact schema:
{{
  "subject": "...",
  "html_body": "<html>..full email body with inline CSS, no external resources..</html>",
  "text_body": "..plain text fallback..",
  "cta_buttons": [{{"label": "...", "key": "..."}}]
}}

Rules:
- html_body must be complete self-contained HTML with inline CSS only
- Subject must populate {{match_count}} and {{today}} placeholders if present
- Include the data table in html_body as an HTML table with the matched records
- CTA buttons: only include relevant ones from the available list
- No markdown in JSON values
- UAE business context (AED/USD, Dubai timezone references)"""

    async def _call_llm(self, prompt: str) -> str:
        if self._backend == "anthropic":
            msg = self._client.messages.create(
                model=self._model,
                max_tokens=4096,
                messages=[{"role": "user", "content": prompt}],
            )
            return msg.content[0].text
        elif self._backend == "ollama":
            import httpx
            ollama_url = os.environ.get("OLLAMA_URL", "http://ollama:11434")
            async with httpx.AsyncClient(timeout=120) as client:
                resp = await client.post(
                    f"{ollama_url}/api/generate",
                    json={"model": os.environ.get("LLM_MODEL", "llama3.1"), "prompt": prompt, "stream": False},
                )
                resp.raise_for_status()
                return resp.json()["response"]
        else:
            raise ValueError(f"Unknown LLM backend: {self._backend}")

    def _parse_response(
        self, raw: str, subject_template: str,
        matched_rows: list[dict], cta_buttons: list[dict]
    ) -> ComposedEmail:
        # Strip markdown code fences if present
        clean = raw.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
        try:
            data = json.loads(clean)
            # Substitute subject placeholders
            subject = data.get("subject", subject_template)
            subject = subject.replace("{{match_count}}", str(len(matched_rows)))
            import datetime
            subject = subject.replace("{{today}}", datetime.date.today().strftime("%d %b %Y"))
            data["subject"] = subject
            return ComposedEmail(**data)
        except Exception as exc:
            logger.error("LLM output parse failed: %s\nRaw: %.500s", exc, raw)
            # Fallback: minimal valid email
            return ComposedEmail(
                subject=subject_template or "Notification",
                html_body=f"<html><body><p>Notification — {len(matched_rows)} records matched.</p></body></html>",
                text_body=f"Notification — {len(matched_rows)} records matched.",
                cta_buttons=cta_buttons[:3],
            )
