"""Smart Notifier AI Service — schema analysis, email composition, insights."""
import asyncio, logging, os
from contextlib import asynccontextmanager
import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .events.consumer import AIServiceConsumer

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    consumer = AIServiceConsumer(os.environ["RABBITMQ_URL"])
    task = asyncio.create_task(consumer.start())
    logger.info("sn-ai-service started")
    yield
    task.cancel()
    try: await task
    except asyncio.CancelledError: pass


app = FastAPI(title="sn-ai-service", version="1.0.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


@app.get("/health")
async def health():
    return {
        "service": "sn-ai-service", "status": "healthy",
        "llm_backend": os.getenv("LLM_BACKEND", "anthropic"),
        "model": os.getenv("LLM_MODEL", "claude-sonnet-4-20250514"),
        "pii_redaction": os.getenv("PII_REDACTION_ENABLED", "true"),
    }


@app.post("/analyse")
async def analyse_schema(body: dict):
    """HTTP endpoint for on-demand schema analysis (from job studio UI)."""
    from .pii.redactor import PIIRedactor
    from .composition.composer import NotificationComposer
    import pandas as pd

    redact = PIIRedactor()
    composer = NotificationComposer()

    rows = body.get("sample_rows", [])
    schema = body.get("schema", {})
    user_hint = body.get("hint", "")

    # Redact sample rows
    if rows:
        df = pd.DataFrame(rows)
        df_clean, pii_res = redact.redact_dataframe(df)
        rows_clean = df_clean.to_dict(orient="records")
    else:
        rows_clean, pii_res = [], None

    # Build analysis prompt
    import anthropic, json
    client = anthropic.Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY", ""))
    model  = os.environ.get("LLM_MODEL", "claude-sonnet-4-20250514")

    prompt = f"""Analyse this enterprise data schema and suggest notification jobs.
Schema fields: {list(schema.keys()) if schema else 'unknown'}
Sample (redacted): {json.dumps(rows_clean[:5], default=str)}
User hint: {user_hint}

Respond with JSON only:
{{
  "analysis": "2-3 sentence description of what this data contains",
  "suggested_jobs": [
    {{
      "name": "...", "description": "...", "tone": "Professional|Urgent|...",
      "channel": "gmail|outlook", "schedule": "Daily at 08:00",
      "criteria": [{{"field": "...", "op": "greater_than", "value": 30}}],
      "subject": "...", "body_hint": "..."
    }}
  ]
}}"""

    msg = client.messages.create(model=model, max_tokens=1500, messages=[{"role":"user","content":prompt}])
    raw = msg.content[0].text.strip().removeprefix("```json").removesuffix("```").strip()

    try:
        result = json.loads(raw)
    except Exception:
        result = {"analysis": raw, "suggested_jobs": []}

    return result


if __name__ == "__main__":
    uvicorn.run("src.main:app", host="0.0.0.0", port=int(os.getenv("PORT", "8005")))
