"""PII Redactor — DESC/NESA: no PII sent to external LLM providers."""
from __future__ import annotations
import re, logging
from dataclasses import dataclass, field
from typing import Any
import pandas as pd

logger = logging.getLogger(__name__)

_PATTERNS: dict[str, re.Pattern] = {
    "email":       re.compile(r'\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b'),
    "phone_uae":   re.compile(r'\b(?:\+971|00971)?[- ]?(?:0)?(?:50|51|52|54|55|56|58|2|3|4|6|7|9)\d{7}\b'),
    "emirates_id": re.compile(r'\b784-?\d{4}-?\d{7}-?\d\b'),
    "passport":    re.compile(r'\b[A-Z]{1,2}\d{6,9}\b'),
    "iban":        re.compile(r'\bAE\d{2}[0-9A-Z]{3,30}\b'),
    "credit_card": re.compile(r'\b(?:4\d{12}(?:\d{3})?|5[1-5]\d{14}|3[47]\d{13})\b'),
}

@dataclass
class RedactionResult:
    redacted_fields: list[str] = field(default_factory=list)
    total_values_redacted: int = 0
    def had_pii(self) -> bool:
        return bool(self.redacted_fields)

class PIIRedactor:
    def redact_dataframe(self, df: pd.DataFrame) -> tuple[pd.DataFrame, RedactionResult]:
        result = RedactionResult()
        redacted = df.copy()
        for col in redacted.select_dtypes(include="object").columns:
            mask = redacted[col].astype(str).apply(self._has_pii)
            if mask.any():
                result.redacted_fields.append(col)
                result.total_values_redacted += int(mask.sum())
                redacted.loc[mask, col] = redacted.loc[mask, col].astype(str).apply(self._redact)
        return redacted, result

    def _has_pii(self, v: str) -> bool:
        return any(p.search(v) for p in _PATTERNS.values())

    def _redact(self, v: str) -> str:
        for name, p in _PATTERNS.items():
            v = p.sub(f"[REDACTED_{name.upper()}]", v)
        return v

    def redact_dict(self, d: dict[str, Any]) -> tuple[dict[str, Any], list[str]]:
        keys: list[str] = []
        out: dict[str, Any] = {}
        for k, v in d.items():
            if isinstance(v, str) and self._has_pii(v):
                out[k] = self._redact(v); keys.append(k)
            elif isinstance(v, dict):
                out[k], sub = self.redact_dict(v); keys.extend(f"{k}.{s}" for s in sub)
            else:
                out[k] = v
        return out, keys
