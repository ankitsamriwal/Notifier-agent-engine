"""
AI Email Composer — uses Claude to draft notification emails.
Inputs: job config, tone, matched rows (PII-redacted sample), body instruction.
Outputs: subject, html_body, text_body, cta_buttons (validated via Pydantic).
"""
import json
import logging
import os
import time
from typing import Any

import anthropic
from pydantic import BaseModel, Field, validator

logger = logging.getLogger(__name__)


# ── Output schema (validated) ────────────────────────────────────────────────

class CTAButton(BaseModel):
    label: str = Field(..., min_length=1, max_length=50)
    key: str = Field(..., min_length=1, max_length=50)   # URL-safe key


class ComposedEmail(BaseModel):
    subject: str = Field(..., min_length=1, max_length=500)
    html_body: str = Field(..., min_length=10)
    text_body: str = Field(..., min_length=10)
    cta_buttons: list[CTAButton] = Field(default_factory=list, max_items=6)
    tone_applied: str
    pii_fields_redacted: list[str] = Field(default_factory=list)

    @validator("subject")
    def subject_no_injection(cls, v: str) -> str:
        # Basic prompt injection guard on subject line
        dangerous = ["ignore previous", "disregard", "system:", "assistant:"]
        lower = v.lower()
        for d in dangerous:
            if d in lower:
                raise ValueError(f"Subject contains suspicious content: {d}")
        return v


# ── Prompt templates ──────────────────────────────────────────────────────────

COMPOSE_SYSTEM = """You are Smart Notifier's AI composition engine for enterprise finance and compliance notifications.
Your role is to draft professional, accurate notification emails based on the provided configuration.

Rules you MUST follow:
1. Draft the email exactly matching the requested tone (Urgent/Professional/Formal/Friendly/Firm/Concise)
2. Use {{field_name}} syntax for dynamic values from matched data rows
3. Never invent data values — use only what is provided in matched_rows_sample
4. CTA buttons must be actionable and appropriate to the job domain
5. HTML body must be valid, clean, inline-styled HTML suitable for email clients
6. Text body must be a plain-text version of the HTML body
7. Respond ONLY with a valid JSON object matching the specified schema — no prose, no markdown fences

Output schema:
{
  "subject": "string — email subject, may use {{COLUMN_NAME}} placeholders",
  "html_body": "string — complete HTML email body with inline CSS",
  "text_body": "string — plain text version",
  "cta_buttons": [{"label": "string max 50 chars", "key": "snake_case_key"}],
  "tone_applied": "string — name of tone used"
}"""


class EmailComposer:
    """Composes email content using the configured LLM backend."""

    def __init__(self, settings: Any):
        self._settings = settings
        self._client = self._build_client()

    def _build_client(self):
        backend = self._settings.llm_backend
        if backend == "anthropic":
            return anthropic.AsyncAnthropic(api_key=self._settings.anthropic_api_key)
        elif backend == "ollama":
            # Ollama-compatible client for on-prem/air-gapped deployments
            return anthropic.AsyncAnthropic(
                api_key="ollama",
                base_url=f"{self._settings.ollama_url}/v1",
            )
        else:
            raise ValueError(f"Unsupported LLM backend: {backend}")

    async def compose(
        self,
        job_config: dict,
        matched_rows_sample: list[dict],
        pii_fields_redacted: list[str],
        schema_fields: list[str],
    ) -> ComposedEmail:
        """Draft a full notification email. PII already redacted from matched_rows_sample."""
        t0 = time.monotonic()

        tone         = job_config.get("tone", "Professional")
        body_hint    = job_config.get("template", {}).get("body_hint", "")
        subject_tmpl = job_config.get("template", {}).get("subject", "")
        channel      = job_config.get("channel", "gmail")
        job_name     = job_config.get("name", "Notification")
        domain       = self._infer_domain(job_config)

        user_prompt = f"""Compose a {tone} tone notification email for this job:

Job name: {job_name}
Domain: {domain}
Channel: {channel}
Subject template: {subject_tmpl or "(generate from context)"}
Body instruction: {body_hint or "(professional notification based on matched data)"}

Available column fields: {json.dumps(schema_fields)}
Matched data sample ({len(matched_rows_sample)} rows — PII redacted if present):
{json.dumps(matched_rows_sample[:5], indent=2)}

PII fields redacted before this call: {json.dumps(pii_fields_redacted)}

Generate appropriate CTA buttons for domain '{domain}'.
For Finance/AR: Payment confirmed, Will pay by [date], Query raised, Escalate, Dispute
For Compliance: Action taken, Renewal started, Extension requested, Not applicable
For HR: Acknowledged, Renewal initiated, Extension required
For Operations: Resolved, In progress, Escalate

HTML must use inline styles only (no <style> tags — email client compatibility).
Include a professional footer with: job name, run timestamp placeholder {{RUN_DATE}}, source system."""

        response = await self._client.messages.create(
            model=self._settings.llm_model,
            max_tokens=1500,
            system=COMPOSE_SYSTEM,
            messages=[{"role": "user", "content": user_prompt}],
        )

        raw = response.content[0].text.strip()

        # Strip markdown fences if model added them despite instructions
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
            raw = raw.strip()

        parsed = json.loads(raw)
        email = ComposedEmail(
            **parsed,
            pii_fields_redacted=pii_fields_redacted,
        )

        elapsed = int((time.monotonic() - t0) * 1000)
        logger.info("Email composed in %dms (tone=%s, cta_count=%d)", elapsed, tone, len(email.cta_buttons))
        return email

    async def generate_job_suggestions(
        self,
        schema_fields: list[str],
        sample_rows: list[dict],
        connector_name: str,
    ) -> list[dict]:
        """Auto-generate notification job configs from a data schema."""
        system = """You are Smart Notifier's job configuration AI.
Analyse the data schema and suggest notification jobs.
Respond ONLY with a JSON array of job configs. No prose. No markdown.

Each job: {"name","description","tone","channel","criteria":[{"field","op","value"}],"subject","body_hint","schedule"}"""

        user = f"""Data source: {connector_name}
Fields: {json.dumps(schema_fields)}
Sample (5 rows, PII redacted): {json.dumps(sample_rows[:5], indent=2)}

Suggest 3 notification jobs appropriate for this data.
Use realistic UAE finance/compliance context (AED, Dubai, GST).
Tone options: Professional | Urgent | Formal | Friendly | Firm | Concise
Channel: gmail or outlook
Schedule: "Daily at 08:00" | "Weekly on Monday 07:00" | "Monthly on 1st 08:00"
Ops: greater_than | less_than | equals | contains | is_not_empty | date_before | date_after"""

        response = await self._client.messages.create(
            model=self._settings.llm_model,
            max_tokens=1200,
            system=system,
            messages=[{"role": "user", "content": user}],
        )

        raw = response.content[0].text.strip()
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
            raw = raw.strip()

        return json.loads(raw)

    async def generate_insights(
        self,
        effectiveness_data: dict,
        tenant_name: str,
    ) -> list[dict]:
        """Generate weekly AI insights from effectiveness metrics."""
        system = """You are Smart Notifier's analytics AI.
Analyse notification effectiveness data and generate actionable insights.
Respond ONLY with a JSON array. No prose. No markdown.

Each insight: {"type":"recommendation|anomaly|suggestion","severity":"info|warning|high","title","body","confidence":"high|medium|low"}"""

        user = f"""Tenant: {tenant_name}
Effectiveness data: {json.dumps(effectiveness_data, indent=2)}

Generate 3–5 specific, actionable insights about:
- Best performing day/time combinations
- Tone effectiveness patterns
- Channel performance comparison  
- Month-position patterns
- Frequency recommendations
Be specific with numbers from the data."""

        response = await self._client.messages.create(
            model=self._settings.llm_model,
            max_tokens=1000,
            system=system,
            messages=[{"role": "user", "content": user}],
        )

        raw = response.content[0].text.strip()
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
            raw = raw.strip()

        return json.loads(raw)

    def _infer_domain(self, job_config: dict) -> str:
        """Infer business domain from job name and criteria for CTA selection."""
        name = (job_config.get("name", "") + " " + job_config.get("description", "")).lower()
        if any(w in name for w in ["ar ", "ap ", "invoice", "overdue", "payment", "ageing"]):
            return "Finance/AR-AP"
        if any(w in name for w in ["licence", "visa", "expir", "compliance", "renew"]):
            return "Compliance"
        if any(w in name for w in ["contract", "probation", "hr ", "employee", "training"]):
            return "HR"
        if any(w in name for w in ["po ", "procurement", "sla", "supplier", "vendor"]):
            return "Operations"
        return "General"
