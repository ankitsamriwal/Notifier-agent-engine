"""
PII Redactor — scans DataFrames and prompt strings for PII before LLM calls.
DESC/NESA compliance: no PII must reach external LLM APIs.
Detected fields are replaced with typed placeholders, never stripped silently.
"""
import re
import logging
import hashlib
from typing import Any
import pandas as pd

logger = logging.getLogger(__name__)

# ── PII detection patterns ────────────────────────────────────────────────────
_PATTERNS: dict[str, re.Pattern] = {
    "EMAIL":       re.compile(r'\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b'),
    "PHONE_UAE":   re.compile(r'\b(?:\+971|00971|0)(?:2|3|4|6|7|8|9|50|51|52|54|55|56|58)\d{7}\b'),
    "PHONE_INTL":  re.compile(r'\+\d{1,3}[\s\-]?\(?\d{1,4}\)?[\s\-]?\d{3,4}[\s\-]?\d{3,4}'),
    "EMIRATES_ID": re.compile(r'\b784-\d{4}-\d{7}-\d{1}\b|\b784\d{12}\b'),
    "PASSPORT":    re.compile(r'\b[A-Z]{1,2}\d{6,9}\b'),
    "IBAN":        re.compile(r'\bAE\d{2}[0-9A-Z]{16,22}\b', re.IGNORECASE),
    "CREDIT_CARD": re.compile(r'\b(?:\d{4}[\s\-]?){3}\d{4}\b'),
    "IPV4":        re.compile(r'\b(?:\d{1,3}\.){3}\d{1,3}\b'),
    "FULL_NAME_ARABIC": re.compile(r'[\u0600-\u06FF]{2,}(?:\s+[\u0600-\u06FF]{2,}){1,3}'),
}

# Column names that strongly suggest PII content
_PII_COLUMN_HINTS = {
    "email", "email_id", "email id", "e-mail",
    "phone", "mobile", "contact", "telephone",
    "emirates id", "emiratesid", "eid",
    "passport", "passport no", "passport number",
    "iban", "bank account", "account number",
    "address", "full name", "first name", "last name",
    "national id", "civil id",
}


class PIIRedactionResult:
    __slots__ = ("redacted_value", "pii_types_found", "was_redacted")

    def __init__(self, redacted_value: str, pii_types_found: list[str]):
        self.redacted_value = redacted_value
        self.pii_types_found = pii_types_found
        self.was_redacted = bool(pii_types_found)


class PIIRedactor:
    """
    Redacts PII from strings and DataFrames before LLM calls.
    Replacement format: [REDACTED_EMAIL], [REDACTED_PHONE_UAE], etc.
    """

    def redact_string(self, text: str) -> PIIRedactionResult:
        """Scan and redact PII from a string."""
        if not text:
            return PIIRedactionResult(text, [])

        result = text
        found: list[str] = []

        for pii_type, pattern in _PATTERNS.items():
            if pattern.search(result):
                result = pattern.sub(f"[REDACTED_{pii_type}]", result)
                found.append(pii_type)

        return PIIRedactionResult(result, found)

    def redact_dataframe_sample(
        self,
        df: pd.DataFrame,
        sample_rows: int = 10,
    ) -> tuple[pd.DataFrame, list[str]]:
        """
        Redact PII from a sample DataFrame before sending to LLM.
        Returns: (redacted_sample_df, list_of_pii_types_found)
        """
        sample = df.head(sample_rows).copy()
        all_found: list[str] = []

        for col in sample.columns:
            col_lower = col.lower().strip()

            # Check column name hint
            is_pii_col = any(hint in col_lower for hint in _PII_COLUMN_HINTS)

            if is_pii_col:
                # Redact entire column
                sample[col] = f"[REDACTED_{col.upper().replace(' ', '_')}]"
                all_found.append(col)
                continue

            # Scan string columns for PII patterns
            if sample[col].dtype == object:
                redacted_vals = []
                for val in sample[col]:
                    if val is None:
                        redacted_vals.append(None)
                        continue
                    r = self.redact_string(str(val))
                    redacted_vals.append(r.redacted_value)
                    all_found.extend(r.pii_types_found)
                sample[col] = redacted_vals

        unique_found = list(set(all_found))
        if unique_found:
            logger.info("PII redacted from sample: %s", unique_found)

        return sample, unique_found

    def hash_pii(self, value: str) -> str:
        """SHA-256 hash of a PII value for audit/tracking without storing the value."""
        return hashlib.sha256(value.encode("utf-8")).hexdigest()[:16]
