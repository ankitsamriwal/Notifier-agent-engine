from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
    port: int = 8005
    log_level: str = "INFO"
    database_url: str = ""
    rabbitmq_url: str = ""
    anthropic_api_key: str = ""
    llm_backend: str = "anthropic"
    llm_model: str = "claude-sonnet-4-20250514"
    ollama_url: str = "http://ollama:11434"
    pii_redaction_enabled: bool = True
    prompt_log_ttl_days: int = 30
    otel_exporter_otlp_endpoint: str = "http://otel-collector:4317"
