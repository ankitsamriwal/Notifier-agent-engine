from fastapi import APIRouter
from ..connectors.registry import list_types

router = APIRouter()

@router.get("/health")
async def health():
    return {
        "service": "sn-connector",
        "version": "1.0.0",
        "status": "healthy",
        "registered_connectors": list_types(),
    }
