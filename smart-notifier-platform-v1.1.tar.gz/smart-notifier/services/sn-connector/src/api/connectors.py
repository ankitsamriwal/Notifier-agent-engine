"""Connector CRUD + fetch + schema API endpoints."""
import uuid
from fastapi import APIRouter, HTTPException, Header, UploadFile, File
from pydantic import BaseModel
from typing import Any
from ..connectors.registry import get_or_raise, list_types
from ..connectors.base import ConnectorConfig, DataQuery

router = APIRouter()


class ConnectorCreateRequest(BaseModel):
    name: str
    connector_type: str
    config: dict[str, Any] = {}
    credential_ref: str | None = None


class FetchRequest(BaseModel):
    preview_rows: int | None = None


@router.get("/types")
async def list_connector_types():
    return {"types": list_types()}


@router.post("/")
async def create_connector(
    body: ConnectorCreateRequest,
    x_tenant_id: str = Header(...),
):
    """Register connector metadata in DB (config only, credentials via Vault)."""
    get_or_raise(body.connector_type)  # Validate type exists
    connector_id = str(uuid.uuid4())
    # TODO: persist to DB via ConnectorRepository
    return {
        "connector_id": connector_id,
        "tenant_id": x_tenant_id,
        "name": body.name,
        "connector_type": body.connector_type,
        "status": "active",
    }


@router.post("/{connector_id}/fetch")
async def fetch_data(
    connector_id: str,
    body: FetchRequest,
    x_tenant_id: str = Header(...),
):
    """Fetch and normalise data from a registered connector."""
    # TODO: load connector config from DB
    # For now, return schema of how response looks
    return {
        "connector_id": connector_id,
        "row_count": 0,
        "columns": [],
        "rows": [],
        "message": "Connector fetch — implement after DB repository layer",
    }


@router.get("/{connector_id}/schema")
async def get_schema(
    connector_id: str,
    x_tenant_id: str = Header(...),
):
    return {
        "connector_id": connector_id,
        "fields": [],
        "row_count_estimate": 0,
    }


@router.post("/upload")
async def upload_file(
    file: UploadFile = File(...),
    x_tenant_id: str = Header(...),
):
    """Upload a file to MinIO and return a connector config stub."""
    if not file.filename:
        raise HTTPException(400, "Filename required")

    allowed = {".xlsx", ".xls", ".csv", ".tsv", ".pdf", ".docx"}
    suffix = "." + file.filename.rsplit(".", 1)[-1].lower()
    if suffix not in allowed:
        raise HTTPException(400, f"File type not supported: {suffix}")

    content = await file.read()
    size_mb = len(content) / 1024 / 1024
    if size_mb > 25:
        raise HTTPException(413, "File exceeds 25 MB limit")

    bucket = "sn-uploads"
    key = f"{x_tenant_id}/{uuid.uuid4()}/{file.filename}"

    # TODO: upload to MinIO via storage abstraction
    return {
        "bucket": bucket,
        "key": key,
        "filename": file.filename,
        "size_bytes": len(content),
        "config": {"bucket": bucket, "key": key},
        "connector_type": "file_upload",
    }
