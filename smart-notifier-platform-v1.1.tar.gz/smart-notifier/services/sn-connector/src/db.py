"""Async SQLAlchemy session with RLS tenant context injection."""
from contextlib import asynccontextmanager
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy import text

_engine = None
_session_factory = None


async def init_db(database_url: str) -> None:
    global _engine, _session_factory
    _engine = create_async_engine(
        database_url,
        pool_size=10,
        max_overflow=20,
        pool_pre_ping=True,
        echo=False,
    )
    _session_factory = async_sessionmaker(_engine, expire_on_commit=False)


@asynccontextmanager
async def get_session(tenant_id: str | None = None, role: str = "app"):
    """Yield a session with RLS context set."""
    async with _session_factory() as session:
        if tenant_id:
            await session.execute(
                text("SET LOCAL app.tenant_id = :tid"), {"tid": tenant_id}
            )
        if role == "super_admin":
            await session.execute(text("SET LOCAL app.role = 'super_admin'"))
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
