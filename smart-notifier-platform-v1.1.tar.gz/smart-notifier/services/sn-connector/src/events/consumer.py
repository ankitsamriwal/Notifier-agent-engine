"""
RabbitMQ event consumer for sn-connector.
Listens on: sn.data.fetch (routing key: job.triggered)
Publishes: data.fetched → sn.events exchange
"""
import asyncio, json, logging
import aio_pika
from aio_pika.abc import AbstractIncomingMessage

logger = logging.getLogger(__name__)


class ConnectorEventConsumer:
    def __init__(self, settings):
        self._settings = settings

    async def start(self):
        while True:
            try:
                await self._consume()
            except Exception as exc:
                logger.error("Consumer error, reconnecting in 5s: %s", exc)
                await asyncio.sleep(5)

    async def _consume(self):
        conn = await aio_pika.connect_robust(self._settings.rabbitmq_url)
        async with conn:
            channel = await conn.channel()
            await channel.set_qos(prefetch_count=4)

            queue = await channel.declare_queue("sn.data.fetch", durable=True, passive=True)
            exchange = await channel.get_exchange("sn.events")

            async with queue.iterator() as q:
                async for message in q:
                    async with message.process(requeue=True):
                        await self._handle(message, exchange)

    async def _handle(self, message: AbstractIncomingMessage, exchange):
        try:
            payload = json.loads(message.body)
            job_id    = payload["job_id"]
            run_id    = payload["run_id"]
            tenant_id = payload["tenant_id"]
            connector_id = payload["connector_id"]

            logger.info("Fetching data for job=%s run=%s", job_id, run_id)

            # TODO: load connector config from DB, run connector.fetch()
            # Publish data.fetched event with DataFrame serialised to JSON
            result = {
                "event": "data.fetched",
                "run_id": run_id,
                "job_id": job_id,
                "tenant_id": tenant_id,
                "connector_id": connector_id,
                "row_count": 0,
                "columns": [],
                "rows": [],
                "status": "ok",
            }

            await exchange.publish(
                aio_pika.Message(
                    body=json.dumps(result).encode(),
                    content_type="application/json",
                    delivery_mode=aio_pika.DeliveryMode.PERSISTENT,
                ),
                routing_key="data.fetched",
            )
            logger.info("Published data.fetched for run=%s", run_id)

        except Exception as exc:
            logger.error("Failed to process job.triggered: %s", exc)
            raise
