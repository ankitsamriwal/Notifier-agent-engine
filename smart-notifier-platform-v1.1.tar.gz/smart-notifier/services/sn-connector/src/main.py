"""
Smart Notifier — Connector Service
FastAPI service: plugin registry, schema inference, data fetch, normalisation
"""
import asyncio
import logging
from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor

from .config import Settings
from .api import connectors, health
from .events.consumer import ConnectorEventConsumer
from .db import init_db
from .telemetry import init_telemetry

logger = logging.getLogger(__name__)
settings = Settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup / shutdown lifecycle."""
    init_telemetry(settings.otel_exporter_otlp_endpoint, "sn-connector")
    await init_db(settings.database_url)

    # Start AMQP event consumer in background
    consumer = ConnectorEventConsumer(settings)
    consumer_task = asyncio.create_task(consumer.start())
    logger.info("sn-connector started — listening for events")

    yield

    consumer_task.cancel()
    try:
        await consumer_task
    except asyncio.CancelledError:
        pass
    logger.info("sn-connector shutdown complete")


app = FastAPI(
    title="Smart Notifier — Connector Service",
    version="1.0.0",
    description="Pluggable data source connector registry",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url=None,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Gateway enforces auth; CORS is permissive internally
    allow_methods=["*"],
    allow_headers=["*"],
)

FastAPIInstrumentor.instrument_app(app)

app.include_router(health.router, tags=["health"])
app.include_router(connectors.router, prefix="/connectors", tags=["connectors"])

if __name__ == "__main__":
    uvicorn.run(
        "src.main:app",
        host="0.0.0.0",
        port=settings.port,
        reload=False,
        log_level=settings.log_level.lower(),
        access_log=True,
    )
