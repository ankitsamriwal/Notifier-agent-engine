"""
HashiCorp Vault secret store — implements SecretStore interface.
Credential values are NEVER logged or stored in PostgreSQL.
"""
import json, logging, os
import hvac
from typing import Any

logger = logging.getLogger(__name__)


class VaultSecretStore:
    def __init__(self):
        self._client = hvac.Client(
            url=os.environ.get("VAULT_ADDR", "http://vault:8200"),
            token=os.environ.get("VAULT_TOKEN", ""),
        )

    async def get(self, path: str) -> str:
        """Read a single secret value from Vault KV v2."""
        try:
            response = self._client.secrets.kv.v2.read_secret_version(
                path=path, mount_point="secret"
            )
            data = response["data"]["data"]
            if len(data) == 1:
                return next(iter(data.values()))
            return json.dumps(data)
        except Exception as exc:
            logger.error("Vault read failed for path '%s': %s", path, exc)
            raise

    async def get_json(self, path: str) -> dict[str, Any]:
        """Read and parse a JSON secret from Vault."""
        raw = await self.get(path)
        if isinstance(raw, str):
            return json.loads(raw)
        return raw

    async def set(self, path: str, data: dict[str, Any]) -> None:
        """Write a secret to Vault KV v2."""
        self._client.secrets.kv.v2.create_or_update_secret(
            path=path, secret=data, mount_point="secret"
        )

    async def delete(self, path: str) -> None:
        """Soft-delete a secret (Vault destroys all versions)."""
        self._client.secrets.kv.v2.delete_metadata_and_all_versions(
            path=path, mount_point="secret"
        )
