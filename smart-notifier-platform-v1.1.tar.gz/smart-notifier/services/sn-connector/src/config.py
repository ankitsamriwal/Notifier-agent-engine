from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    port: int = 8001
    log_level: str = "INFO"

    database_url: str = Field(..., description="PostgreSQL asyncpg DSN")
    rabbitmq_url: str = Field(..., description="AMQP URL")

    # MinIO / object storage
    minio_endpoint: str = "minio:9000"
    minio_access_key: str = "sn_minio"
    minio_secret_key: str = "changeme"
    minio_secure: bool = False
    storage_backend: str = "minio"  # minio | s3 | azure | gcs

    # Vault
    vault_addr: str = "http://vault:8200"
    vault_token: str = "sn-dev-root-token"
    secret_backend: str = "vault"   # vault | aws_sm | azure_kv | gcp_sm

    # OTel
    otel_exporter_otlp_endpoint: str = "http://otel-collector:4317"

    # Limits
    max_upload_mb: int = 25
    schema_cache_ttl_seconds: int = 3600
