"""
File Upload Connector — XLSX, CSV, PDF, DOCX from MinIO bucket.
Registered as connector_type = 'file_upload'.
"""
import io
import logging
import time
from typing import Any

import pandas as pd
from minio import Minio

from .base import (
    ConnectorConfig, ConnectorFetchError, DataQuery,
    HealthStatus, SchemaDefinition, SchemaField, SourceConnector,
)
from .registry import register

logger = logging.getLogger(__name__)

_TYPE_MAP = {
    "object": "string",
    "int64": "number", "int32": "number", "float64": "number", "float32": "number",
    "datetime64[ns]": "date", "datetime64[ns, UTC]": "date",
    "bool": "boolean",
}


@register
class FileUploadConnector(SourceConnector):
    """Reads uploaded files (XLSX, CSV, PDF-tabulated) from MinIO."""

    def __init__(self, minio_endpoint: str, access_key: str, secret_key: str, secure: bool = False):
        self._minio = Minio(minio_endpoint, access_key=access_key, secret_key=secret_key, secure=secure)

    @classmethod
    def connector_type(cls) -> str:
        return "file_upload"

    async def authenticate(self, cfg: ConnectorConfig) -> bool:
        try:
            bucket = cfg.config.get("bucket", "sn-uploads")
            return self._minio.bucket_exists(bucket)
        except Exception as exc:
            logger.warning("FileUpload auth failed: %s", exc)
            return False

    async def fetch(self, cfg: ConnectorConfig, query: DataQuery) -> pd.DataFrame:
        bucket = cfg.config.get("bucket", "sn-uploads")
        key = cfg.config.get("key", "")
        if not key:
            raise ConnectorFetchError(self.connector_type(), "config.key is required")

        try:
            resp = self._minio.get_object(bucket, key)
            data = resp.read()
        except Exception as exc:
            raise ConnectorFetchError(self.connector_type(), f"MinIO get failed: {exc}") from exc

        df = self._parse(key, data)

        if query.preview_rows:
            df = df.head(query.preview_rows)

        return self._normalise(df)

    async def schema(self, cfg: ConnectorConfig) -> SchemaDefinition:
        # Fetch 5 rows for schema inference — minimal data transfer
        preview_query = DataQuery(connector_id=cfg.connector_id, preview_rows=5)
        df = await self.fetch(cfg, preview_query)
        fields = []
        for col in df.columns:
            dtype_str = str(df[col].dtype)
            data_type = _TYPE_MAP.get(dtype_str, "string")
            sample = str(df[col].iloc[0]) if len(df) > 0 else None
            fields.append(SchemaField(
                name=col,
                data_type=data_type,
                nullable=bool(df[col].isna().any()),
                sample=sample,
            ))
        return SchemaDefinition(
            fields=fields,
            row_count_estimate=len(df),
            source_name=cfg.config.get("key", ""),
        )

    async def health_check(self, cfg: ConnectorConfig) -> HealthStatus:
        t0 = time.monotonic()
        ok = await self.authenticate(cfg)
        latency = int((time.monotonic() - t0) * 1000)
        return HealthStatus(
            healthy=ok,
            message="MinIO reachable" if ok else "Cannot reach MinIO bucket",
            latency_ms=latency,
        )

    def _parse(self, key: str, data: bytes) -> pd.DataFrame:
        key_lower = key.lower()
        if key_lower.endswith(".xlsx") or key_lower.endswith(".xls"):
            return pd.read_excel(io.BytesIO(data), engine="openpyxl")
        elif key_lower.endswith(".csv"):
            return pd.read_csv(io.BytesIO(data))
        elif key_lower.endswith(".tsv"):
            return pd.read_csv(io.BytesIO(data), sep="\t")
        else:
            raise ConnectorFetchError(
                self.connector_type(),
                f"Unsupported file type: {key}. Supported: xlsx, xls, csv, tsv"
            )

    def _normalise(self, df: pd.DataFrame) -> pd.DataFrame:
        """Ensure all columns are JSON-serialisable."""
        for col in df.columns:
            # Convert datetime to ISO string
            if pd.api.types.is_datetime64_any_dtype(df[col]):
                df[col] = df[col].dt.strftime("%Y-%m-%dT%H:%M:%S").where(df[col].notna(), None)
            # Convert numeric NaN to None
            elif pd.api.types.is_numeric_dtype(df[col]):
                df[col] = df[col].where(df[col].notna(), None)
        return df
