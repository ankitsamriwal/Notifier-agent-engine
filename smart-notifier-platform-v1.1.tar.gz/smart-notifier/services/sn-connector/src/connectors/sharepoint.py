"""
SharePoint Online Connector — reads files from SharePoint document libraries
via Microsoft Graph API. Credentials stored in Vault.
"""
import io, logging, time
import pandas as pd
import httpx
import msal

from .base import (
    ConnectorConfig, ConnectorFetchError, DataQuery,
    HealthStatus, SchemaDefinition, SchemaField, SourceConnector,
)
from .registry import register

logger = logging.getLogger(__name__)

_TYPE_MAP = {
    "object": "string", "int64": "number", "float64": "number",
    "datetime64[ns]": "date", "bool": "boolean",
}


@register
class SharePointConnector(SourceConnector):
    """
    Reads XLSX/CSV files from SharePoint Online via MS Graph API.
    config keys: site_url, library_path, file_path
    credential_ref → Vault path containing: client_id, client_secret, tenant_id
    """

    @classmethod
    def connector_type(cls) -> str:
        return "sharepoint"

    async def authenticate(self, cfg: ConnectorConfig) -> bool:
        try:
            token = await self._get_token(cfg)
            return bool(token)
        except Exception as exc:
            logger.warning("SharePoint auth failed: %s", exc)
            return False

    async def fetch(self, cfg: ConnectorConfig, query: DataQuery) -> pd.DataFrame:
        token = await self._get_token(cfg)
        file_content = await self._download_file(cfg, token)
        df = self._parse(cfg.config.get("file_path", ""), file_content)
        if query.preview_rows:
            df = df.head(query.preview_rows)
        return self._normalise(df)

    async def schema(self, cfg: ConnectorConfig) -> SchemaDefinition:
        preview = DataQuery(connector_id=cfg.connector_id, preview_rows=5)
        df = await self.fetch(cfg, preview)
        fields = [
            SchemaField(
                name=col,
                data_type=_TYPE_MAP.get(str(df[col].dtype), "string"),
                nullable=bool(df[col].isna().any()),
                sample=str(df[col].iloc[0]) if len(df) > 0 else None,
            )
            for col in df.columns
        ]
        return SchemaDefinition(fields=fields, row_count_estimate=len(df),
                                source_name=cfg.config.get("file_path", ""))

    async def health_check(self, cfg: ConnectorConfig) -> HealthStatus:
        t0 = time.monotonic()
        ok = await self.authenticate(cfg)
        return HealthStatus(
            healthy=ok,
            message="Graph API token acquired" if ok else "Auth failed",
            latency_ms=int((time.monotonic() - t0) * 1000),
        )

    async def _get_token(self, cfg: ConnectorConfig) -> str:
        """Acquire MSAL token using client credentials from Vault."""
        from ..secrets.vault import VaultSecretStore
        store = VaultSecretStore()
        creds = await store.get_json(cfg.credential_ref or "")
        authority = f"https://login.microsoftonline.com/{creds['tenant_id']}"
        app = msal.ConfidentialClientApplication(
            creds["client_id"],
            authority=authority,
            client_credential=creds["client_secret"],
        )
        result = app.acquire_token_for_client(
            scopes=["https://graph.microsoft.com/.default"]
        )
        if "access_token" not in result:
            raise ConnectorFetchError(
                self.connector_type(),
                f"MSAL token failed: {result.get('error_description', 'unknown')}"
            )
        return result["access_token"]

    async def _download_file(self, cfg: ConnectorConfig, token: str) -> bytes:
        """Download file bytes via Graph API drive item."""
        site_url: str = cfg.config.get("site_url", "")
        file_path: str = cfg.config.get("file_path", "")

        # Resolve site ID
        hostname = site_url.split("/")[2]
        site_relative = "/".join(site_url.split("/")[3:])
        graph_base = "https://graph.microsoft.com/v1.0"

        async with httpx.AsyncClient(timeout=30) as client:
            headers = {"Authorization": f"Bearer {token}"}

            # Get site ID
            site_resp = await client.get(
                f"{graph_base}/sites/{hostname}:/{site_relative}",
                headers=headers,
            )
            site_resp.raise_for_status()
            site_id = site_resp.json()["id"]

            # Download file content
            dl_resp = await client.get(
                f"{graph_base}/sites/{site_id}/drive/root:/{file_path}:/content",
                headers=headers,
                follow_redirects=True,
            )
            dl_resp.raise_for_status()
            return dl_resp.content

    def _parse(self, file_path: str, data: bytes) -> pd.DataFrame:
        if file_path.lower().endswith((".xlsx", ".xls")):
            return pd.read_excel(io.BytesIO(data), engine="openpyxl")
        elif file_path.lower().endswith(".csv"):
            return pd.read_csv(io.BytesIO(data))
        raise ConnectorFetchError(self.connector_type(), f"Unsupported: {file_path}")

    def _normalise(self, df: pd.DataFrame) -> pd.DataFrame:
        for col in df.columns:
            if pd.api.types.is_datetime64_any_dtype(df[col]):
                df[col] = df[col].dt.strftime("%Y-%m-%dT%H:%M:%S").where(df[col].notna(), None)
            elif pd.api.types.is_numeric_dtype(df[col]):
                df[col] = df[col].where(df[col].notna(), None)
        return df
