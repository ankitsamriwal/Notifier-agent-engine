"""
Google Drive Connector — reads XLSX/CSV from Google Drive folders via Drive API.
"""
import io, logging, time
import pandas as pd
import httpx

from .base import (
    ConnectorConfig, ConnectorFetchError, DataQuery,
    HealthStatus, SchemaDefinition, SchemaField, SourceConnector,
)
from .registry import register

logger = logging.getLogger(__name__)


@register
class GoogleDriveConnector(SourceConnector):
    """
    config keys: file_id (Drive file ID) OR folder_id + filename
    credential_ref → Vault path: service_account_json (base64)
    """

    @classmethod
    def connector_type(cls) -> str:
        return "google_drive"

    async def authenticate(self, cfg: ConnectorConfig) -> bool:
        try:
            await self._get_token(cfg)
            return True
        except Exception as exc:
            logger.warning("GDrive auth failed: %s", exc)
            return False

    async def fetch(self, cfg: ConnectorConfig, query: DataQuery) -> pd.DataFrame:
        token = await self._get_token(cfg)
        file_id = await self._resolve_file_id(cfg, token)
        data = await self._download(file_id, token)
        filename = cfg.config.get("filename", cfg.config.get("file_id", "file.xlsx"))
        df = self._parse(filename, data)
        if query.preview_rows:
            df = df.head(query.preview_rows)
        return self._normalise(df)

    async def schema(self, cfg: ConnectorConfig) -> SchemaDefinition:
        df = await self.fetch(cfg, DataQuery(connector_id=cfg.connector_id, preview_rows=5))
        fields = [
            SchemaField(name=c, data_type="string", nullable=True,
                        sample=str(df[c].iloc[0]) if len(df) > 0 else None)
            for c in df.columns
        ]
        return SchemaDefinition(fields=fields, row_count_estimate=len(df))

    async def health_check(self, cfg: ConnectorConfig) -> HealthStatus:
        t0 = time.monotonic()
        ok = await self.authenticate(cfg)
        return HealthStatus(healthy=ok, latency_ms=int((time.monotonic() - t0) * 1000))

    async def _get_token(self, cfg: ConnectorConfig) -> str:
        import base64, json
        from google.oauth2 import service_account
        from google.auth.transport.requests import Request as GRequest

        from ..secrets.vault import VaultSecretStore
        store = VaultSecretStore()
        sa_b64 = await store.get(cfg.credential_ref or "")
        sa_json = json.loads(base64.b64decode(sa_b64))
        creds = service_account.Credentials.from_service_account_info(
            sa_json, scopes=["https://www.googleapis.com/auth/drive.readonly"]
        )
        creds.refresh(GRequest())
        return creds.token

    async def _resolve_file_id(self, cfg: ConnectorConfig, token: str) -> str:
        if "file_id" in cfg.config:
            return cfg.config["file_id"]
        folder_id = cfg.config.get("folder_id", "root")
        filename = cfg.config["filename"]
        async with httpx.AsyncClient() as client:
            r = await client.get(
                "https://www.googleapis.com/drive/v3/files",
                params={"q": f"'{folder_id}' in parents and name='{filename}'",
                        "fields": "files(id,name)"},
                headers={"Authorization": f"Bearer {token}"},
            )
            r.raise_for_status()
            files = r.json().get("files", [])
            if not files:
                raise ConnectorFetchError(self.connector_type(), f"File '{filename}' not found")
            return files[0]["id"]

    async def _download(self, file_id: str, token: str) -> bytes:
        async with httpx.AsyncClient(follow_redirects=True) as client:
            r = await client.get(
                f"https://www.googleapis.com/drive/v3/files/{file_id}?alt=media",
                headers={"Authorization": f"Bearer {token}"},
            )
            r.raise_for_status()
            return r.content

    def _parse(self, filename: str, data: bytes) -> pd.DataFrame:
        if filename.lower().endswith((".xlsx", ".xls")):
            return pd.read_excel(io.BytesIO(data), engine="openpyxl")
        return pd.read_csv(io.BytesIO(data))

    def _normalise(self, df: pd.DataFrame) -> pd.DataFrame:
        for col in df.columns:
            if pd.api.types.is_datetime64_any_dtype(df[col]):
                df[col] = df[col].dt.strftime("%Y-%m-%dT%H:%M:%S").where(df[col].notna(), None)
        return df
