from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any
import pandas as pd


@dataclass
class ConnectorConfig:
    connector_id: str
    tenant_id: str
    connector_type: str
    name: str
    config: dict[str, Any]
    credential_ref: str | None = None


@dataclass
class SchemaField:
    name: str
    data_type: str          # string | number | date | boolean
    nullable: bool = True
    sample: str | None = None


@dataclass
class SchemaDefinition:
    fields: list[SchemaField] = field(default_factory=list)
    row_count_estimate: int = 0
    source_name: str = ""


@dataclass
class DataQuery:
    connector_id: str
    preview_rows: int | None = None


@dataclass
class HealthStatus:
    healthy: bool
    message: str | None = None
    latency_ms: int | None = None


class SourceConnector(ABC):
    """Base class for all Smart Notifier source connectors.
    Implement this interface to add a new data source — zero engine changes required."""

    @classmethod
    @abstractmethod
    def connector_type(cls) -> str:
        """Unique type identifier e.g. 'file_upload', 'sharepoint', 'd365_fo'"""

    @abstractmethod
    async def authenticate(self, cfg: ConnectorConfig) -> bool:
        """Verify credentials. True = connection works."""

    @abstractmethod
    async def fetch(self, cfg: ConnectorConfig, query: DataQuery) -> pd.DataFrame:
        """Fetch data → normalised DataFrame. All values JSON-serialisable."""

    @abstractmethod
    async def schema(self, cfg: ConnectorConfig) -> SchemaDefinition:
        """Introspect and return schema of the source."""

    @abstractmethod
    async def health_check(self, cfg: ConnectorConfig) -> HealthStatus:
        """Return connection health status."""


class ConnectorFetchError(Exception):
    def __init__(self, connector_type: str, reason: str):
        self.connector_type = connector_type
        self.reason = reason
        super().__init__(f"[{connector_type}] {reason}")
