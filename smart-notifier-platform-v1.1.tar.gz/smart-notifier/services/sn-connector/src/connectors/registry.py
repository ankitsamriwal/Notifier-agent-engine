import logging
from .base import SourceConnector

logger = logging.getLogger(__name__)
_registry: dict[str, type[SourceConnector]] = {}


def register(cls: type[SourceConnector]) -> type[SourceConnector]:
    """Class decorator: register a connector."""
    t = cls.connector_type()
    _registry[t] = cls
    logger.info("Registered connector: %s", t)
    return cls


def get(t: str) -> type[SourceConnector] | None:
    return _registry.get(t)


def list_types() -> list[str]:
    return list(_registry.keys())


def get_or_raise(t: str) -> type[SourceConnector]:
    cls = get(t)
    if not cls:
        raise ValueError(f"Unknown connector '{t}'. Available: {list_types()}")
    return cls
