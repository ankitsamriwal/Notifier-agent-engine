"""
Effectiveness Service — computes notification performance metrics.
Dimensions: day_of_week, hour_of_day, month_position, tone, channel, job_type, frequency
Triggered by: cta.clicked events + scheduled recomputation (hourly)
"""
import asyncio, json, logging, os
from contextlib import asynccontextmanager
from datetime import datetime, timezone
import uvicorn
from fastapi import FastAPI, Header
import asyncpg
import aio_pika

logger = logging.getLogger(__name__)
DB_URL = os.environ.get("DATABASE_URL","").replace("postgresql+asyncpg://","postgresql://")
RECOMPUTE_INTERVAL = int(os.environ.get("METRICS_RECOMPUTE_INTERVAL_MINUTES","60")) * 60


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.pool = await asyncpg.create_pool(DB_URL, min_size=2, max_size=8)
    t1 = asyncio.create_task(consume_loop(app.state.pool))
    t2 = asyncio.create_task(recompute_loop(app.state.pool))
    yield
    t1.cancel(); t2.cancel()
    try: await asyncio.gather(t1, t2)
    except asyncio.CancelledError: pass
    await app.state.pool.close()


app = FastAPI(title="sn-effectiveness", version="1.0.0", lifespan=lifespan)


@app.get("/health")
async def health():
    return {"service": "sn-effectiveness", "status": "healthy"}


@app.get("/effectiveness")
async def get_effectiveness(
    x_tenant_id: str = Header(...),
    dimension: str | None = None,
    job_type: str | None = None,
):
    pool = app.state.pool
    q = "SELECT * FROM effectiveness_metrics WHERE tenant_id = $1::uuid"
    params = [x_tenant_id]
    if dimension:
        q += f" AND dimension = ${len(params)+1}"; params.append(dimension)
    if job_type:
        q += f" AND job_type = ${len(params)+1}"; params.append(job_type)
    q += " ORDER BY dimension, dimension_value"
    rows = await pool.fetch(q, *params)
    return {"data": [dict(r) for r in rows]}


@app.get("/effectiveness/summary")
async def get_summary(x_tenant_id: str = Header(...)):
    """Return the best-performing combinations across all dimensions."""
    pool = app.state.pool
    rows = await pool.fetch("""
        SELECT dimension, dimension_value, job_type,
               sends, opens, cta_responses, outcomes_verified,
               ROUND(open_rate * 100, 1) as open_pct,
               ROUND(cta_rate * 100, 1) as cta_pct,
               ROUND(outcome_rate * 100, 1) as outcome_pct
        FROM effectiveness_metrics
        WHERE tenant_id = $1::uuid AND sends >= 5
        ORDER BY outcome_rate DESC NULLS LAST, cta_rate DESC NULLS LAST
        LIMIT 20
    """, x_tenant_id)
    return {"data": [dict(r) for r in rows], "top_performers": [dict(r) for r in rows[:5]]}


# ── Metrics computation ────────────────────────────────────────────────────

async def compute_metrics(pool: asyncpg.Pool, tenant_id: str) -> None:
    """Recompute all effectiveness dimensions for a tenant from raw signal data."""
    logger.info("Recomputing effectiveness metrics for tenant=%s", tenant_id)

    # Day of week (0=Monday … 6=Sunday)
    await pool.execute("""
        INSERT INTO effectiveness_metrics
            (tenant_id, dimension, dimension_value, period_start, period_end,
             sends, opens, cta_responses, outcomes_verified, open_rate, cta_rate, outcome_rate)
        SELECT
            r.tenant_id,
            'day_of_week',
            TO_CHAR(r.triggered_at AT TIME ZONE 'Asia/Dubai', 'Dy'),
            DATE_TRUNC('month', NOW())::date,
            DATE_TRUNC('month', NOW())::date + INTERVAL '1 month' - INTERVAL '1 day',
            COUNT(r.run_id),
            COUNT(r.run_id) FILTER (WHERE r.status IN ('sent','draft_saved')),
            COUNT(DISTINCT cs.signal_id),
            COUNT(DISTINCT cs.signal_id) FILTER (WHERE cs.outcome_verified = true),
            CASE WHEN COUNT(r.run_id) > 0
                 THEN COUNT(r.run_id) FILTER (WHERE r.status IN ('sent','draft_saved'))::numeric / COUNT(r.run_id)
                 ELSE 0 END,
            CASE WHEN COUNT(r.run_id) > 0
                 THEN COUNT(DISTINCT cs.signal_id)::numeric / COUNT(r.run_id)
                 ELSE 0 END,
            CASE WHEN COUNT(r.run_id) > 0
                 THEN COUNT(DISTINCT cs.signal_id) FILTER (WHERE cs.outcome_verified = true)::numeric / COUNT(r.run_id)
                 ELSE 0 END
        FROM notification_runs r
        LEFT JOIN cta_signals cs ON cs.run_id = r.run_id
        WHERE r.tenant_id = $1::uuid
          AND r.triggered_at >= NOW() - INTERVAL '90 days'
        GROUP BY r.tenant_id, TO_CHAR(r.triggered_at AT TIME ZONE 'Asia/Dubai', 'Dy')
        ON CONFLICT (tenant_id, dimension, dimension_value, job_type, period_start)
        DO UPDATE SET
            sends = EXCLUDED.sends, opens = EXCLUDED.opens,
            cta_responses = EXCLUDED.cta_responses,
            outcomes_verified = EXCLUDED.outcomes_verified,
            open_rate = EXCLUDED.open_rate, cta_rate = EXCLUDED.cta_rate,
            outcome_rate = EXCLUDED.outcome_rate, computed_at = NOW()
    """, tenant_id)

    # Hour of day
    await pool.execute("""
        INSERT INTO effectiveness_metrics
            (tenant_id, dimension, dimension_value, period_start, period_end,
             sends, cta_responses, outcomes_verified, cta_rate, outcome_rate)
        SELECT
            r.tenant_id, 'hour_of_day',
            LPAD(EXTRACT(HOUR FROM r.triggered_at AT TIME ZONE 'Asia/Dubai')::text, 2, '0') || ':00',
            DATE_TRUNC('month', NOW())::date,
            (DATE_TRUNC('month', NOW()) + INTERVAL '1 month' - INTERVAL '1 day')::date,
            COUNT(r.run_id), COUNT(DISTINCT cs.signal_id),
            COUNT(DISTINCT cs.signal_id) FILTER (WHERE cs.outcome_verified),
            CASE WHEN COUNT(r.run_id) > 0
                 THEN COUNT(DISTINCT cs.signal_id)::numeric / COUNT(r.run_id) ELSE 0 END,
            CASE WHEN COUNT(r.run_id) > 0
                 THEN COUNT(DISTINCT cs.signal_id) FILTER (WHERE cs.outcome_verified)::numeric / COUNT(r.run_id) ELSE 0 END
        FROM notification_runs r
        LEFT JOIN cta_signals cs ON cs.run_id = r.run_id
        WHERE r.tenant_id = $1::uuid AND r.triggered_at >= NOW() - INTERVAL '90 days'
        GROUP BY r.tenant_id, EXTRACT(HOUR FROM r.triggered_at AT TIME ZONE 'Asia/Dubai')
        ON CONFLICT (tenant_id, dimension, dimension_value, job_type, period_start)
        DO UPDATE SET sends=EXCLUDED.sends, cta_responses=EXCLUDED.cta_responses,
            outcomes_verified=EXCLUDED.outcomes_verified,
            cta_rate=EXCLUDED.cta_rate, outcome_rate=EXCLUDED.outcome_rate, computed_at=NOW()
    """, tenant_id)

    # Month position (day 1-7, 8-14, 15-21, 22-27, 28-31)
    await pool.execute("""
        INSERT INTO effectiveness_metrics
            (tenant_id, dimension, dimension_value, period_start, period_end,
             sends, cta_responses, outcomes_verified, cta_rate, outcome_rate)
        SELECT
            r.tenant_id, 'month_position',
            CASE
                WHEN EXTRACT(DAY FROM r.triggered_at) BETWEEN 1  AND 7  THEN '01-07'
                WHEN EXTRACT(DAY FROM r.triggered_at) BETWEEN 8  AND 14 THEN '08-14'
                WHEN EXTRACT(DAY FROM r.triggered_at) BETWEEN 15 AND 21 THEN '15-21'
                WHEN EXTRACT(DAY FROM r.triggered_at) BETWEEN 22 AND 27 THEN '22-27'
                ELSE '28-31'
            END,
            DATE_TRUNC('month', NOW())::date,
            (DATE_TRUNC('month', NOW()) + INTERVAL '1 month' - INTERVAL '1 day')::date,
            COUNT(r.run_id), COUNT(DISTINCT cs.signal_id),
            COUNT(DISTINCT cs.signal_id) FILTER (WHERE cs.outcome_verified),
            CASE WHEN COUNT(r.run_id)>0 THEN COUNT(DISTINCT cs.signal_id)::numeric/COUNT(r.run_id) ELSE 0 END,
            CASE WHEN COUNT(r.run_id)>0 THEN COUNT(DISTINCT cs.signal_id) FILTER (WHERE cs.outcome_verified)::numeric/COUNT(r.run_id) ELSE 0 END
        FROM notification_runs r
        LEFT JOIN cta_signals cs ON cs.run_id = r.run_id
        WHERE r.tenant_id = $1::uuid AND r.triggered_at >= NOW() - INTERVAL '90 days'
        GROUP BY r.tenant_id, CASE WHEN EXTRACT(DAY FROM r.triggered_at) BETWEEN 1 AND 7 THEN '01-07'
            WHEN EXTRACT(DAY FROM r.triggered_at) BETWEEN 8 AND 14 THEN '08-14'
            WHEN EXTRACT(DAY FROM r.triggered_at) BETWEEN 15 AND 21 THEN '15-21'
            WHEN EXTRACT(DAY FROM r.triggered_at) BETWEEN 22 AND 27 THEN '22-27'
            ELSE '28-31' END
        ON CONFLICT (tenant_id, dimension, dimension_value, job_type, period_start)
        DO UPDATE SET sends=EXCLUDED.sends, cta_responses=EXCLUDED.cta_responses,
            outcomes_verified=EXCLUDED.outcomes_verified, cta_rate=EXCLUDED.cta_rate,
            outcome_rate=EXCLUDED.outcome_rate, computed_at=NOW()
    """, tenant_id)

    logger.info("Effectiveness metrics recomputed for tenant=%s", tenant_id)


async def recompute_loop(pool: asyncpg.Pool):
    """Hourly recomputation for all active tenants."""
    await asyncio.sleep(30)  # Initial delay on startup
    while True:
        try:
            tenants = await pool.fetch("SELECT tenant_id FROM tenants WHERE status = 'active'")
            for t in tenants:
                await compute_metrics(pool, str(t["tenant_id"]))
        except Exception as e:
            logger.error("Recompute error: %s", e)
        await asyncio.sleep(RECOMPUTE_INTERVAL)


async def consume_loop(pool: asyncpg.Pool):
    """Listen for cta.clicked events and trigger incremental metric updates."""
    rabbitmq_url = os.environ["RABBITMQ_URL"]
    while True:
        try:
            conn = await aio_pika.connect_robust(rabbitmq_url)
            async with conn:
                ch = await conn.channel()
                await ch.set_qos(prefetch_count=10)
                q = await ch.declare_queue("sn.effectiveness.signals", durable=True)
                await q.bind("sn.events", "cta.clicked")
                await q.bind("sn.events", "delivery.sent")
                async with q.iterator() as qi:
                    async for msg in qi:
                        async with msg.process(requeue=False):
                            payload = json.loads(msg.body)
                            tenant_id = payload.get("tenant_id")
                            if tenant_id:
                                # Trigger recompute for this tenant (debounced in real impl)
                                await compute_metrics(pool, tenant_id)
        except Exception as e:
            logger.error("Effectiveness consumer error: %s", e)
            await asyncio.sleep(5)


if __name__ == "__main__":
    logging.basicConfig(level=os.getenv("LOG_LEVEL","INFO"))
    uvicorn.run("src.main:app", host="0.0.0.0", port=int(os.getenv("PORT","8010")))
