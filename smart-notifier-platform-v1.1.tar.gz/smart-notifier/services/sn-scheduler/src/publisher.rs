//! AMQP event publisher — emits job.triggered to sn.events exchange.

use lapin::{Channel, BasicProperties, options::BasicPublishOptions};
use serde::Serialize;
use anyhow::Result;

#[derive(Serialize)]
pub struct JobTriggeredEvent {
    pub event: String,
    pub run_id: String,
    pub job_id: String,
    pub tenant_id: String,
    pub connector_id: String,
    pub trigger_type: String,
    pub dry_run: bool,
}

pub async fn publish_job_triggered(
    channel: &Channel,
    event: &JobTriggeredEvent,
) -> Result<()> {
    let payload = serde_json::to_vec(event)?;

    channel.basic_publish(
        "sn.events",
        "job.triggered",
        BasicPublishOptions::default(),
        &payload,
        BasicProperties::default()
            .with_content_type("application/json".into())
            .with_delivery_mode(2),  // persistent
    ).await?.await?;

    Ok(())
}
