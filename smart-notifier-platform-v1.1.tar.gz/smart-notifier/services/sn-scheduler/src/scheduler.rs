//! Core scheduler loop — polls job registry, evaluates CRON expressions,
//! acquires distributed lock, emits job.triggered events.

use std::{
    collections::HashMap,
    sync::atomic::{AtomicUsize, Ordering},
    sync::Arc,
};
use chrono::{Utc, TimeZone};
use chrono_tz::Tz;
use cron::Schedule;
use lapin::Channel;
use redis::aio::ConnectionManager;
use reqwest::Client;
use serde::Deserialize;
use std::str::FromStr;
use tokio::time::{interval, Duration};
use tracing::{error, info, warn};
use uuid::Uuid;

use crate::{config::SchedulerConfig, lock::DistributedLock, publisher};

#[derive(Debug, Clone, Deserialize)]
pub struct JobRecord {
    pub job_id: String,
    pub tenant_id: String,
    pub connector_id: String,
    pub status: String,
    pub schedule: serde_json::Value,
}

pub struct JobScheduler {
    lock: DistributedLock,
    channel: Channel,
    config: SchedulerConfig,
    http: Client,
    job_count: Arc<AtomicUsize>,
}

impl JobScheduler {
    pub fn new(redis: ConnectionManager, channel: Channel, config: SchedulerConfig) -> Self {
        Self {
            lock: DistributedLock::new(redis),
            channel,
            config,
            http: Client::new(),
            job_count: Arc::new(AtomicUsize::new(0)),
        }
    }

    pub fn job_count(&self) -> usize {
        self.job_count.load(Ordering::Relaxed)
    }

    pub async fn run(&self) {
        let mut tick = interval(Duration::from_millis(self.config.scheduler_tick_ms));
        info!("Scheduler loop started ({}ms tick)", self.config.scheduler_tick_ms);

        loop {
            tick.tick().await;
            if let Err(e) = self.evaluate_all_jobs().await {
                error!("Scheduler tick error: {}", e);
            }
        }
    }

    async fn evaluate_all_jobs(&self) -> anyhow::Result<()> {
        // Fetch active jobs from job registry
        let url = format!("{}/jobs?status=active", self.config.job_registry_url);
        let resp = self.http.get(&url)
            .header("x-tenant-id", "00000000-0000-0000-0000-000000000000") // super_admin context
            .header("x-roles", "super_admin")
            .send()
            .await?;

        if !resp.status().is_success() {
            warn!("Job registry returned {}", resp.status());
            return Ok(());
        }

        #[derive(Deserialize)]
        struct JobListResponse { data: Vec<JobRecord> }
        let body: JobListResponse = resp.json().await?;
        self.job_count.store(body.data.len(), Ordering::Relaxed);

        let now = Utc::now();

        for job in &body.data {
            let sched_type = job.schedule["type"].as_str().unwrap_or("manual");
            if sched_type != "cron" {
                continue;  // Only CRON jobs are auto-triggered here
            }

            let cron_expr = job.schedule["cron"].as_str().unwrap_or("");
            let tz_str    = job.schedule["timezone"].as_str().unwrap_or("Asia/Dubai");

            if cron_expr.is_empty() {
                continue;
            }

            // Parse CRON and check if it should fire in this tick window
            if self.should_trigger(cron_expr, tz_str, now).await {
                let window = now.timestamp() / 60; // 1-minute window key
                match self.lock.try_acquire(&job.job_id, window, self.config.lock_ttl_seconds).await {
                    Ok(true) => {
                        // We acquired the lock — trigger this job
                        let run_id = Uuid::new_v4().to_string();
                        let event = publisher::JobTriggeredEvent {
                            event: "job.triggered".into(),
                            run_id: run_id.clone(),
                            job_id: job.job_id.clone(),
                            tenant_id: job.tenant_id.clone(),
                            connector_id: job.connector_id.clone(),
                            trigger_type: "cron".into(),
                            dry_run: false,
                        };
                        if let Err(e) = publisher::publish_job_triggered(&self.channel, &event).await {
                            error!(job_id = %job.job_id, "Failed to publish trigger: {}", e);
                            // Release lock so another replica can retry
                            let _ = self.lock.release(&job.job_id, window).await;
                        } else {
                            info!(job_id = %job.job_id, run_id = %run_id, "Triggered job");
                        }
                    }
                    Ok(false) => {
                        // Another replica already triggered this job in this window — skip
                    }
                    Err(e) => {
                        error!(job_id = %job.job_id, "Lock error: {}", e);
                    }
                }
            }
        }

        Ok(())
    }

    async fn should_trigger(&self, cron_expr: &str, tz: &str, now: chrono::DateTime<Utc>) -> bool {
        // Add seconds field if 5-field cron (standard cron without seconds)
        let expr = if cron_expr.split_whitespace().count() == 5 {
            format!("0 {}", cron_expr)   // prepend seconds=0
        } else {
            cron_expr.to_string()
        };

        let schedule = match Schedule::from_str(&expr) {
            Ok(s) => s,
            Err(e) => {
                warn!("Invalid CRON '{}': {}", cron_expr, e);
                return false;
            }
        };

        let tz: Tz = tz.parse().unwrap_or(chrono_tz::Asia::Dubai);
        let now_local = now.with_timezone(&tz);

        // Check if CRON fired within this tick window (last tick_ms milliseconds)
        let tick_window = Duration::from_millis(self.config.scheduler_tick_ms);
        let window_start = now - chrono::Duration::milliseconds(tick_window.as_millis() as i64);

        schedule.after(&window_start.with_timezone(&tz))
            .next()
            .map(|next| next <= now_local)
            .unwrap_or(false)
    }
}
