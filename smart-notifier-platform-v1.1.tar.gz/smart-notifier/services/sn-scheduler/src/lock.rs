//! Distributed lock using Redis SET NX EX
//! Prevents duplicate job triggers when running multiple scheduler replicas.

use redis::{AsyncCommands, aio::ConnectionManager};
use anyhow::Result;

pub struct DistributedLock {
    redis: ConnectionManager,
}

impl DistributedLock {
    pub fn new(redis: ConnectionManager) -> Self {
        Self { redis }
    }

    /// Acquire lock for a job run. Returns true if acquired (this replica should trigger).
    /// Key: sn:lock:job:{job_id}:{window}  TTL: lock_ttl_seconds
    pub async fn try_acquire(&self, job_id: &str, window: i64, ttl_secs: u64) -> Result<bool> {
        let key = format!("sn:lock:job:{}:{}", job_id, window);
        let mut conn = self.redis.clone();

        // SET key 1 NX EX ttl — atomic: set only if not exists
        let result: Option<String> = redis::cmd("SET")
            .arg(&key)
            .arg("1")
            .arg("NX")
            .arg("EX")
            .arg(ttl_secs)
            .query_async(&mut conn)
            .await?;

        Ok(result.is_some())  // Some("OK") = acquired, None = already locked
    }

    pub async fn release(&self, job_id: &str, window: i64) -> Result<()> {
        let key = format!("sn:lock:job:{}:{}", job_id, window);
        let mut conn = self.redis.clone();
        conn.del(&key).await?;
        Ok(())
    }
}
