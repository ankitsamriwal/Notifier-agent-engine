use serde::Deserialize;
use anyhow::{Context, Result};

#[derive(Debug, Clone, Deserialize)]
pub struct SchedulerConfig {
    #[serde(default = "default_port")]
    pub port: u16,
    pub redis_url: String,
    pub rabbitmq_url: String,
    pub job_registry_url: String,
    #[serde(default = "default_tick")]
    pub scheduler_tick_ms: u64,
    #[serde(default = "default_lock_ttl")]
    pub lock_ttl_seconds: u64,
}

fn default_port() -> u16 { 8003 }
fn default_tick() -> u64 { 1000 }
fn default_lock_ttl() -> u64 { 30 }

impl SchedulerConfig {
    pub fn from_env() -> Result<Self> {
        config::Config::builder()
            .add_source(config::Environment::default().separator("_").try_parsing(true))
            .build()
            .context("Config build failed")?
            .try_deserialize()
            .context("Config deserialise failed")
    }
}
