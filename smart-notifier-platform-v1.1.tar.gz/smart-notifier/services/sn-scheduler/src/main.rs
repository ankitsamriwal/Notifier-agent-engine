//! Smart Notifier Scheduler
//! Manages 10k+ concurrent CRON job timers using Tokio tasks.
//! Distributed lock (Redis) prevents duplicate triggers across replicas.

use std::{sync::Arc, net::SocketAddr};
use tokio::net::TcpListener;
use axum::{Router, routing::get, Json};
use serde_json::json;
use tracing::info;

mod config;
mod scheduler;
mod lock;
mod publisher;

use config::SchedulerConfig;
use scheduler::JobScheduler;

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    dotenvy::dotenv().ok();
    init_tracing();

    let cfg = SchedulerConfig::from_env()?;
    info!("sn-scheduler starting, tick={}ms", cfg.scheduler_tick_ms);

    // Redis for distributed lock
    let redis_client = redis::Client::open(cfg.redis_url.clone())?;
    let redis = redis::aio::ConnectionManager::new(redis_client).await?;

    // AMQP connection
    let amqp_conn = lapin::Connection::connect(
        &cfg.rabbitmq_url,
        lapin::ConnectionProperties::default(),
    ).await?;
    let amqp_channel = amqp_conn.create_channel().await?;

    let scheduler = Arc::new(JobScheduler::new(
        redis.clone(),
        amqp_channel,
        cfg.clone(),
    ));

    // Start scheduler loop
    let sched_handle = {
        let s = scheduler.clone();
        tokio::spawn(async move { s.run().await })
    };

    // Health / management HTTP server
    let app = Router::new()
        .route("/health", get(health))
        .route("/scheduler/jobs", get({
            let s = scheduler.clone();
            move || async move { Json(json!({ "active_jobs": s.job_count() })) }
        }));

    let addr: SocketAddr = format!("0.0.0.0:{}", cfg.port).parse()?;
    info!(addr = %addr, "Scheduler HTTP listening");
    let listener = TcpListener::bind(addr).await?;

    tokio::select! {
        r = axum::serve(listener, app) => r?,
        r = sched_handle => { r??; },
    }

    Ok(())
}

async fn health() -> Json<serde_json::Value> {
    Json(json!({ "service": "sn-scheduler", "status": "healthy" }))
}

fn init_tracing() {
    use tracing_subscriber::{EnvFilter, fmt, prelude::*};
    tracing_subscriber::registry()
        .with(EnvFilter::from_default_env()
            .add_directive("sn_scheduler=info".parse().unwrap()))
        .with(fmt::layer().json())
        .init();
}
