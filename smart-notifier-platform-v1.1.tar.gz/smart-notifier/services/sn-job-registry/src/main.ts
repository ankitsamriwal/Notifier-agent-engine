/**
 * Smart Notifier — Job Registry Service
 * Fastify + TypeScript: Job CRUD, config store, WebSocket push, AMQP events
 */
import Fastify from 'fastify'
import cors from '@fastify/cors'
import helmet from '@fastify/helmet'
import websocket from '@fastify/websocket'
import { PrismaClient } from '@prisma/client'
import Redis from 'ioredis'

import { registerRoutes } from './routes'
import { AmqpPublisher } from './events/publisher'
import { getConfig } from './config'
import { initTelemetry } from './telemetry'

const config = getConfig()
initTelemetry(config.otelEndpoint, 'sn-job-registry')

const prisma = new PrismaClient({
  log: ['error', 'warn'],
})

const redis = new Redis(config.redisUrl, {
  maxRetriesPerRequest: 3,
  lazyConnect: false,
})

const amqp = new AmqpPublisher(config.rabbitmqUrl)

const app = Fastify({
  logger: {
    level: config.logLevel,
    serializers: {
      req: (req) => ({ method: req.method, url: req.url, correlationId: req.headers['x-correlation-id'] }),
    },
  },
  trustProxy: true,
})

async function bootstrap() {
  // Register plugins
  await app.register(cors, { origin: '*' })
  await app.register(helmet, { contentSecurityPolicy: false })
  await app.register(websocket)

  // Dependency injection via decorators
  app.decorate('prisma', prisma)
  app.decorate('redis', redis)
  app.decorate('amqp', amqp)
  app.decorate('config', config)

  // Connect AMQP
  await amqp.connect()

  // Register all routes
  registerRoutes(app)

  // Health
  app.get('/health', async () => ({
    service: 'sn-job-registry',
    version: '1.0.0',
    status: 'healthy',
    db: 'ok',
    amqp: amqp.isConnected() ? 'ok' : 'degraded',
  }))

  await app.listen({ port: config.port, host: '0.0.0.0' })
  app.log.info(`sn-job-registry listening on :${config.port}`)
}

bootstrap().catch((err) => {
  console.error('Fatal startup error', err)
  process.exit(1)
})

// Graceful shutdown
process.on('SIGTERM', async () => {
  await app.close()
  await prisma.$disconnect()
  await amqp.close()
  redis.quit()
  process.exit(0)
})
