import amqplib, { Channel, Connection } from 'amqplib'

export class AmqpPublisher {
  private connection: Connection | null = null
  private channel: Channel | null = null

  constructor(private readonly url: string) {}

  async connect(): Promise<void> {
    this.connection = await amqplib.connect(this.url)
    this.channel = await this.connection.createChannel()
    await this.channel.assertExchange('sn.events', 'topic', { durable: true })
  }

  async publish(exchange: string, routingKey: string, payload: object): Promise<void> {
    if (!this.channel) throw new Error('AMQP not connected')
    this.channel.publish(
      exchange,
      routingKey,
      Buffer.from(JSON.stringify(payload)),
      { persistent: true, contentType: 'application/json' },
    )
  }

  isConnected(): boolean { return this.channel !== null }

  async close(): Promise<void> {
    await this.channel?.close()
    await this.connection?.close()
  }
}
