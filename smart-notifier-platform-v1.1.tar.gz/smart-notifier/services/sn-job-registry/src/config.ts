export interface Config {
  port: number
  logLevel: string
  databaseUrl: string
  redisUrl: string
  rabbitmqUrl: string
  otelEndpoint: string
}

export function getConfig(): Config {
  return {
    port:         parseInt(process.env.PORT ?? '8002', 10),
    logLevel:     process.env.LOG_LEVEL ?? 'info',
    databaseUrl:  requireEnv('DATABASE_URL'),
    redisUrl:     requireEnv('REDIS_URL'),
    rabbitmqUrl:  requireEnv('RABBITMQ_URL'),
    otelEndpoint: process.env.OTEL_EXPORTER_OTLP_ENDPOINT ?? 'http://otel-collector:4317',
  }
}

function requireEnv(key: string): string {
  const val = process.env[key]
  if (!val) throw new Error(`Required env var missing: ${key}`)
  return val
}
