import { z } from 'zod'

export const CriterionSchema = z.object({
  field: z.string().min(1),
  op: z.enum(['greater_than','less_than','equals','not_equals','contains','not_contains','is_empty','is_not_empty','regex','date_before','date_after']),
  value: z.union([z.string(), z.number()]).optional(),
})

export const CreateJobSchema = z.object({
  name:         z.string().min(1).max(255),
  description:  z.string().default(''),
  connector_id: z.string().uuid(),
  criteria: z.object({
    logic: z.enum(['AND','OR']).default('AND'),
    conditions: z.array(CriterionSchema),
  }),
  tone: z.enum(['Professional','Urgent','Friendly','Formal','Firm','Concise']).default('Professional'),
  channel: z.enum(['gmail','outlook','whatsapp','teams','slack','webhook']),
  recipients: z.object({ to: z.string(), cc: z.string().default(''), bcc: z.string().default('') }),
  template: z.object({ subject: z.string().default(''), body_hint: z.string().default(''), body_draft: z.string().default('') }),
  schedule: z.object({ type: z.enum(['cron','polling','webhook','manual']).default('manual'), cron: z.string().default(''), timezone: z.string().default('Asia/Dubai') }),
  approval_mode: z.enum(['draft','manual','auto']).default('manual'),
  options: z.object({
    include_data_table: z.boolean().default(true),
    attach_pdf: z.boolean().default(false),
    attach_files: z.array(z.string()).default([]),
    digest_mode: z.enum(['digest','individual']).default('digest'),
  }).default({}),
})

export const UpdateJobSchema = CreateJobSchema.partial().extend({
  status: z.enum(['active','paused','draft']).optional(),
})

export type CreateJobInput = z.infer<typeof CreateJobSchema>
export type UpdateJobInput = z.infer<typeof UpdateJobSchema>
