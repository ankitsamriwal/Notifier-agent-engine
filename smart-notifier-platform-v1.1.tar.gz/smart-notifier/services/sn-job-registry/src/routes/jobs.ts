import type { FastifyInstance } from 'fastify'
import { randomUUID } from 'crypto'
import { CreateJobSchema, UpdateJobSchema } from '../schemas/job'

export async function jobRoutes(app: FastifyInstance): Promise<void> {

  app.get('/', async (req) => {
    const tenantId = req.headers['x-tenant-id'] as string
    const { status } = req.query as Record<string, string>
    const where: Record<string, unknown> = { tenant_id: tenantId }
    if (status) where.status = status
    // @ts-ignore
    const jobs = await app.prisma.jobs.findMany({ where, orderBy: { created_at: 'desc' } })
    return { data: jobs, total: jobs.length }
  })

  app.post('/', async (req, reply) => {
    const tenantId = req.headers['x-tenant-id'] as string
    const userId = req.headers['x-user-id'] as string
    const body = CreateJobSchema.parse(req.body)
    // @ts-ignore
    const job = await app.prisma.jobs.create({
      data: { job_id: randomUUID(), tenant_id: tenantId, created_by: userId, ...body, status: 'draft' },
    })
    // @ts-ignore
    await app.amqp.publish('sn.events', 'audit.job.created', { event: 'job.created', job_id: job.job_id, tenant_id: tenantId, actor_id: userId })
    reply.code(201)
    return job
  })

  app.get('/:id', async (req, reply) => {
    const { id } = req.params as { id: string }
    const tenantId = req.headers['x-tenant-id'] as string
    // @ts-ignore
    const job = await app.prisma.jobs.findFirst({ where: { job_id: id, tenant_id: tenantId } })
    if (!job) return reply.code(404).send({ error: 'not_found' })
    return job
  })

  app.put('/:id', async (req, reply) => {
    const { id } = req.params as { id: string }
    const tenantId = req.headers['x-tenant-id'] as string
    const body = UpdateJobSchema.parse(req.body)
    // @ts-ignore
    const existing = await app.prisma.jobs.findFirst({ where: { job_id: id, tenant_id: tenantId } })
    if (!existing) return reply.code(404).send({ error: 'not_found' })
    // @ts-ignore
    const updated = await app.prisma.jobs.update({ where: { job_id: id }, data: { ...body, updated_at: new Date() } })
    return updated
  })

  app.delete('/:id', async (req, reply) => {
    const { id } = req.params as { id: string }
    const tenantId = req.headers['x-tenant-id'] as string
    // @ts-ignore
    await app.prisma.jobs.delete({ where: { job_id: id, tenant_id: tenantId } })
    reply.code(204)
  })

  app.post('/:id/trigger', async (req, reply) => {
    const { id } = req.params as { id: string }
    const tenantId = req.headers['x-tenant-id'] as string
    const { dry_run } = (req.body as { dry_run?: boolean }) ?? {}
    // @ts-ignore
    const job = await app.prisma.jobs.findFirst({ where: { job_id: id, tenant_id: tenantId } })
    if (!job) return reply.code(404).send({ error: 'not_found' })
    const runId = randomUUID()
    // @ts-ignore
    await app.amqp.publish('sn.events', 'job.triggered', {
      event: 'job.triggered', run_id: runId, job_id: id, tenant_id: tenantId,
      connector_id: job.connector_id, trigger_type: 'manual', dry_run: dry_run ?? false, job_config: job,
    })
    reply.code(202)
    return { run_id: runId, job_id: id, status: 'triggered' }
  })

  app.post('/:id/clone', async (req, reply) => {
    const { id } = req.params as { id: string }
    const tenantId = req.headers['x-tenant-id'] as string
    const userId = req.headers['x-user-id'] as string
    // @ts-ignore
    const src = await app.prisma.jobs.findFirst({ where: { job_id: id, tenant_id: tenantId } })
    if (!src) return reply.code(404).send({ error: 'not_found' })
    // @ts-ignore
    const cloned = await app.prisma.jobs.create({
      data: { ...src, job_id: randomUUID(), name: `${src.name} (copy)`, status: 'draft', run_count: 0, version: 1, created_by: userId, created_at: new Date(), updated_at: new Date(), last_run_at: null, next_run_at: null },
    })
    reply.code(201)
    return cloned
  })
}
