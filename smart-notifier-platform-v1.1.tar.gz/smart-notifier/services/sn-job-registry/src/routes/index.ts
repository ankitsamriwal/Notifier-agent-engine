import type { FastifyInstance } from 'fastify'
import { jobRoutes } from './jobs'

export function registerRoutes(app: FastifyInstance): void {
  app.register(jobRoutes, { prefix: '/jobs' })
}
