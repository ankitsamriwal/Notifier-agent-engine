use lapin::{Channel, BasicProperties, options::BasicPublishOptions};
use serde_json::Value;
use anyhow::Result;

pub async fn publish_cta_clicked(channel: &Channel, payload: Value) -> Result<()> {
    let body = serde_json::to_vec(&payload)?;
    channel.basic_publish(
        "sn.events",
        "cta.clicked",
        BasicPublishOptions::default(),
        &body,
        BasicProperties::default()
            .with_content_type("application/json".into())
            .with_delivery_mode(2),
    ).await?.await?;
    Ok(())
}
