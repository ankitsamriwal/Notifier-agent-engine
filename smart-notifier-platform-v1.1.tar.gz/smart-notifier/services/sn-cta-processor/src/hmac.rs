//! HMAC-SHA256 URL signing and verification.
//! Uses ring::constant_time::verify_slices_are_equal — timing-safe by design.
//! DESC ISR 10.1 cryptographic controls compliance.

use ring::{hmac, constant_time};
use serde::{Deserialize, Serialize};
use uuid::Uuid;
use chrono::{Utc, Duration};
use base64::{Engine, engine::general_purpose::URL_SAFE_NO_PAD};

#[derive(Debug, Serialize, Deserialize)]
pub struct CtaPayload {
    pub run_id:       String,
    pub job_id:       String,
    pub tenant_id:    String,
    pub button_key:   String,
    pub button_label: String,
    pub expires_at:   i64,   // Unix timestamp
}

pub struct CtaSigner {
    key: hmac::Key,
}

impl CtaSigner {
    pub fn new(secret: &str) -> Self {
        let key = hmac::Key::new(hmac::HMAC_SHA256, secret.as_bytes());
        Self { key }
    }

    /// Generate a signed, URL-safe CTA token from a payload.
    /// Token format: base64url(json_payload) + "." + base64url(hmac_signature)
    pub fn sign(&self, payload: &CtaPayload) -> anyhow::Result<String> {
        let payload_json = serde_json::to_string(payload)?;
        let payload_b64  = URL_SAFE_NO_PAD.encode(payload_json.as_bytes());
        let sig          = hmac::sign(&self.key, payload_b64.as_bytes());
        let sig_b64      = URL_SAFE_NO_PAD.encode(sig.as_ref());
        Ok(format!("{}.{}", payload_b64, sig_b64))
    }

    /// Verify a CTA token. Returns the payload if valid, error if tampered or expired.
    /// Timing-safe: uses constant_time::verify_slices_are_equal.
    pub fn verify(&self, token: &str) -> anyhow::Result<CtaPayload> {
        let parts: Vec<&str> = token.splitn(2, '.').collect();
        if parts.len() != 2 {
            anyhow::bail!("Invalid token format");
        }

        let payload_b64 = parts[0];
        let sig_b64     = parts[1];

        // Compute expected HMAC
        let expected_sig = hmac::sign(&self.key, payload_b64.as_bytes());
        let expected_b64 = URL_SAFE_NO_PAD.encode(expected_sig.as_ref());

        // Constant-time comparison — prevents timing attacks
        let sig_bytes     = sig_b64.as_bytes();
        let expected_bytes = expected_b64.as_bytes();
        constant_time::verify_slices_are_equal(sig_bytes, expected_bytes)
            .map_err(|_| anyhow::anyhow!("Invalid HMAC signature"))?;

        // Decode and parse payload
        let payload_bytes = URL_SAFE_NO_PAD.decode(payload_b64)?;
        let payload: CtaPayload = serde_json::from_slice(&payload_bytes)?;

        // Check expiry
        if Utc::now().timestamp() > payload.expires_at {
            anyhow::bail!("CTA token expired");
        }

        Ok(payload)
    }

    /// Build a full CTA URL for embedding in emails.
    pub fn build_url(&self, base_url: &str, payload: &CtaPayload) -> anyhow::Result<String> {
        let token = self.sign(payload)?;
        Ok(format!("{}/cta/{}", base_url, token))
    }
}

/// Build CTA payload with TTL
pub fn make_payload(
    run_id: &str,
    job_id: &str,
    tenant_id: &str,
    button_key: &str,
    button_label: &str,
    ttl_hours: u64,
) -> CtaPayload {
    CtaPayload {
        run_id:       run_id.to_string(),
        job_id:       job_id.to_string(),
        tenant_id:    tenant_id.to_string(),
        button_key:   button_key.to_string(),
        button_label: button_label.to_string(),
        expires_at:   (Utc::now() + Duration::hours(ttl_hours as i64)).timestamp(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_sign_and_verify_roundtrip() {
        let signer = CtaSigner::new("test-secret-32-chars-minimum-ok!");
        let payload = make_payload("run-1","job-1","tenant-1","payment_made","Payment made",72);
        let token = signer.sign(&payload).unwrap();
        let verified = signer.verify(&token).unwrap();
        assert_eq!(verified.button_key, "payment_made");
        assert_eq!(verified.run_id, "run-1");
    }

    #[test]
    fn test_tampered_token_rejected() {
        let signer = CtaSigner::new("test-secret-32-chars-minimum-ok!");
        let payload = make_payload("run-1","job-1","tenant-1","payment_made","Payment made",72);
        let mut token = signer.sign(&payload).unwrap();
        // Tamper the last character
        token.pop();
        token.push(if token.ends_with('A') { 'B' } else { 'A' });
        assert!(signer.verify(&token).is_err());
    }
}
