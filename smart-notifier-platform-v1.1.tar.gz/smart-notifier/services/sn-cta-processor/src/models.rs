use serde::{Deserialize, Serialize};

#[derive(Debug, Deserialize)]
pub struct GenerateCtaRequest {
    pub run_id:    String,
    pub job_id:    String,
    pub tenant_id: String,
    pub buttons:   Vec<CtaButtonDef>,
}

#[derive(Debug, Deserialize)]
pub struct CtaButtonDef {
    pub label: String,
    pub key:   String,
}

#[derive(Debug, Serialize)]
pub struct GenerateCtaResponse {
    pub buttons: Vec<CtaButtonWithUrl>,
}

#[derive(Debug, Serialize)]
pub struct CtaButtonWithUrl {
    pub label: String,
    pub key:   String,
    pub url:   String,
}
