use crate::hmac::TokenClaims;
use sha2::{Sha256, Digest};
use hex;
use anyhow::Result;

pub async fn insert_cta_signal(pool: &sqlx::PgPool, claims: &TokenClaims) -> Result<()> {
    let signal_id = uuid::Uuid::new_v4();
    let idempotency = format!("{}:{}", claims.run_id, claims.button_key);
    let idem_hash = {
        let mut h = Sha256::new();
        h.update(idempotency.as_bytes());
        hex::encode(h.finalize())
    };

    sqlx::query!(
        r#"
        INSERT INTO cta_signals
            (signal_id, run_id, job_id, tenant_id, button_key, button_label,
             channel, clicked_at, idempotency_key)
        VALUES ($1, $2, $3, $4, $5, $5, 'email', NOW(), $6)
        ON CONFLICT (idempotency_key) DO NOTHING
        "#,
        signal_id,
        claims.run_id,
        claims.job_id,
        uuid::Uuid::parse_str(&claims.tenant_id).unwrap_or_default(),
        claims.button_key,
        idem_hash,
    ).execute(pool).await?;

    Ok(())
}

pub async fn schedule_verification(pool: &sqlx::PgPool, claims: &TokenClaims) -> Result<()> {
    // Schedule verification checks at T+24h and T+72h
    let signal_id = uuid::Uuid::new_v4();
    for hours in [24i64, 72i64] {
        sqlx::query!(
            r#"
            INSERT INTO cta_verification_queue (signal_id, run_at, attempt)
            SELECT s.signal_id, NOW() + ($1 || ' hours')::INTERVAL, 1
            FROM cta_signals s
            WHERE s.run_id = $2 AND s.button_key = $3
            LIMIT 1
            "#,
            hours.to_string(),
            claims.run_id,
            claims.button_key,
        ).execute(pool).await?;
    }
    Ok(())
}
