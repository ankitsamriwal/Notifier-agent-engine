use axum::{
    extract::{State, Path},
    response::{IntoResponse, Redirect, Json},
    http::StatusCode,
};
use redis::AsyncCommands;
use serde_json::json;
use uuid::Uuid;
use chrono::Utc;
use crate::{AppState, hmac, models::*};

pub async fn health() -> Json<serde_json::Value> {
    Json(json!({"service": "sn-cta-processor", "status": "healthy"}))
}

/// POST /cta/generate — create signed CTA URLs for a set of buttons
pub async fn generate_cta_urls(
    State(state): State<AppState>,
    Json(req): Json<GenerateCtaRequest>,
) -> Result<Json<GenerateCtaResponse>, (StatusCode, Json<serde_json::Value>)> {
    let mut buttons = Vec::new();

    for btn in &req.buttons {
        let url = hmac::build_cta_url(
            &state.config.cta_base_url,
            &state.config.cta_hmac_secret,
            &req.run_id,
            &req.job_id,
            &req.tenant_id,
            &btn.key,
            &btn.label,
            state.config.cta_url_ttl_hours,
        ).map_err(|e| (
            StatusCode::INTERNAL_SERVER_ERROR,
            Json(json!({"error": e.to_string()})),
        ))?;

        buttons.push(CtaButton { label: btn.label.clone(), key: btn.key.clone(), url });
    }

    Ok(Json(GenerateCtaResponse { run_id: req.run_id, buttons }))
}

/// GET /cta/:token — recipient clicks CTA button in email
pub async fn handle_click(
    State(state): State<AppState>,
    Path(token): Path<String>,
    axum::extract::ConnectInfo(addr): axum::extract::ConnectInfo<std::net::SocketAddr>,
) -> impl IntoResponse {
    // Verify HMAC signature (constant-time)
    let payload = match hmac::verify(&token, &state.config.cta_hmac_secret) {
        Ok(p) => p,
        Err(e) => {
            tracing::warn!("Invalid CTA token: {}", e);
            return (StatusCode::BAD_REQUEST, "Invalid or expired link").into_response();
        }
    };

    // Idempotency: prevent duplicate recording of same click (nonce in Redis)
    let dedup_key = format!("sn:cta:click:{}", payload.nonce);
    let mut redis = state.redis.clone();
    let already_recorded: bool = redis.exists(&dedup_key).await.unwrap_or(false);

    if !already_recorded {
        // Hash IP for privacy (DESC ISR 11.1)
        use sha2::{Sha256, Digest};
        let ip_hash = format!("{:x}", Sha256::digest(addr.ip().to_string().as_bytes()));

        // Record signal in DB
        let signal_id = Uuid::new_v4().to_string();
        let _ = sqlx::query!(
            r#"
            INSERT INTO cta_signals
              (signal_id, run_id, job_id, tenant_id, button_label, button_key,
               channel, ip_hash, idempotency_key, clicked_at)
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
            ON CONFLICT (idempotency_key) DO NOTHING
            "#,
            signal_id,
            payload.run_id,
            payload.job_id,
            payload.tenant_id,
            payload.button_label,
            payload.button_key,
            "email",
            ip_hash,
            payload.nonce,
            Utc::now(),
        )
        .execute(&state.db)
        .await;

        // Dedup key TTL = 7 days
        let _: () = redis.set_ex(&dedup_key, "1", 604800).await.unwrap_or(());

        // Schedule verification checks at T+24h and T+72h
        let _ = sqlx::query!(
            "INSERT INTO cta_verification_queue (signal_id, run_at, attempt) VALUES ($1, $2, 1), ($1, $3, 2)",
            signal_id,
            Utc::now() + chrono::Duration::hours(24),
            Utc::now() + chrono::Duration::hours(72),
        )
        .execute(&state.db)
        .await;

        tracing::info!(
            run_id = %payload.run_id,
            button = %payload.button_key,
            signal_id = %signal_id,
            "CTA click recorded"
        );
    }

    // Redirect to a thank-you / confirmation page
    Redirect::temporary("/cta/thankyou").into_response()
}
