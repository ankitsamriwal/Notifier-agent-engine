use serde::Deserialize;
use anyhow::{Context, Result};

#[derive(Debug, Clone, Deserialize)]
pub struct CtaConfig {
    #[serde(default = "default_port")]
    pub port: u16,
    pub database_url: String,
    pub redis_url: String,
    pub rabbitmq_url: String,
    pub cta_hmac_secret: String,
    #[serde(default = "default_ttl")]
    pub cta_url_ttl_hours: u64,
    pub cta_base_url: String,
}

fn default_port() -> u16 { 8008 }
fn default_ttl()  -> u64 { 72 }

impl CtaConfig {
    pub fn from_env() -> Result<Self> {
        config::Config::builder()
            .add_source(config::Environment::default().separator("_").try_parsing(true))
            .build()
            .context("Config build")?
            .try_deserialize()
            .context("Config deserialise")
    }
}
