use axum::{
    extract::{Path, State},
    response::{IntoResponse, Redirect},
    Json, http::StatusCode,
};
use redis::AsyncCommands;
use serde_json::json;
use sha2::{Sha256, Digest};
use chrono::Utc;
use uuid::Uuid;

use crate::{
    AppState,
    hmac::{CtaSigner, make_payload},
    models::{GenerateCtaRequest, GenerateCtaResponse, CtaButtonWithUrl},
    publisher::publish_cta_clicked,
};

pub async fn health() -> Json<serde_json::Value> {
    Json(json!({ "service": "sn-cta-processor", "status": "healthy" }))
}

/// Handle a recipient clicking a CTA button in their email.
/// Public endpoint — no auth required. Security via HMAC verification.
pub async fn handle_click(
    State(state): State<AppState>,
    Path(token): Path<String>,
    axum::extract::ConnectInfo(addr): axum::extract::ConnectInfo<std::net::SocketAddr>,
) -> impl IntoResponse {
    let signer = CtaSigner::new(&state.config.cta_hmac_secret);

    // Verify HMAC — constant-time
    let payload = match signer.verify(&token) {
        Ok(p) => p,
        Err(e) => {
            tracing::warn!("Invalid CTA token: {}", e);
            return (StatusCode::BAD_REQUEST, "Invalid or expired link").into_response();
        }
    };

    // Idempotency: dedup via Redis (prevent double-counting rapid re-clicks)
    let dedup_key = format!("sn:cta:dedup:{}", Sha256::digest(token.as_bytes()).iter().map(|b| format!("{:02x}", b)).collect::<String>());
    let mut redis = state.redis.clone();
    let already: bool = redis.exists(&dedup_key).await.unwrap_or(false);
    if !already {
        let _: () = redis.set_ex(&dedup_key, "1", 86400).await.unwrap_or(());
    }

    // Hash IP for privacy (DESC/NESA PII)
    let ip_hash = format!("{:x}", Sha256::digest(addr.ip().to_string().as_bytes()));

    let signal_id = Uuid::new_v4().to_string();
    let clicked_at = Utc::now();

    // Record to PostgreSQL
    if !already {
        let _ = sqlx::query!(
            r#"
            INSERT INTO cta_signals
                (signal_id, run_id, job_id, tenant_id, button_label, button_key,
                 channel, ip_hash, clicked_at, idempotency_key)
            VALUES ($1,$2,$3,$4,$5,$6,'email',$7,$8,$9)
            ON CONFLICT (idempotency_key) DO NOTHING
            "#,
            signal_id,
            payload.run_id,
            payload.job_id,
            payload.tenant_id,
            payload.button_label,
            payload.button_key,
            ip_hash,
            clicked_at,
            dedup_key,
        )
        .execute(&state.db)
        .await;

        // Publish cta.clicked event
        let event = json!({
            "event": "cta.clicked",
            "signal_id": signal_id,
            "run_id":    payload.run_id,
            "job_id":    payload.job_id,
            "tenant_id": payload.tenant_id,
            "button_key":   payload.button_key,
            "button_label": payload.button_label,
            "clicked_at": clicked_at.to_rfc3339(),
        });
        let _ = publish_cta_clicked(&state.amqp, event).await;

        tracing::info!(
            run_id = %payload.run_id,
            button = %payload.button_key,
            "CTA click recorded"
        );
    }

    // Redirect to a thank-you page (configurable per tenant)
    let redirect_url = format!("{}/cta/thankyou?btn={}&already={}", state.config.cta_base_url, payload.button_key, already);
    Redirect::to(&redirect_url).into_response()
}

/// Generate signed CTA URLs for all buttons in a notification.
/// Called by channel adapters before inserting buttons into email HTML.
pub async fn generate_cta_urls(
    State(state): State<AppState>,
    Json(req): Json<GenerateCtaRequest>,
) -> Json<GenerateCtaResponse> {
    let signer = CtaSigner::new(&state.config.cta_hmac_secret);
    let mut buttons = Vec::new();

    for btn in &req.buttons {
        let payload = make_payload(
            &req.run_id, &req.job_id, &req.tenant_id,
            &btn.key, &btn.label,
            state.config.cta_url_ttl_hours,
        );
        let url = signer.build_url(&state.config.cta_base_url, &payload)
            .unwrap_or_else(|_| "#".to_string());
        buttons.push(CtaButtonWithUrl { label: btn.label.clone(), key: btn.key.clone(), url });
    }

    Json(GenerateCtaResponse { buttons })
}
