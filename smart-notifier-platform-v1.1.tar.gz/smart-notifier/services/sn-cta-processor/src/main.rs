//! Smart Notifier CTA Processor
//! - Generates HMAC-SHA256 signed CTA URLs for email buttons
//! - Handles click events (constant-time HMAC verification — DESC security)
//! - Records signals to PostgreSQL
//! - Publishes cta.clicked events to AMQP
//! - Deduplicates clicks via Redis

use std::{net::SocketAddr, sync::Arc};
use tokio::net::TcpListener;
use axum::{Router, routing::{get, post}, middleware as axum_mw};
use tower_http::{trace::TraceLayer, cors::{CorsLayer, Any}};
use tracing::info;

mod config;
mod hmac;
mod handlers;
mod models;
mod publisher;

use config::CtaConfig;

#[derive(Clone)]
pub struct AppState {
    pub config:  Arc<CtaConfig>,
    pub db:      sqlx::PgPool,
    pub redis:   redis::aio::ConnectionManager,
    pub amqp:    Arc<lapin::Channel>,
    pub http:    reqwest::Client,
}

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    dotenvy::dotenv().ok();
    tracing_subscriber::fmt().json().init();

    let cfg = CtaConfig::from_env()?;
    info!("sn-cta-processor starting");

    // PostgreSQL pool
    let db = sqlx::PgPool::connect(&cfg.database_url).await?;

    // Redis
    let redis_client = redis::Client::open(cfg.redis_url.clone())?;
    let redis = redis::aio::ConnectionManager::new(redis_client).await?;

    // AMQP
    let amqp_conn = lapin::Connection::connect(
        &cfg.rabbitmq_url,
        lapin::ConnectionProperties::default(),
    ).await?;
    let amqp_ch = Arc::new(amqp_conn.create_channel().await?);

    let state = AppState {
        config: Arc::new(cfg.clone()),
        db, redis,
        amqp: amqp_ch,
        http: reqwest::Client::new(),
    };

    let app = Router::new()
        // Public endpoints — no auth (recipients click from email)
        .route("/health",             get(handlers::health))
        .route("/cta/:token",         get(handlers::handle_click))
        // Internal endpoints — called by channel adapters
        .route("/cta/generate",       post(handlers::generate_cta_urls))
        .layer(TraceLayer::new_for_http())
        .layer(CorsLayer::new().allow_origin(Any).allow_methods(Any))
        .with_state(state);

    let addr: SocketAddr = format!("0.0.0.0:{}", cfg.port).parse()?;
    info!(addr = %addr, "CTA processor listening");
    axum::serve(TcpListener::bind(addr).await?, app).await?;
    Ok(())
}
