"""Outlook Channel Adapter Worker — mirrors sn-channel-gmail pattern."""
import asyncio, json, logging, os
from contextlib import asynccontextmanager
import uvicorn
from fastapi import FastAPI
import aio_pika
from .adapter import OutlookAdapter

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    task = asyncio.create_task(consume_loop())
    yield
    task.cancel()
    try: await task
    except asyncio.CancelledError: pass

app = FastAPI(title="sn-channel-outlook", version="1.0.0", lifespan=lifespan)

@app.get("/health")
async def health():
    return {"service": "sn-channel-outlook", "status": "healthy", "channel": "outlook"}

async def consume_loop():
    url = os.environ["RABBITMQ_URL"]
    while True:
        try:
            conn = await aio_pika.connect_robust(url)
            async with conn:
                ch = await conn.channel()
                await ch.set_qos(prefetch_count=int(os.getenv("WORKER_CONCURRENCY","2")))
                exchange = await ch.get_exchange("sn.events")
                queue = await ch.declare_queue("sn.channel.outlook", durable=True, passive=True)
                async with queue.iterator() as q:
                    async for msg in q:
                        async with msg.process(requeue=True):
                            await handle(msg.body, exchange)
        except Exception as e:
            logger.error("Outlook consumer error: %s", e)
            await asyncio.sleep(5)

async def handle(body: bytes, exchange):
    payload = json.loads(body)
    run_id, job_id, tenant_id = payload["run_id"], payload["job_id"], payload["tenant_id"]
    approval_mode = payload.get("job_config", {}).get("approval_mode", "manual")
    message = payload.get("message", {})
    adapter = OutlookAdapter(tenant_id)
    result = await adapter.draft(message) if approval_mode == "draft" else await adapter.send(message)
    routing_key = f"delivery.{result.get('status','failed').replace('_','-')}"
    event = {"event": routing_key, "run_id": run_id, "job_id": job_id,
             "tenant_id": tenant_id, "channel": "outlook", **result}
    await exchange.publish(
        aio_pika.Message(body=json.dumps(event).encode(), content_type="application/json",
                         delivery_mode=aio_pika.DeliveryMode.PERSISTENT),
        routing_key=routing_key,
    )

if __name__ == "__main__":
    uvicorn.run("src.main:app", host="0.0.0.0", port=8007)
