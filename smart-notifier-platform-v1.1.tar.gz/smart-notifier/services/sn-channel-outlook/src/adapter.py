"""
Outlook Channel Adapter — Microsoft Graph API
Credentials: MSAL client credentials from Vault at secret/channels/outlook/{tenant_id}
Supports: send (immediate), draft (save to Drafts folder), status
"""
from __future__ import annotations
import logging, json
from typing import Any
import httpx
import msal

logger = logging.getLogger(__name__)
GRAPH_BASE = "https://graph.microsoft.com/v1.0"


class OutlookAdapter:
    def __init__(self, tenant_id: str):
        self._sn_tenant_id = tenant_id  # our platform tenant, not MS tenant
        self._token: str | None = None

    async def _get_token(self) -> str:
        if self._token:
            return self._token
        creds = await self._load_credentials()
        authority = f"https://login.microsoftonline.com/{creds['ms_tenant_id']}"
        app = msal.ConfidentialClientApplication(
            creds["client_id"], authority=authority,
            client_credential=creds["client_secret"],
        )
        result = app.acquire_token_for_client(
            scopes=["https://graph.microsoft.com/.default"]
        )
        if "access_token" not in result:
            raise RuntimeError(f"MSAL error: {result.get('error_description')}")
        self._token = result["access_token"]
        return self._token

    async def _load_credentials(self) -> dict[str, Any]:
        import os, hvac
        client = hvac.Client(url=os.environ["VAULT_ADDR"], token=os.environ["VAULT_TOKEN"])
        response = client.secrets.kv.v2.read_secret_version(
            path=f"channels/outlook/{self._sn_tenant_id}", mount_point="secret"
        )
        return response["data"]["data"]

    def _build_message_body(self, message: dict[str, Any]) -> dict:
        return {
            "subject": message["subject"],
            "body": {"contentType": "HTML", "content": message["html_body"]},
            "toRecipients": [{"emailAddress": {"address": a.strip()}}
                             for a in message["to"].split(",") if a.strip()],
            "ccRecipients": [{"emailAddress": {"address": a.strip()}}
                             for a in message.get("cc", "").split(",") if a.strip()],
        }

    async def send(self, message: dict[str, Any]) -> dict[str, Any]:
        token = await self._get_token()
        body = {"message": self._build_message_body(message), "saveToSentItems": True}
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(
                f"{GRAPH_BASE}/me/sendMail",
                headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
                json=body,
            )
        if resp.status_code == 202:
            logger.info("Outlook sent to=%s", message["to"])
            return {"status": "sent", "provider": "outlook"}
        logger.error("Outlook send failed: %d %s", resp.status_code, resp.text)
        return {"status": "failed", "error": resp.text}

    async def draft(self, message: dict[str, Any]) -> dict[str, Any]:
        token = await self._get_token()
        body = self._build_message_body(message)
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(
                f"{GRAPH_BASE}/me/messages",
                headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
                json=body,
            )
        if resp.status_code == 201:
            data = resp.json()
            draft_id = data["id"]
            logger.info("Outlook draft saved: draftId=%s", draft_id)
            return {"draft_id": draft_id, "status": "draft_saved", "provider": "outlook"}
        return {"status": "failed", "error": resp.text}

    async def status(self, delivery_id: str) -> str:
        return "unknown"   # Graph API doesn't expose delivery receipts without premium licence
