import asyncio, json, logging, os
import aio_pika
from .adapter import OutlookAdapter, Message

logger = logging.getLogger(__name__)
adapter = OutlookAdapter()


async def run():
    url = os.environ["RABBITMQ_URL"]
    while True:
        try:
            conn = await aio_pika.connect_robust(url)
            async with conn:
                ch = await conn.channel()
                await ch.set_qos(prefetch_count=int(os.getenv("WORKER_CONCURRENCY","2")))
                exchange = await ch.get_exchange("sn.events")
                queue = await ch.declare_queue("sn.channel.outlook", durable=True, passive=True)
                async with queue.iterator() as q:
                    async for msg in q:
                        async with msg.process(requeue=True):
                            await handle(msg.body, exchange)
        except Exception as e:
            logger.error("Outlook worker error: %s", e)
            await asyncio.sleep(5)


async def handle(body: bytes, exchange):
    payload = json.loads(body)
    run_id = payload["run_id"]; job_id = payload["job_id"]; tenant_id = payload["tenant_id"]
    composed = payload.get("composed",{}); job_cfg = payload.get("job_config",{})
    recipients = job_cfg.get("recipients",{}); to = recipients.get("to","")

    msg = Message(
        run_id=run_id, job_id=job_id, tenant_id=tenant_id,
        to=[t.strip() for t in to.split(",") if t.strip()],
        cc=[c.strip() for c in recipients.get("cc","").split(",") if c.strip()],
        bcc=[], subject=composed.get("subject",""),
        html_body=composed.get("html_body",""), text_body=composed.get("text_body",""),
        cta_buttons=composed.get("cta_buttons",[]), attachments=[],
    )

    mode = job_cfg.get("approval_mode","manual")
    result = await adapter.draft(msg) if mode == "draft" else await adapter.send(msg)

    event = {"event": "delivery.sent" if result.status in ("sent","draft_saved") else "delivery.failed",
             "run_id":run_id,"job_id":job_id,"tenant_id":tenant_id,"channel":"outlook",
             "status":result.status,"provider_ref":result.provider_ref,"error":result.error}
    await exchange.publish(aio_pika.Message(body=json.dumps(event).encode(),
        content_type="application/json",delivery_mode=aio_pika.DeliveryMode.PERSISTENT),
        routing_key=event["event"])

if __name__ == "__main__":
    logging.basicConfig(level=os.getenv("LOG_LEVEL","INFO"))
    asyncio.run(run())
