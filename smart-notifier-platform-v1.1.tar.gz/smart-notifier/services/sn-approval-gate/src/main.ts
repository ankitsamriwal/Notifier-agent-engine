/**
 * Smart Notifier — Approval Gate Service
 * State machine: PENDING_REVIEW → APPROVED → DISPATCHED | REJECTED | MODIFIED → APPROVED
 * WebSocket: pushes real-time approval state changes to admin console
 * AMQP: consumes email.composed, produces dispatch.{channel} or approval events
 */
import Fastify from 'fastify'
import cors from '@fastify/cors'
import websocket from '@fastify/websocket'
import { PrismaClient } from '@prisma/client'
import amqplib from 'amqplib'
import { randomUUID } from 'crypto'
import { createHmac } from 'crypto'
import { z } from 'zod'

const PORT      = parseInt(process.env.PORT ?? '8006', 10)
const DB_URL    = process.env.DATABASE_URL!
const AMQP_URL  = process.env.RABBITMQ_URL!
const TOKEN_SECRET = process.env.APPROVAL_TOKEN_SECRET ?? 'dev-secret-min-32-chars-required!!'
const TTL_HOURS = parseInt(process.env.APPROVAL_TTL_HOURS ?? '48', 10)

const prisma = new PrismaClient({ log: ['error'] })
let amqpChannel: amqplib.Channel

// Connected WebSocket clients (admin console instances)
const wsClients = new Set<any>()

const app = Fastify({ logger: { level: process.env.LOG_LEVEL ?? 'info' }, trustProxy: true })

await app.register(cors, { origin: '*' })
await app.register(websocket)

// ── WebSocket endpoint ─────────────────────────────────────────────────────

app.register(async function wsPlugin(app) {
  app.get('/ws', { websocket: true }, (socket, req) => {
    wsClients.add(socket)
    socket.on('close', () => wsClients.delete(socket))
    socket.send(JSON.stringify({ type: 'connected', message: 'Approval gate WebSocket active' }))
  })
})

function broadcast(payload: object) {
  const msg = JSON.stringify(payload)
  wsClients.forEach(ws => { try { ws.send(msg) } catch {} })
}

// ── REST routes ────────────────────────────────────────────────────────────

app.get('/health', async () => ({
  service: 'sn-approval-gate', version: '1.0.0', status: 'healthy',
  ws_clients: wsClients.size,
}))

// GET /approvals — list pending for tenant
app.get('/approvals', async (req) => {
  const tenantId = req.headers['x-tenant-id'] as string
  const { status } = req.query as { status?: string }
  const rows = await prisma.$queryRaw<any[]>`
    SELECT a.*, r.job_id, r.channel, r.match_count, r.composed_subject
    FROM approvals a
    JOIN notification_runs r ON r.run_id = a.run_id::uuid
    WHERE a.tenant_id = ${tenantId}::uuid
      ${status ? prisma.$raw`AND a.status = ${status}` : prisma.$raw``}
    ORDER BY a.created_at DESC
    LIMIT 50`
  return { data: rows }
})

// GET /approvals/:runId — get approval detail with email preview
app.get('/approvals/:runId', async (req, reply) => {
  const { runId } = req.params as { runId: string }
  const tenantId  = req.headers['x-tenant-id'] as string
  const row = await prisma.$queryRaw<any[]>`
    SELECT a.*, r.composed_subject, r.composed_html, r.composed_text,
           r.recipient_to, r.recipient_cc, r.match_count, r.channel
    FROM approvals a
    JOIN notification_runs r ON r.run_id = a.run_id::uuid
    WHERE a.run_id = ${runId}::uuid AND a.tenant_id = ${tenantId}::uuid`
  if (!row.length) return reply.code(404).send({ error: 'not_found' })
  return row[0]
})

const ApproveSchema = z.object({ note: z.string().optional() })
const RejectSchema  = z.object({ reason: z.string().optional() })
const ModifySchema  = z.object({
  subject_override: z.string().optional(),
  html_override:    z.string().optional(),
  cc_override:      z.string().optional(),
})

// POST /approvals/:runId/approve
app.post('/approvals/:runId/approve', async (req, reply) => {
  const { runId }  = req.params as { runId: string }
  const tenantId   = req.headers['x-tenant-id'] as string
  const userId     = req.headers['x-user-id'] as string
  const body       = ApproveSchema.parse(req.body ?? {})

  const approval = await getApproval(runId, tenantId)
  if (!approval) return reply.code(404).send({ error: 'not_found' })
  if (approval.status === 'dispatched') return reply.code(409).send({ error: 'already_dispatched' })

  await prisma.$executeRaw`
    UPDATE approvals
    SET status = 'approved', reviewed_by = ${userId}::uuid, reviewed_at = NOW(), review_note = ${body.note ?? null}
    WHERE run_id = ${runId}::uuid AND tenant_id = ${tenantId}::uuid`

  // Publish dispatch event with any overrides applied
  await dispatchApproved(runId, tenantId, approval)
  broadcast({ type: 'approval.approved', run_id: runId, tenant_id: tenantId })
  return { run_id: runId, status: 'approved', dispatching: true }
})

// POST /approvals/:runId/reject
app.post('/approvals/:runId/reject', async (req, reply) => {
  const { runId }  = req.params as { runId: string }
  const tenantId   = req.headers['x-tenant-id'] as string
  const userId     = req.headers['x-user-id'] as string
  const body       = RejectSchema.parse(req.body ?? {})

  await prisma.$executeRaw`
    UPDATE approvals
    SET status = 'rejected', reviewed_by = ${userId}::uuid, reviewed_at = NOW(), review_note = ${body.reason ?? null}
    WHERE run_id = ${runId}::uuid AND tenant_id = ${tenantId}::uuid`

  // Publish rejected event for audit
  await publishEvent('approval.rejected', { run_id: runId, tenant_id: tenantId, reason: body.reason })
  broadcast({ type: 'approval.rejected', run_id: runId })
  return { run_id: runId, status: 'rejected' }
})

// PUT /approvals/:runId/modify — edit before approving
app.put('/approvals/:runId/modify', async (req, reply) => {
  const { runId }  = req.params as { runId: string }
  const tenantId   = req.headers['x-tenant-id'] as string
  const body       = ModifySchema.parse(req.body ?? {})

  await prisma.$executeRaw`
    UPDATE approvals
    SET status = 'modified',
        subject_override = ${body.subject_override ?? null},
        html_override    = ${body.html_override ?? null},
        cc_override      = ${body.cc_override ?? null},
        updated_at       = NOW()
    WHERE run_id = ${runId}::uuid AND tenant_id = ${tenantId}::uuid`

  broadcast({ type: 'approval.modified', run_id: runId })
  return { run_id: runId, status: 'modified', message: 'Modified — approve to dispatch' }
})

// GET /approvals/:runId/audit
app.get('/approvals/:runId/audit', async (req, reply) => {
  const { runId } = req.params as { runId: string }
  const tenantId  = req.headers['x-tenant-id'] as string
  const events = await prisma.$queryRaw<any[]>`
    SELECT * FROM audit_events
    WHERE resource_id = ${runId} AND tenant_id = ${tenantId}::uuid
    ORDER BY created_at ASC`
  return { data: events }
})

// Public: email-based approval via signed token (no JWT required)
app.get('/approve-email', async (req, reply) => {
  const { token, action } = req.query as { token: string; action: string }
  if (!token || !['approve','reject'].includes(action)) {
    return reply.code(400).send({ error: 'Invalid request' })
  }
  try {
    const payload = verifyApprovalToken(token)
    if (action === 'approve') {
      await prisma.$executeRaw`
        UPDATE approvals SET status = 'approved', reviewed_by = NULL, reviewed_at = NOW(), review_note = 'Approved via email link'
        WHERE run_id = ${payload.runId}::uuid`
      const approval = await getApproval(payload.runId, payload.tenantId)
      if (approval) await dispatchApproved(payload.runId, payload.tenantId, approval)
    } else {
      await prisma.$executeRaw`
        UPDATE approvals SET status = 'rejected', reviewed_at = NOW(), review_note = 'Rejected via email link'
        WHERE run_id = ${payload.runId}::uuid`
    }
    return reply.redirect(`${process.env.CTA_BASE_URL ?? 'http://localhost:4200'}/approval-confirmed?action=${action}`)
  } catch (e) {
    return reply.code(401).send({ error: 'Invalid or expired approval token' })
  }
})

// ── Helpers ────────────────────────────────────────────────────────────────

async function getApproval(runId: string, tenantId: string) {
  const rows = await prisma.$queryRaw<any[]>`
    SELECT a.*, r.composed_subject, r.composed_html, r.composed_text,
           r.composed_text as text_body, r.recipient_to, r.recipient_cc,
           r.channel, r.match_count, r.job_id
    FROM approvals a
    JOIN notification_runs r ON r.run_id = a.run_id::uuid
    WHERE a.run_id = ${runId}::uuid AND a.tenant_id = ${tenantId}::uuid`
  return rows[0] ?? null
}

async function dispatchApproved(runId: string, tenantId: string, approval: any) {
  const channel = approval.channel ?? 'gmail'
  const event = {
    event:         `dispatch.${channel}`,
    run_id:        runId,
    job_id:        approval.job_id,
    tenant_id:     tenantId,
    approval_mode: 'manual',
    channel,
    recipients: {
      to:  approval.cc_override ?? approval.recipient_to,
      cc:  approval.cc_override ?? approval.recipient_cc ?? '',
      bcc: '',
    },
    subject:   approval.subject_override ?? approval.composed_subject,
    html_body: approval.html_override    ?? approval.composed_html,
    text_body: approval.text_body,
  }
  await publishEvent(`dispatch.${channel}`, event)
  await prisma.$executeRaw`
    UPDATE approvals SET status = 'dispatched' WHERE run_id = ${runId}::uuid`
}

async function publishEvent(routingKey: string, payload: object) {
  if (!amqpChannel) return
  amqpChannel.publish(
    'sn.events', routingKey,
    Buffer.from(JSON.stringify(payload)),
    { persistent: true, contentType: 'application/json' },
  )
}

function verifyApprovalToken(token: string): { runId: string; tenantId: string } {
  const [payloadB64, sig] = token.split('.')
  const expected = createHmac('sha256', TOKEN_SECRET).update(payloadB64).digest('hex')
  if (expected !== sig) throw new Error('Invalid token')
  const payload = JSON.parse(Buffer.from(payloadB64, 'base64url').toString())
  if (payload.exp < Date.now() / 1000) throw new Error('Token expired')
  return payload
}

// ── AMQP consumer: email.composed ─────────────────────────────────────────

async function startConsumer() {
  const conn = await amqplib.connect(AMQP_URL)
  const ch   = await conn.createChannel()
  amqpChannel = ch
  await ch.assertExchange('sn.events', 'topic', { durable: true })
  const q = await ch.assertQueue('sn.approval.inbox', {
    durable: true,
    arguments: { 'x-dead-letter-exchange': 'sn.dlx' },
  })
  await ch.bindQueue(q.queue, 'sn.events', 'email.composed')
  ch.prefetch(4)
  ch.consume(q.queue, async (msg) => {
    if (!msg) return
    try {
      const payload = JSON.parse(msg.content.toString())
      await createApprovalRecord(payload)
      ch.ack(msg)
    } catch (e) {
      ch.nack(msg, false, false)  // send to DLQ
    }
  })
}

async function createApprovalRecord(payload: any) {
  const runId    = payload.run_id
  const tenantId = payload.tenant_id
  const approvalMode = payload.approval_mode ?? 'manual'

  // Update notification_runs with composed content
  await prisma.$executeRaw`
    UPDATE notification_runs
    SET composed_subject = ${payload.subject},
        composed_html    = ${payload.html_body},
        composed_text    = ${payload.text_body},
        composed_at      = NOW(),
        status           = 'pending_approval'
    WHERE run_id = ${runId}::uuid`

  const approvalId = randomUUID()
  const expiresAt  = new Date(Date.now() + TTL_HOURS * 3600 * 1000)

  // Generate email-based approval token
  const tokenPayload = Buffer.from(JSON.stringify({
    runId, tenantId, exp: expiresAt.getTime() / 1000
  })).toString('base64url')
  const sig   = createHmac('sha256', TOKEN_SECRET).update(tokenPayload).digest('hex')
  const token = `${tokenPayload}.${sig}`

  await prisma.$executeRaw`
    INSERT INTO approvals (approval_id, run_id, tenant_id, status, approval_token, expires_at)
    VALUES (${approvalId}::uuid, ${runId}::uuid, ${tenantId}::uuid, 'pending_review', ${token}, ${expiresAt})`

  broadcast({ type: 'approval.pending', run_id: runId, tenant_id: tenantId, approval_mode: approvalMode })
}

// ── Boot ───────────────────────────────────────────────────────────────────

await startConsumer()
await app.listen({ port: PORT, host: '0.0.0.0' })
app.log.info(`sn-approval-gate on :${PORT}`)
