export interface Config { port: number; logLevel: string; databaseUrl: string; rabbitmqUrl: string; otelEndpoint: string; approvalTokenSecret: string; approvalTtlHours: number }
export function getConfig(): Config {
  return {
    port:               parseInt(process.env.PORT ?? '8006', 10),
    logLevel:           process.env.LOG_LEVEL ?? 'info',
    databaseUrl:        process.env.DATABASE_URL!,
    rabbitmqUrl:        process.env.RABBITMQ_URL!,
    otelEndpoint:       process.env.OTEL_EXPORTER_OTLP_ENDPOINT ?? 'http://otel-collector:4317',
    approvalTokenSecret:process.env.APPROVAL_TOKEN_SECRET!,
    approvalTtlHours:   parseInt(process.env.APPROVAL_TTL_HOURS ?? '48', 10),
  }
}
