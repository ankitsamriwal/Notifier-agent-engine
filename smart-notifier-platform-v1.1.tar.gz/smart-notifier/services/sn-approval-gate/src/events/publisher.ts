import amqplib,{Channel,Connection} from 'amqplib'
export class AmqpPublisher {
  private conn:Connection|null=null; private ch:Channel|null=null
  constructor(private url:string){}
  async connect(){this.conn=await amqplib.connect(this.url);this.ch=await this.conn.createChannel();await this.ch.assertExchange('sn.events','topic',{durable:true})}
  async publish(e:string,rk:string,p:object){if(!this.ch)throw new Error('not connected');this.ch.publish(e,rk,Buffer.from(JSON.stringify(p)),{persistent:true,contentType:'application/json'})}
  async close(){await this.ch?.close();await this.conn?.close()}
}