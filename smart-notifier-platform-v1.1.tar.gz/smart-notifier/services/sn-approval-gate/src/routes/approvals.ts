import type{FastifyInstance}from 'fastify'
import{z}from 'zod'
import{transition,canTransition}from '../state_machine/approval'

export async function approvalRoutes(app:FastifyInstance):Promise<void>{
  app.get('/:runId',async(req,reply)=>{
    const{runId}=req.params as{runId:string}
    const tenantId=req.headers['x-tenant-id'] as string
    // @ts-ignore
    const a=await app.prisma.approvals.findFirst({where:{run_id:runId,tenant_id:tenantId}})
    if(!a)return reply.code(404).send({error:'not_found'})
    return a
  })
  app.post('/:runId/approve',async(req,reply)=>{
    const{runId}=req.params as{runId:string}
    const tenantId=req.headers['x-tenant-id'] as string
    const userId=req.headers['x-user-id'] as string
    const body=z.object({note:z.string().optional()}).parse(req.body??{})
    // @ts-ignore
    const a=await app.prisma.approvals.findFirst({where:{run_id:runId,tenant_id:tenantId}})
    if(!a)return reply.code(404).send({error:'not_found'})
    if(!canTransition(a.status as any,'approve'))return reply.code(409).send({error:'invalid_state'})
    const ns=transition(a.status as any,'approve')
    // @ts-ignore
    const u=await app.prisma.approvals.update({where:{approval_id:a.approval_id},data:{status:ns,reviewed_by:userId,reviewed_at:new Date(),review_note:body.note??null}})
    // @ts-ignore
    await app.amqp.publish('sn.events','approval.approved',{event:'approval.approved',run_id:runId,tenant_id:tenantId,actor_id:userId})
    return u
  })
  app.post('/:runId/reject',async(req,reply)=>{
    const{runId}=req.params as{runId:string}
    const tenantId=req.headers['x-tenant-id'] as string
    const userId=req.headers['x-user-id'] as string
    const body=z.object({reason:z.string().optional()}).parse(req.body??{})
    // @ts-ignore
    const a=await app.prisma.approvals.findFirst({where:{run_id:runId,tenant_id:tenantId}})
    if(!a)return reply.code(404).send({error:'not_found'})
    if(!canTransition(a.status as any,'reject'))return reply.code(409).send({error:'invalid_state'})
    const ns=transition(a.status as any,'reject')
    // @ts-ignore
    await app.prisma.approvals.update({where:{approval_id:a.approval_id},data:{status:ns,reviewed_by:userId,reviewed_at:new Date()}})
    // @ts-ignore
    await app.amqp.publish('sn.events','approval.rejected',{event:'approval.rejected',run_id:runId,tenant_id:tenantId,actor_id:userId,reason:body.reason})
    return{status:ns}
  })
  app.put('/:runId/modify',async(req,reply)=>{
    const{runId}=req.params as{runId:string}
    const tenantId=req.headers['x-tenant-id'] as string
    const body=z.object({subject_override:z.string().optional(),html_override:z.string().optional(),cc_override:z.string().optional()}).parse(req.body??{})
    // @ts-ignore
    const a=await app.prisma.approvals.findFirst({where:{run_id:runId,tenant_id:tenantId}})
    if(!a)return reply.code(404).send({error:'not_found'})
    if(!canTransition(a.status as any,'modify'))return reply.code(409).send({error:'invalid_state'})
    const ns=transition(a.status as any,'modify')
    // @ts-ignore
    return await app.prisma.approvals.update({where:{approval_id:a.approval_id},data:{status:ns,...body,updated_at:new Date()}})
  })
}