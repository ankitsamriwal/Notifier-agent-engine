import type{FastifyInstance}from 'fastify'
import{approvalRoutes}from './approvals'
export function registerRoutes(app:FastifyInstance):void{app.register(approvalRoutes,{prefix:'/approvals'})}