export type ApprovalStatus = 'pending_review'|'approved'|'rejected'|'modified'|'dispatched'|'expired'
export type ApprovalAction = 'approve'|'reject'|'modify'|'dispatch'|'expire'
const T: Record<ApprovalStatus, Partial<Record<ApprovalAction, ApprovalStatus>>> = {
  pending_review:{approve:'approved',reject:'rejected',modify:'modified',expire:'expired'},
  approved:{dispatch:'dispatched'},modified:{approve:'approved',reject:'rejected'},
  rejected:{},dispatched:{},expired:{}
}
export function transition(s: ApprovalStatus, a: ApprovalAction): ApprovalStatus {
  const n = T[s]?.[a]; if(!n) throw new Error(`Invalid: ${s} -> ${a}`); return n
}
export function canTransition(s: ApprovalStatus, a: ApprovalAction): boolean { return !!(T[s]?.[a]) }