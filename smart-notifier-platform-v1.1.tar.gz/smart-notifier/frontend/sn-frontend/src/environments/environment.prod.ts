export const environment = {
  production: true,
  apiUrl: window.location.origin,
  wsUrl: window.location.origin.replace('http','ws'),
}
