import { Component, ChangeDetectionStrategy } from '@angular/core'
import { RouterLink, RouterLinkActive } from '@angular/router'
import { CommonModule } from '@angular/common'

const NAV = [
  { label:'Dashboard',     icon:'grid',    path:'/dashboard' },
  { label:'Jobs',          icon:'briefcase',path:'/jobs' },
  { label:'Runs & log',   icon:'list',    path:'/runs' },
  { label:'Approvals',     icon:'check',   path:'/approvals' },
  { label:'Effectiveness', icon:'chart',   path:'/effectiveness' },
  { label:'Insights',      icon:'lightbulb',path:'/insights' },
  { label:'Channels',      icon:'mail',    path:'/channels' },
  { label:'Tenants',       icon:'users',   path:'/tenants' },
]

@Component({
  selector: 'sn-sidebar',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <aside class="sidebar" role="navigation" aria-label="Main navigation">
      <div class="sidebar__brand">
        <div class="brand-mark" aria-hidden="true"></div>
        <div class="brand-text">
          <span class="brand-name">Smart Notifier</span>
          <span class="brand-version">v1.0</span>
        </div>
      </div>

      <nav class="sidebar__nav">
        <span class="sidebar__section-label">Platform</span>
        @for (item of navItems; track item.path) {
          <a class="nav-item" [routerLink]="item.path" routerLinkActive="nav-item--active"
             [attr.aria-label]="item.label">
            <span class="nav-item__label">{{ item.label }}</span>
          </a>
        }
      </nav>

      <div class="sidebar__footer">
        <div class="tenant-badge">
          <div class="tenant-avatar">E</div>
          <div class="tenant-info">
            <span class="tenant-name">Emirates DC</span>
            <span class="tenant-role">operator</span>
          </div>
        </div>
      </div>
    </aside>
  `,
  styles: [`
    .sidebar {
      width: 220px; min-width: 220px;
      background: var(--sn-surface);
      border-right: 1px solid var(--sn-border);
      display: flex; flex-direction: column;
      height: 100vh; position: sticky; top: 0;
    }
    .sidebar__brand {
      padding: 16px; border-bottom: 1px solid var(--sn-border);
      display: flex; align-items: center; gap: 10px;
    }
    .brand-mark {
      width: 28px; height: 28px; border-radius: var(--sn-radius-md);
      background: var(--sn-blue); flex-shrink: 0;
    }
    .brand-name { font-size: 13px; font-weight: 600; color: var(--sn-text-primary); display:block; }
    .brand-version { font-size: 10px; color: var(--sn-text-tertiary); }
    .sidebar__nav { flex: 1; padding: 12px 8px; overflow-y: auto; }
    .sidebar__section-label {
      font-size: 10px; font-weight: 500; color: var(--sn-text-tertiary);
      text-transform: uppercase; letter-spacing: .05em;
      padding: 0 8px 6px; display: block;
    }
    .nav-item {
      display: flex; align-items: center; gap: 8px;
      padding: 8px 10px; border-radius: var(--sn-radius-md);
      font-size: 13px; color: var(--sn-text-secondary);
      border-left: 2px solid transparent;
      transition: background var(--sn-transition), color var(--sn-transition);
      margin-bottom: 2px;
    }
    .nav-item:hover { background: var(--sn-surface-3); color: var(--sn-text-primary); }
    .nav-item--active {
      background: var(--sn-blue-light); color: var(--sn-blue);
      border-left-color: var(--sn-blue); font-weight: 500;
    }
    .sidebar__footer {
      padding: 12px; border-top: 1px solid var(--sn-border);
    }
    .tenant-badge { display:flex; align-items:center; gap:8px; }
    .tenant-avatar {
      width:28px; height:28px; border-radius:50%;
      background:var(--sn-teal); color:#fff; font-size:12px; font-weight:600;
      display:flex; align-items:center; justify-content:center;
    }
    .tenant-name { font-size:12px; font-weight:500; color:var(--sn-text-primary); display:block; }
    .tenant-role { font-size:10px; color:var(--sn-text-tertiary); }
  `]
})
export class SidebarComponent {
  navItems = NAV
}
