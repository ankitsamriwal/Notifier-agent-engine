import { Component, Input, ChangeDetectionStrategy } from '@angular/core'
import { CommonModule } from '@angular/common'

@Component({
  selector: 'sn-topbar',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="topbar" role="banner">
      <h1 class="topbar__title">{{ title }}</h1>
      <div class="topbar__actions">
        <ng-content></ng-content>
      </div>
    </header>
  `,
  styles: [`
    .topbar {
      display: flex; align-items: center; justify-content: space-between;
      padding: 14px 24px; background: var(--sn-surface);
      border-bottom: 1px solid var(--sn-border);
      position: sticky; top: 0; z-index: 100;
    }
    .topbar__title { font-size: 16px; font-weight: 500; color: var(--sn-text-primary); }
    .topbar__actions { display: flex; align-items: center; gap: 10px; }
  `]
})
export class TopbarComponent { @Input() title = '' }
