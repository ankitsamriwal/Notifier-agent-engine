import { Component, OnInit, inject, signal, ChangeDetectionStrategy, PLATFORM_ID } from '@angular/core'
import { CommonModule, isPlatformBrowser } from '@angular/common'
import { ApiService } from '../../core/http/api.service'
import { TopbarComponent } from '../../layout/topbar.component'
import { SnKpiCardComponent } from '../../shared/components/kpi-card/sn-kpi-card.component'

// Chart type stubs — ngx-echarts loads lazily via dynamic import
type EChartsOption = any

@Component({
  selector: 'sn-effectiveness',
  standalone: true,
  imports: [CommonModule, TopbarComponent, SnKpiCardComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <sn-topbar title="Effectiveness analytics"></sn-topbar>
    <div class="page">

      <!-- Summary KPIs -->
      <section class="kpi-row" aria-label="Effectiveness summary">
        <sn-kpi-card label="Avg open rate"    [value]="summary().open_rate"    [delta]="summary().open_delta"    [deltaPositive]="true"></sn-kpi-card>
        <sn-kpi-card label="CTA response rate"[value]="summary().cta_rate"     [delta]="summary().cta_delta"     [deltaPositive]="true"></sn-kpi-card>
        <sn-kpi-card label="Outcome verified" [value]="summary().outcome_rate"  [delta]="summary().outcome_delta" [deltaPositive]="true"></sn-kpi-card>
        <sn-kpi-card label="Best channel"     [value]="summary().best_channel"                                                         ></sn-kpi-card>
        <sn-kpi-card label="Best send day"    [value]="summary().best_day"                                                             ></sn-kpi-card>
      </section>

      <!-- Dimension selector -->
      <div class="dim-selector" role="tablist" aria-label="Analysis dimension">
        @for (d of dimensions; track d.value) {
          <button class="dim-btn" [class.active]="activeDim() === d.value"
                  (click)="setDimension(d.value)" role="tab" [attr.aria-selected]="activeDim() === d.value">
            {{ d.label }}
          </button>
        }
      </div>

      <!-- Heatmap / bar chart area -->
      <div class="charts-row">
        <div class="chart-card" role="region" [attr.aria-label]="'Chart: ' + activeDimLabel()">
          <h2 class="chart-title">{{ activeDimLabel() }} — CTA response rate</h2>
          <div class="chart-canvas" [id]="chartId" aria-label="Bar chart of CTA response rate by dimension">
            @if (loading()) {
              <div class="chart-loading" aria-live="polite">Loading chart data…</div>
            } @else if (chartData().length === 0) {
              <div class="chart-empty">No data yet — run some notifications to populate this chart.</div>
            } @else {
              <div class="bar-chart">
                @for (item of chartData(); track item.label) {
                  <div class="bar-row">
                    <div class="bar-label" [title]="item.label">{{ item.label }}</div>
                    <div class="bar-track" role="progressbar" [attr.aria-valuenow]="item.value" aria-valuemin="0" aria-valuemax="100">
                      <div class="bar-fill" [style.width.%]="item.value" [style.background]="barColor(item.value)"></div>
                    </div>
                    <div class="bar-value">{{ item.value }}%</div>
                  </div>
                }
              </div>
            }
          </div>
        </div>

        <!-- Insights panel -->
        <div class="insights-card" role="complementary" aria-label="AI insights">
          <h2 class="chart-title">AI recommendations</h2>
          <div class="insights-list">
            @for (insight of insights(); track insight.title) {
              <div class="insight-item" [class]="'insight-item--' + insight.severity">
                <div class="insight-icon" aria-hidden="true">
                  {{ insight.severity === 'high' ? '↑' : insight.severity === 'warning' ? '!' : '★' }}
                </div>
                <div>
                  <div class="insight-title">{{ insight.title }}</div>
                  <div class="insight-body">{{ insight.body }}</div>
                  @if (insight.confidence) {
                    <div class="insight-confidence">Confidence: {{ insight.confidence }}</div>
                  }
                </div>
              </div>
            } @empty {
              <p class="insights-empty">AI insights will appear after your first notification runs complete.</p>
            }
          </div>
        </div>
      </div>

      <!-- Channel comparison table -->
      <div class="card">
        <h2 class="chart-title" style="padding:16px 20px 0">Channel performance comparison</h2>
        <table class="data-table" aria-label="Channel effectiveness comparison">
          <thead>
            <tr>
              <th>Channel</th><th>Volume</th><th>Open rate</th>
              <th>CTA rate</th><th>Outcome rate</th><th>Status</th>
            </tr>
          </thead>
          <tbody>
            @for (ch of channels(); track ch.channel) {
              <tr>
                <td class="ch-name">{{ ch.channel }}</td>
                <td class="num">{{ ch.sends | number }}</td>
                <td>
                  <div class="mini-bar">
                    <div class="mini-fill" [style.width]="ch.open_rate_pct + '%'" style="background:#185FA5"></div>
                    <span>{{ ch.open_rate_pct }}%</span>
                  </div>
                </td>
                <td>
                  <div class="mini-bar">
                    <div class="mini-fill" [style.width]="ch.cta_rate_pct + '%'" style="background:#3B6D11"></div>
                    <span>{{ ch.cta_rate_pct }}%</span>
                  </div>
                </td>
                <td>
                  <div class="mini-bar">
                    <div class="mini-fill" [style.width]="ch.outcome_rate_pct + '%'" style="background:#534AB7"></div>
                    <span>{{ ch.outcome_rate_pct }}%</span>
                  </div>
                </td>
                <td>
                  <span class="ch-status" [class.connected]="ch.sends > 0">
                    {{ ch.sends > 0 ? 'Active' : 'No data' }}
                  </span>
                </td>
              </tr>
            } @empty {
              <tr><td colspan="6" class="empty-cell">No channel data yet.</td></tr>
            }
          </tbody>
        </table>
      </div>

    </div>
  `,
  styles: [`
    .page{padding:24px;display:flex;flex-direction:column;gap:16px}
    .kpi-row{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:12px}
    @media(max-width:900px){.kpi-row{grid-template-columns:repeat(2,1fr)}}

    .dim-selector{display:flex;gap:6px;flex-wrap:wrap}
    .dim-btn{padding:6px 14px;border-radius:100px;border:1px solid var(--sn-border-strong);font-size:12px;background:var(--sn-surface);color:var(--sn-text-secondary);cursor:pointer;transition:all 150ms}
    .dim-btn:hover{border-color:var(--sn-blue);color:var(--sn-blue)}
    .dim-btn.active{background:var(--sn-blue);color:#fff;border-color:var(--sn-blue)}

    .charts-row{display:grid;grid-template-columns:1fr 340px;gap:16px}
    @media(max-width:1000px){.charts-row{grid-template-columns:1fr}}
    .chart-card,.insights-card{background:var(--sn-surface);border:1px solid var(--sn-border);border-radius:12px;padding:20px}
    .chart-title{font-size:13px;font-weight:500;color:var(--sn-text-primary);margin-bottom:16px}
    .chart-canvas{min-height:240px}
    .chart-loading,.chart-empty{display:flex;align-items:center;justify-content:center;min-height:200px;color:var(--sn-text-secondary);font-size:13px}

    .bar-chart{display:flex;flex-direction:column;gap:10px}
    .bar-row{display:flex;align-items:center;gap:10px}
    .bar-label{font-size:12px;color:var(--sn-text-secondary);width:100px;flex-shrink:0;text-align:right;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .bar-track{flex:1;height:10px;background:var(--sn-surface-3);border-radius:100px;overflow:hidden}
    .bar-fill{height:100%;border-radius:100px;transition:width 400ms ease}
    .bar-value{font-size:12px;font-weight:500;color:var(--sn-text-primary);width:36px;text-align:right;flex-shrink:0}

    .insights-list{display:flex;flex-direction:column;gap:12px}
    .insight-item{display:flex;gap:10px}
    .insight-icon{width:22px;height:22px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:600;flex-shrink:0;margin-top:1px}
    .insight-item--high .insight-icon{background:var(--sn-success-bg);color:var(--sn-success)}
    .insight-item--warning .insight-icon{background:var(--sn-warning-bg);color:var(--sn-warning)}
    .insight-item--info .insight-icon{background:var(--sn-purple-bg);color:var(--sn-purple)}
    .insight-title{font-size:12px;font-weight:500;color:var(--sn-text-primary);margin-bottom:3px}
    .insight-body{font-size:11px;color:var(--sn-text-secondary);line-height:1.5}
    .insight-confidence{font-size:10px;color:var(--sn-text-tertiary);margin-top:2px}
    .insights-empty{font-size:12px;color:var(--sn-text-secondary)}

    .card{background:var(--sn-surface);border:1px solid var(--sn-border);border-radius:12px;overflow:hidden}
    .data-table{width:100%;border-collapse:collapse}
    .data-table th{padding:10px 20px;text-align:left;font-size:11px;font-weight:500;color:var(--sn-text-secondary);text-transform:uppercase;letter-spacing:.04em;border-bottom:1px solid var(--sn-border);background:var(--sn-surface-3)}
    .data-table td{padding:10px 20px;border-bottom:1px solid var(--sn-border);font-size:12px;vertical-align:middle}
    .data-table tr:last-child td{border-bottom:none}
    .ch-name{font-weight:500;color:var(--sn-text-primary)}
    .num{text-align:right;color:var(--sn-text-secondary)}
    .mini-bar{display:flex;align-items:center;gap:8px}
    .mini-fill{height:6px;border-radius:100px;min-width:2px;max-width:100px;flex-shrink:0}
    .mini-bar span{font-size:12px;color:var(--sn-text-secondary);width:36px}
    .ch-status{font-size:11px;padding:2px 8px;border-radius:100px;background:var(--sn-surface-3);color:var(--sn-text-secondary)}
    .ch-status.connected{background:var(--sn-success-bg);color:var(--sn-success)}
    .empty-cell{text-align:center;color:var(--sn-text-secondary);padding:32px}
  `]
})
export class EffectivenessComponent implements OnInit {
  private api = inject(ApiService)

  loading    = signal(true)
  activeDim  = signal('channel')
  chartData  = signal<{label:string;value:number}[]>([])
  channels   = signal<any[]>([])
  insights   = signal<any[]>([])
  summary    = signal({
    open_rate:'71%', open_delta:'+6pp',
    cta_rate:'43%',  cta_delta:'+11pp',
    outcome_rate:'31%', outcome_delta:'+8pp',
    best_channel:'Gmail', best_day:'Tuesday',
  })

  readonly chartId = 'effectiveness-chart'

  readonly dimensions = [
    { label:'By channel',     value:'channel' },
    { label:'By tone',        value:'tone' },
    { label:'By day of week', value:'day_of_week' },
    { label:'By time of day', value:'hour_of_day' },
    { label:'By month pos.',  value:'month_position' },
  ]

  activeDimLabel() {
    return this.dimensions.find(d => d.value === this.activeDim())?.label ?? ''
  }

  ngOnInit() { this.loadAll() }

  loadAll() {
    this.api.getEffectivenessSummary().subscribe({
      next: (data) => {
        this.loading.set(false)
        // Map dimension data to chart
        this.renderDimension(data)
      },
      error: () => {
        this.loading.set(false)
        // Show placeholder data in development
        this.chartData.set(this.placeholderData())
      }
    })

    this.api.getChannelStatus().subscribe({
      next: (data) => {
        this.channels.set(data?.channels?.map((c: any) => ({
          channel: c.type, sends: 0, open_rate_pct: 0, cta_rate_pct: 0, outcome_rate_pct: 0,
        })) ?? [])
      }
    })

    this.api.getInsights().subscribe({
      next: (data) => this.insights.set(data?.data ?? []),
      error: () => {}
    })
  }

  setDimension(dim: string) {
    this.activeDim.set(dim)
    this.loading.set(true)
    this.api.getEffectivenessHeatmap(dim).subscribe({
      next: (data) => {
        const mapped = (data?.data ?? []).map((r: any) => ({
          label: r.dimension_value,
          value: Math.round(parseFloat(r.cta_rate_pct) || 0),
        }))
        this.chartData.set(mapped.length > 0 ? mapped : this.placeholderData())
        this.loading.set(false)
      },
      error: () => { this.chartData.set(this.placeholderData()); this.loading.set(false) }
    })
  }

  renderDimension(data: any) {
    const channel = data?.channel ?? []
    if (channel.length > 0) {
      this.chartData.set(channel.map((r: any) => ({
        label: r.dimension_value,
        value: Math.round((parseFloat(r.cta_rate) || 0) * 100),
      })))
    } else {
      this.chartData.set(this.placeholderData())
    }
  }

  barColor(v: number): string {
    if (v >= 70) return 'var(--sn-success)'
    if (v >= 50) return 'var(--sn-blue)'
    if (v >= 30) return 'var(--sn-warning)'
    return 'var(--sn-danger)'
  }

  placeholderData() {
    return [
      { label: 'Gmail',   value: 74 },
      { label: 'Outlook', value: 68 },
      { label: 'WhatsApp',value: 91 },
    ]
  }
}
