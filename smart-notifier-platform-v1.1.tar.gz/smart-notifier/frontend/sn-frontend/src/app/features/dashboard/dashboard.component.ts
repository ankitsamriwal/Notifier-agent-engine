import { Component, OnInit, inject, signal, ChangeDetectionStrategy } from '@angular/core'
import { CommonModule } from '@angular/common'
import { forkJoin } from 'rxjs'
import { ApiService } from '../../core/http/api.service'
import { TopbarComponent } from '../../layout/topbar.component'
import { SnKpiCardComponent } from '../../shared/components/kpi-card/sn-kpi-card.component'
import { SnBadgeComponent } from '../../shared/components/badge/sn-badge.component'

@Component({
  selector: 'sn-dashboard',
  standalone: true,
  imports: [CommonModule, TopbarComponent, SnKpiCardComponent, SnBadgeComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <sn-topbar title="Dashboard"></sn-topbar>
    <div class="page">

      @if (loading()) {
        <div class="loading" aria-live="polite">Loading dashboard data…</div>
      } @else {
        <!-- KPI row -->
        <section class="kpi-row" aria-label="Key performance indicators">
          <sn-kpi-card label="Total sent"        [value]="kpis().total_sent"       delta="+18%" [deltaPositive]="true"></sn-kpi-card>
          <sn-kpi-card label="Delivery rate"     [value]="kpis().delivery_rate"    delta="+0.4pp" [deltaPositive]="true"></sn-kpi-card>
          <sn-kpi-card label="Active jobs"       [value]="kpis().active_jobs"                                         ></sn-kpi-card>
          <sn-kpi-card label="CTA response rate" [value]="kpis().cta_rate"         delta="+11pp" [deltaPositive]="true"></sn-kpi-card>
          <sn-kpi-card label="Pending approvals" [value]="kpis().pending_approvals" delta="Action required" [deltaPositive]="false"></sn-kpi-card>
        </section>

        <!-- Recent runs -->
        <section class="section" aria-label="Recent notification runs">
          <h2 class="section__title">Recent runs</h2>
          <div class="run-list">
            @for (run of runs(); track run.run_id) {
              <div class="run-row">
                <sn-badge [variant]="runBadge(run.status)">{{ run.status }}</sn-badge>
                <span class="run-channel">{{ run.channel }}</span>
                <span class="run-matches">{{ run.match_count }} records</span>
                <span class="run-time">{{ run.triggered_at | date:'d MMM HH:mm' }}</span>
              </div>
            } @empty {
              <p class="empty">No runs yet — trigger a job to get started.</p>
            }
          </div>
        </section>

        <!-- Channels -->
        <section class="section" aria-label="Channel status">
          <h2 class="section__title">Channels</h2>
          <div class="channel-list">
            @for (ch of channels(); track ch.type) {
              <div class="channel-card">
                <span class="channel-name">{{ ch.type }}</span>
                <sn-badge [variant]="ch.status === 'connected' ? 'success' : 'neutral'">{{ ch.status }}</sn-badge>
                <span class="channel-phase">Phase {{ ch.phase }}</span>
              </div>
            }
          </div>
        </section>
      }
    </div>
  `,
  styles: [`
    .page { padding: var(--sn-space-6); display: flex; flex-direction: column; gap: var(--sn-space-6); }
    .kpi-row { display: grid; grid-template-columns: repeat(5, minmax(0,1fr)); gap: var(--sn-space-4); }
    .loading { padding: 40px; text-align: center; color: var(--sn-text-secondary); font-size: 13px; }
    .section { background: var(--sn-surface); border: 1px solid var(--sn-border); border-radius: var(--sn-radius-lg); padding: var(--sn-space-6); }
    .section__title { font-size: 13px; font-weight: 500; margin-bottom: var(--sn-space-4); }
    .run-row { display:flex; align-items:center; gap:12px; padding:9px 0; border-bottom:1px solid var(--sn-border); font-size:12px; }
    .run-row:last-child { border-bottom:none; }
    .run-channel { color:var(--sn-text-secondary); }
    .run-matches { color:var(--sn-text-secondary); margin-left:auto; }
    .run-time { color:var(--sn-text-tertiary); }
    .channel-list { display:flex; flex-direction:column; gap:8px; }
    .channel-card { display:flex; align-items:center; gap:10px; padding:8px 0; border-bottom:1px solid var(--sn-border); font-size:12px; }
    .channel-card:last-child { border-bottom:none; }
    .channel-name { font-weight:500; color:var(--sn-text-primary); width:80px; }
    .channel-phase { color:var(--sn-text-tertiary); margin-left:auto; }
    .empty { font-size:12px; color:var(--sn-text-tertiary); padding:16px 0; }
    @media (max-width: 900px) { .kpi-row { grid-template-columns: repeat(2, 1fr); } }
  `]
})
export class DashboardComponent implements OnInit {
  private api = inject(ApiService)

  loading = signal(true)
  kpis    = signal<any>({ total_sent:0, delivery_rate:'0%', active_jobs:0, cta_rate:'0%', pending_approvals:0 })
  runs    = signal<any[]>([])
  channels= signal<any[]>([])

  ngOnInit() {
    forkJoin([
      this.api.getDashboardKpis(),
      this.api.listRuns(undefined, undefined),
      this.api.getChannelStatus(),
    ]).subscribe({
      next: ([kpis, runsResp, chResp]) => {
        this.kpis.set(kpis)
        this.runs.set((runsResp?.data ?? []).slice(0, 8))
        this.channels.set(chResp?.channels ?? [])
        this.loading.set(false)
      },
      error: () => {
        // Graceful fallback — show empty state
        this.loading.set(false)
      }
    })
  }

  runBadge(status: string) {
    const map: Record<string, any> = {
      sent:'success', draft_saved:'info', failed:'danger',
      skipped:'neutral', pending_approval:'warning', rejected:'danger', approved:'purple'
    }
    return map[status] ?? 'neutral'
  }
}
