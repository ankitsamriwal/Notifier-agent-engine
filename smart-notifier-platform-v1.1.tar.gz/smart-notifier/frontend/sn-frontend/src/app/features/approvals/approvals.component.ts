import { Component, OnInit, inject, signal, ChangeDetectionStrategy } from '@angular/core'
import { CommonModule } from '@angular/common'
import { ApiService } from '../../core/http/api.service'
import { TopbarComponent } from '../../layout/topbar.component'
import { SnBadgeComponent } from '../../shared/components/badge/sn-badge.component'
import { SnButtonComponent } from '../../shared/components/button/sn-button.component'

@Component({
  selector: 'sn-approvals',
  standalone: true,
  imports: [CommonModule, TopbarComponent, SnBadgeComponent, SnButtonComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <sn-topbar title="Approval queue"></sn-topbar>
    <div class="page">

      @if (loading()) {
        <p class="loading" aria-live="polite">Loading approvals…</p>
      } @else if (approvals().length === 0) {
        <div class="empty-card">
          <svg width="40" height="40" viewBox="0 0 40 40" fill="none" stroke="var(--sn-border-strong)" stroke-width="1.5" aria-hidden="true">
            <circle cx="20" cy="20" r="16"/><path d="M14 20l4 4 8-8"/>
          </svg>
          <p>No approvals pending. All notifications are up to date.</p>
        </div>
      } @else {
        @for (a of approvals(); track a.approval_id) {
          <article class="approval-card" [attr.aria-label]="'Approval for run ' + a.run_id">
            <div class="approval-header">
              <div>
                <span class="approval-subject">{{ a.composed_subject ?? 'No subject' }}</span>
                <span class="approval-meta">Run {{ a.run_id.slice(0,8) }} · {{ a.channel }} · expires {{ a.expires_at | date:'d MMM HH:mm' }}</span>
              </div>
              <sn-badge [variant]="a.status === 'pending_review' ? 'warning' : 'neutral'">
                {{ a.status }}
              </sn-badge>
            </div>

            @if (a.status === 'pending_review') {
              <div class="approval-actions">
                <button snButton variant="success" size="sm" (click)="approve(a)">Approve & send</button>
                <button snButton variant="secondary" size="sm" (click)="saveDraft(a)">Save draft</button>
                <button snButton variant="danger" size="sm" (click)="reject(a)">Reject</button>
              </div>
            }
          </article>
        }
      }
    </div>
  `,
  styles: [`
    .page { padding:var(--sn-space-6); display:flex; flex-direction:column; gap:var(--sn-space-4); }
    .loading { color:var(--sn-text-secondary); font-size:13px; }
    .empty-card { background:var(--sn-surface); border:1px solid var(--sn-border); border-radius:var(--sn-radius-lg);
      padding:48px; text-align:center; display:flex; flex-direction:column; align-items:center; gap:12px; }
    .empty-card p { color:var(--sn-text-secondary); font-size:13px; }
    .approval-card { background:var(--sn-surface); border:1px solid var(--sn-border); border-radius:var(--sn-radius-lg); padding:var(--sn-space-5); }
    .approval-header { display:flex; align-items:flex-start; justify-content:space-between; gap:12px; margin-bottom:12px; }
    .approval-subject { font-size:14px; font-weight:500; color:var(--sn-text-primary); display:block; margin-bottom:4px; }
    .approval-meta { font-size:11px; color:var(--sn-text-secondary); display:block; }
    .approval-actions { display:flex; gap:8px; }
  `]
})
export class ApprovalsComponent implements OnInit {
  private api = inject(ApiService)
  loading    = signal(true)
  approvals  = signal<any[]>([])

  ngOnInit() { this.load() }

  load() {
    this.api.listApprovals('pending_review').subscribe({
      next: (r) => { this.approvals.set(r.data ?? []); this.loading.set(false) },
      error: () => this.loading.set(false)
    })
  }

  approve(a: any) {
    this.api.approveRun(a.run_id).subscribe(() => this.load())
  }

  saveDraft(a: any) {
    // Modify approval_mode to draft, then approve
    this.api.modifyApproval(a.run_id, { approval_mode: 'draft' }).subscribe(() => this.load())
  }

  reject(a: any) {
    const reason = prompt('Reason for rejection (optional):') ?? ''
    this.api.rejectRun(a.run_id, reason).subscribe(() => this.load())
  }
}
