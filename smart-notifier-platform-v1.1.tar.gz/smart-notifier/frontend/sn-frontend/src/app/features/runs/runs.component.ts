import { Component, OnInit, inject, signal, ChangeDetectionStrategy } from '@angular/core'
import { CommonModule } from '@angular/common'
import { ApiService } from '../../core/http/api.service'
import { TopbarComponent } from '../../layout/topbar.component'
import { SnBadgeComponent } from '../../shared/components/badge/sn-badge.component'
import type { NotificationRun } from '../../core/models/run.model'

@Component({
  selector: 'sn-runs',
  standalone: true,
  imports: [CommonModule, TopbarComponent, SnBadgeComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <sn-topbar title="Notification log"></sn-topbar>
    <div class="page">
      <div class="card">
        <table class="data-table" aria-label="Notification run history">
          <thead>
            <tr>
              <th scope="col">Run ID</th>
              <th scope="col">Status</th>
              <th scope="col">Channel</th>
              <th scope="col">Matches</th>
              <th scope="col">Triggered</th>
              <th scope="col">Completed</th>
            </tr>
          </thead>
          <tbody>
            @for (run of runs(); track run.run_id) {
              <tr>
                <td class="mono">{{ run.run_id.slice(0,12) }}…</td>
                <td><sn-badge [variant]="badge(run.status)">{{ run.status }}</sn-badge></td>
                <td>{{ run.channel }}</td>
                <td class="num">{{ run.match_count }}</td>
                <td class="date">{{ run.triggered_at | date:'d MMM HH:mm' }}</td>
                <td class="date">{{ run.completed_at ? (run.completed_at | date:'d MMM HH:mm') : '—' }}</td>
              </tr>
            } @empty {
              <tr><td colspan="6" class="empty">No runs recorded yet.</td></tr>
            }
          </tbody>
        </table>
      </div>
    </div>
  `,
  styles: [`
    .page{padding:var(--sn-space-6)}
    .card{background:var(--sn-surface);border:1px solid var(--sn-border);border-radius:var(--sn-radius-lg);overflow:hidden}
    .data-table{width:100%;border-collapse:collapse}
    .data-table th{padding:10px 14px;text-align:left;font-size:11px;font-weight:500;color:var(--sn-text-secondary);text-transform:uppercase;letter-spacing:.04em;border-bottom:1px solid var(--sn-border);background:var(--sn-surface-3)}
    .data-table td{padding:10px 14px;border-bottom:1px solid var(--sn-border);font-size:12px;vertical-align:middle}
    .data-table tr:last-child td{border-bottom:none}
    .mono{font-family:var(--sn-font-mono);font-size:11px;color:var(--sn-text-secondary)}
    .num{text-align:right;color:var(--sn-text-secondary)}
    .date{color:var(--sn-text-tertiary);white-space:nowrap}
    .empty{text-align:center;color:var(--sn-text-secondary);padding:32px}
  `]
})
export class RunsComponent implements OnInit {
  private api = inject(ApiService)
  runs = signal<NotificationRun[]>([])

  ngOnInit() {
    this.api.listRuns().subscribe(r => this.runs.set(r.data ?? []))
  }

  badge(status: string) {
    const m: Record<string,any> = {
      sent:'success', draft_saved:'info', failed:'danger',
      skipped:'neutral', pending_approval:'warning', rejected:'danger',
    }
    return m[status] ?? 'neutral'
  }
}
