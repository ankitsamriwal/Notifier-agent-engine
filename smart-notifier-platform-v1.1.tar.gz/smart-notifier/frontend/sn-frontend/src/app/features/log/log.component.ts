import { Component, OnInit, inject, signal, ChangeDetectionStrategy } from '@angular/core'
import { CommonModule } from '@angular/common'
import { ApiService } from '../../core/services/api.service'
import { SnBadgeComponent } from '../../shared/ui/badge/sn-badge.component'
import { SnSpinnerComponent } from '../../shared/ui/spinner/sn-spinner.component'

interface NotificationRun {
  run_id: string; job_id: string; status: string; channel: string
  match_count: number; trigger_type: string; triggered_at: string; recipient_to: string
}

@Component({
  selector: 'sn-log', standalone: true,
  imports: [CommonModule, SnBadgeComponent, SnSpinnerComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="log-page">
      <div class="log-header">
        <h1>Notification run log</h1>
        <p class="subtitle">Full history of all notification runs across all jobs.</p>
      </div>
      <sn-spinner *ngIf="loading()" size="lg"/>
      <div *ngIf="!loading()" class="log-table">
        <div class="log-table__header">
          <span>Status</span><span>Job</span><span>Channel</span><span>To</span><span>Matched</span><span>Triggered</span>
        </div>
        <div *ngFor="let run of runs()" class="log-row">
          <sn-badge [variant]="statusVariant(run.status)">{{run.status}}</sn-badge>
          <span class="log-row__id">{{run.job_id | slice:0:8}}...</span>
          <sn-badge [variant]="channelVariant(run.channel)">{{run.channel}}</sn-badge>
          <span class="log-row__to">{{run.recipient_to}}</span>
          <span>{{run.match_count}}</span>
          <span class="log-row__time">{{run.triggered_at | date:'short'}}</span>
        </div>
        <div *ngIf="runs().length === 0" class="log-empty">No runs yet — trigger a job to see it here.</div>
      </div>
    </div>`,
  styles: [`
    .log-page { padding: 24px; }
    .log-header { margin-bottom: 20px; }
    h1 { font-size: 22px; font-weight: 600; color: var(--sn-navy); }
    .subtitle { font-size: 13px; color: var(--sn-text-secondary); margin-top: 4px; }
    .log-table { background: var(--sn-white); border: 1px solid var(--sn-border); border-radius: var(--sn-radius-lg); overflow: hidden; }
    .log-table__header { display: grid; grid-template-columns: 100px 1fr 100px 200px 80px 140px; gap: 12px; padding: 10px 16px; background: var(--sn-offwhite); font-size: 11px; font-weight: 500; color: var(--sn-text-secondary); text-transform: uppercase; letter-spacing: .04em; }
    .log-row { display: grid; grid-template-columns: 100px 1fr 100px 200px 80px 140px; gap: 12px; padding: 11px 16px; border-top: 1px solid var(--sn-border); align-items: center; font-size: 12px; }
    .log-row:hover { background: var(--sn-offwhite); }
    .log-row__id { font-family: var(--sn-font-mono); color: var(--sn-text-secondary); font-size: 11px; }
    .log-row__to { color: var(--sn-text-secondary); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .log-row__time { color: var(--sn-text-muted); }
    .log-empty { padding: 32px; text-align: center; color: var(--sn-text-secondary); }
  `],
})
export class LogComponent implements OnInit {
  private api = inject(ApiService)
  loading = signal(true)
  runs = signal<NotificationRun[]>([])

  ngOnInit() {
    this.api.get<{ data: NotificationRun[] }>('/api/v1/runs').subscribe(
      r => { this.runs.set(r.data); this.loading.set(false) },
      () => this.loading.set(false)
    )
  }

  statusVariant(s: string): any {
    return { sent: 'success', draft_saved: 'info', failed: 'danger', skipped: 'default', triggered: 'warning' }[s] ?? 'default'
  }
  channelVariant(ch: string): any {
    return { gmail: 'danger', outlook: 'primary', whatsapp: 'success' }[ch] ?? 'default'
  }
}
