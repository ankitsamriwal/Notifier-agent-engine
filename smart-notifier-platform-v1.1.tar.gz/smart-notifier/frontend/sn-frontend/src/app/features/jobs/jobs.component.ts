import { Component, OnInit, inject, ChangeDetectionStrategy, effect } from '@angular/core'
import { CommonModule } from '@angular/common'
import { TopbarComponent } from '../../layout/topbar.component'
import { SnBadgeComponent } from '../../shared/components/badge/sn-badge.component'
import { SnButtonComponent } from '../../shared/components/button/sn-button.component'
import { JobFormComponent } from '../../shared/components/job-form/job-form.component'
import { JobsStore } from '../../core/stores/jobs.store'
import { ToastService } from '../../shared/components/toast/sn-toast.component'
import type { Job } from '../../core/models/job.model'

@Component({
  selector: 'sn-jobs',
  standalone: true,
  imports: [CommonModule, TopbarComponent, SnBadgeComponent, SnButtonComponent, JobFormComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <sn-topbar title="Notification jobs">
      <button snButton variant="primary" size="sm" (click)="store.openDrawer()">+ New job</button>
    </sn-topbar>

    <div class="page">
      <!-- Filters -->
      <div class="filters" role="tablist">
        @for (f of filters; track f.value) {
          <button class="filter-pill" [class.active]="store.filter() === f.value"
                  (click)="applyFilter(f.value)" role="tab">
            {{ f.label }}
            @if (f.value === 'active') {
              <span class="badge-count">{{ store.activeCount() }}</span>
            }
          </button>
        }
      </div>

      @if (store.error()) {
        <div class="error-banner" role="alert">{{ store.error() }}</div>
      }

      <!-- Table -->
      <div class="card">
        @if (store.loading()) {
          <div class="loading">Loading jobs…</div>
        } @else if (store.filteredJobs().length === 0) {
          <div class="empty-state">
            <p>No jobs found. Create your first notification job.</p>
            <button snButton variant="primary" (click)="store.openDrawer()">+ New job</button>
          </div>
        } @else {
          <table class="data-table">
            <thead>
              <tr>
                <th>Job name</th><th>Status</th><th>Channel</th>
                <th>Tone</th><th>Approval</th><th>Runs</th><th>Last run</th>
                <th><span class="sr-only">Actions</span></th>
              </tr>
            </thead>
            <tbody>
              @for (job of store.filteredJobs(); track job.job_id) {
                <tr (click)="selectJob(job)" [class.selected]="store.selectedJob()?.job_id === job.job_id">
                  <td class="name-cell">
                    <span class="name">{{ job.name }}</span>
                    <span class="desc">{{ job.description }}</span>
                  </td>
                  <td><sn-badge [variant]="statusBadge(job.status)">{{ job.status }}</sn-badge></td>
                  <td><sn-badge variant="neutral">{{ job.channel }}</sn-badge></td>
                  <td class="muted">{{ job.tone }}</td>
                  <td class="muted">{{ job.approval_mode }}</td>
                  <td class="num">{{ job.run_count }}</td>
                  <td class="date">{{ job.last_run_at ? (job.last_run_at | date:'d MMM HH:mm') : '—' }}</td>
                  <td class="actions" (click)="$event.stopPropagation()">
                    <button snButton variant="ghost" size="sm" (click)="trigger(job)" title="Trigger now">▶</button>
                    <button snButton variant="ghost" size="sm" (click)="clone(job)" title="Clone">⎘</button>
                    <button snButton variant="ghost" size="sm" (click)="remove(job)" title="Delete">✕</button>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        }
      </div>
    </div>

    <!-- Job form drawer -->
    <sn-job-form
      [open]="store.drawerOpen()"
      [job]="store.selectedJob()"
      (closed)="store.closeDrawer()"
      (saved)="onSaved($event)">
    </sn-job-form>
  `,
  styles: [`
    .page{padding:24px;display:flex;flex-direction:column;gap:14px}
    .filters{display:flex;gap:6px;flex-wrap:wrap}
    .filter-pill{padding:5px 12px;border-radius:100px;border:1px solid var(--sn-border-strong);font-size:12px;background:var(--sn-surface);color:var(--sn-text-secondary);cursor:pointer;transition:all 150ms;display:flex;align-items:center;gap:5px}
    .filter-pill:hover{border-color:var(--sn-blue);color:var(--sn-blue)}
    .filter-pill.active{background:var(--sn-blue);color:#fff;border-color:var(--sn-blue)}
    .badge-count{background:rgba(255,255,255,0.25);border-radius:100px;padding:1px 6px;font-size:10px}
    .card{background:var(--sn-surface);border:1px solid var(--sn-border);border-radius:12px;overflow:hidden}
    .loading,.empty-state{padding:40px;text-align:center;color:var(--sn-text-secondary);font-size:13px}
    .empty-state{display:flex;flex-direction:column;align-items:center;gap:14px}
    .data-table{width:100%;border-collapse:collapse}
    .data-table th{padding:10px 14px;text-align:left;font-size:11px;font-weight:500;color:var(--sn-text-secondary);text-transform:uppercase;letter-spacing:.04em;border-bottom:1px solid var(--sn-border);background:var(--sn-surface-3)}
    .data-table td{padding:11px 14px;border-bottom:1px solid var(--sn-border);font-size:12px;vertical-align:middle;cursor:pointer}
    .data-table tr:last-child td{border-bottom:none}
    .data-table tr:hover td{background:var(--sn-surface-3)}
    .data-table tr.selected td{background:var(--sn-blue-light)}
    .name-cell{max-width:260px}
    .name{font-weight:500;color:var(--sn-text-primary);display:block}
    .desc{color:var(--sn-text-secondary);font-size:11px;display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:240px}
    .muted{color:var(--sn-text-secondary)}
    .num{text-align:right;color:var(--sn-text-secondary)}
    .date{color:var(--sn-text-tertiary);white-space:nowrap}
    .actions{display:flex;gap:4px}
    .error-banner{background:var(--sn-danger-bg);color:var(--sn-danger);padding:10px 14px;border-radius:8px;font-size:12px}
  `]
})
export class JobsComponent implements OnInit {
  store = inject(JobsStore)
  toast = inject(ToastService)

  filters = [
    { label: 'All',    value: '' },
    { label: 'Active', value: 'active' },
    { label: 'Draft',  value: 'draft' },
    { label: 'Paused', value: 'paused' },
  ]

  ngOnInit() { this.store.loadJobs(undefined) }

  applyFilter(f: string) {
    this.store.setFilter(f)
    this.store.loadJobs(f || undefined)
  }

  selectJob(job: Job) { this.store.selectJob(job) }

  trigger(job: Job) {
    this.store.triggerJob(job.job_id)
    this.toast.success(`Job triggered: ${job.name}`)
  }

  clone(job: Job) {
    this.store.cloneJob(job.job_id)
    this.toast.info(`Cloned: ${job.name}`)
  }

  remove(job: Job) {
    if (!confirm(`Delete "${job.name}"?`)) return
    this.store.deleteJob(job.job_id)
    this.toast.success('Job deleted')
  }

  onSaved(job: Job) {
    this.store.closeDrawer()
    this.store.loadJobs(this.store.filter() || undefined)
    this.toast.success(`Job saved: ${job.name}`)
  }

  statusBadge(s: string) {
    return s === 'active' ? 'success' : s === 'paused' ? 'warning' : 'neutral'
  }
}
