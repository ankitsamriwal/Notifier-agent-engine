import { HttpInterceptorFn, HttpRequest, HttpHandlerFn } from '@angular/common/http'
import { inject } from '@angular/core'
import { AuthService } from '../auth/auth.service'

export const authInterceptor: HttpInterceptorFn = (
  req: HttpRequest<unknown>,
  next: HttpHandlerFn
) => {
  const auth = inject(AuthService)
  const token = auth.getToken()

  if (token) {
    const cloned = req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`,
        'X-Correlation-Id': generateCorrelationId(),
      }
    })
    return next(cloned)
  }
  return next(req)
}

function generateCorrelationId(): string {
  return `sn-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`
}
