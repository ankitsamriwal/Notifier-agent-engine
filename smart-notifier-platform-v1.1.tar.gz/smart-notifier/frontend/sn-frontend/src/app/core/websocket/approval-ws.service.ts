import { Injectable, OnDestroy, signal } from '@angular/core'
import { Subject } from 'rxjs'
import { environment } from '../../../environments/environment'

export interface WsEvent {
  type: string
  run_id?: string
  job_id?: string
  subject?: string
  match_count?: number
  expires_at?: string
  approved_by?: string
}

@Injectable({ providedIn: 'root' })
export class ApprovalWebSocketService implements OnDestroy {
  private ws: WebSocket | null = null
  private readonly _events$ = new Subject<WsEvent>()
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null

  readonly events$ = this._events$.asObservable()
  readonly connected = signal(false)

  connect(tenantId: string): void {
    if (this.ws?.readyState === WebSocket.OPEN) return
    this.ws = new WebSocket(`${environment.wsUrl}?tenant_id=${tenantId}`)

    this.ws.onopen = () => {
      this.connected.set(true)
      if (this.reconnectTimer) clearTimeout(this.reconnectTimer)
    }

    this.ws.onmessage = (ev) => {
      try {
        const data = JSON.parse(ev.data) as WsEvent
        this._events$.next(data)
      } catch {}
    }

    this.ws.onclose = () => {
      this.connected.set(false)
      // Auto-reconnect after 5s
      this.reconnectTimer = setTimeout(() => this.connect(tenantId), 5000)
    }

    this.ws.onerror = () => this.ws?.close()
  }

  disconnect(): void {
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer)
    this.ws?.close()
    this.ws = null
    this.connected.set(false)
  }

  ngOnDestroy(): void {
    this.disconnect()
    this._events$.complete()
  }
}
