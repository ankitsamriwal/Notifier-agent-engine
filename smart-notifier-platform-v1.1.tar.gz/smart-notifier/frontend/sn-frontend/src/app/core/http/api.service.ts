import { Injectable, inject } from '@angular/core'
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs'
import { environment } from '../../../environments/environment'
import type { Job, CreateJobRequest } from '../models/job.model'
import type { NotificationRun, RunStats } from '../models/run.model'

@Injectable({ providedIn: 'root' })
export class ApiService {
  private http = inject(HttpClient)
  private base = environment.apiUrl

  // Jobs
  listJobs(status?: string): Observable<{ data: Job[]; total: number }> {
    return this.http.get<any>(`${this.base}/api/v1/jobs${status ? '?status='+status : ''}`)
  }
  getJob(id: string): Observable<Job> {
    return this.http.get<Job>(`${this.base}/api/v1/jobs/${id}`)
  }
  createJob(body: CreateJobRequest): Observable<Job> {
    return this.http.post<Job>(`${this.base}/api/v1/jobs`, body)
  }
  updateJob(id: string, body: Partial<CreateJobRequest>): Observable<Job> {
    return this.http.put<Job>(`${this.base}/api/v1/jobs/${id}`, body)
  }
  deleteJob(id: string): Observable<void> {
    return this.http.delete<void>(`${this.base}/api/v1/jobs/${id}`)
  }
  triggerJob(id: string, dryRun = false) {
    return this.http.post<any>(`${this.base}/api/v1/jobs/${id}/trigger`, { dry_run: dryRun })
  }
  cloneJob(id: string): Observable<Job> {
    return this.http.post<Job>(`${this.base}/api/v1/jobs/${id}/clone`, {})
  }
  // Runs
  listRuns(jobId?: string, status?: string): Observable<{ data: NotificationRun[]; total: number }> {
    const p = new URLSearchParams()
    if (jobId) p.set('job_id', jobId)
    if (status) p.set('status', status)
    return this.http.get<any>(`${this.base}/api/v1/runs${p.size ? '?'+p : ''}`)
  }
  getRunStats(): Observable<RunStats> {
    return this.http.get<RunStats>(`${this.base}/api/v1/runs/stats`)
  }
  // Approvals
  listApprovals(status?: string) {
    return this.http.get<any>(`${this.base}/api/v1/approvals${status ? '?status='+status : ''}`)
  }
  approveRun(runId: string, note?: string) {
    return this.http.post(`${this.base}/api/v1/approvals/${runId}/approve`, { note })
  }
  rejectRun(runId: string, reason?: string) {
    return this.http.post(`${this.base}/api/v1/approvals/${runId}/reject`, { reason })
  }
  modifyApproval(runId: string, body: any) {
    return this.http.put(`${this.base}/api/v1/approvals/${runId}/modify`, body)
  }
  // Dashboard
  getDashboardKpis() { return this.http.get<any>(`${this.base}/api/v1/admin/dashboard/kpis`) }
  getEffectivenessSummary() { return this.http.get<any>(`${this.base}/api/v1/effectiveness/summary`) }
  getEffectivenessHeatmap(dim: string) { return this.http.get<any>(`${this.base}/api/v1/effectiveness/heatmap?dimension=${dim}`) }
  getInsights() { return this.http.get<any>(`${this.base}/api/v1/admin/insights`) }
  getChannelStatus() { return this.http.get<any>(`${this.base}/api/v1/admin/channels/status`) }
  // Connectors
  listConnectorTypes() { return this.http.get<{ types: string[] }>(`${this.base}/api/v1/connectors/types`) }
  uploadFile(file: File) {
    const fd = new FormData(); fd.append('file', file)
    return this.http.post<any>(`${this.base}/api/v1/connectors/upload`, fd)
  }
  analyseConnector(body: any) { return this.http.post<any>(`${this.base}/api/v1/ai/analyse`, body) }
}
