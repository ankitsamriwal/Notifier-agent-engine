export interface Criterion { field:string; op:string; value?:string|number }
export interface JobCriteria { logic:'AND'|'OR'; conditions:Criterion[] }
export interface JobRecipients { to:string; cc?:string; bcc?:string }
export interface JobTemplate { subject:string; body_hint:string; body_draft?:string }
export interface JobSchedule { type:'cron'|'polling'|'webhook'|'manual'; cron?:string; timezone?:string }
export interface JobOptions { include_data_table:boolean; attach_pdf:boolean; attach_files:string[]; digest_mode:'digest'|'individual' }
export type JobTone='Professional'|'Urgent'|'Friendly'|'Formal'|'Firm'|'Concise'
export type JobStatus='active'|'paused'|'draft'
export type JobChannel='gmail'|'outlook'|'whatsapp'|'teams'|'slack'|'webhook'
export type ApprovalMode='draft'|'manual'|'auto'
export interface Job {
  job_id:string; tenant_id:string; name:string; description:string; status:JobStatus;
  connector_id:string; criteria:JobCriteria; tone:JobTone; channel:JobChannel;
  recipients:JobRecipients; template:JobTemplate; schedule:JobSchedule;
  approval_mode:ApprovalMode; options:JobOptions; run_count:number;
  last_run_at?:string; next_run_at?:string; created_at:string; updated_at:string;
}
export type CreateJobRequest = Omit<Job,'job_id'|'tenant_id'|'run_count'|'created_at'|'updated_at'|'last_run_at'|'next_run_at'>
