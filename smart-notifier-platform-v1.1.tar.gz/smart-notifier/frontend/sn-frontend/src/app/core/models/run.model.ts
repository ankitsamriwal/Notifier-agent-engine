export type RunStatus='triggered'|'fetching'|'evaluating'|'composing'|'pending_approval'|'approved'|'dispatching'|'sent'|'draft_saved'|'rejected'|'failed'|'skipped'
export interface NotificationRun {
  run_id:string; job_id:string; tenant_id:string; trigger_type:string;
  status:RunStatus; match_count:number; channel:string; recipient_to?:string;
  delivery_id?:string; draft_id?:string; error_message?:string;
  triggered_at:string; completed_at?:string;
}
export interface RunStats { total:number; sent:number; draft_saved:number; failed:number; skipped:number; pending:number; delivery_rate:string; }
