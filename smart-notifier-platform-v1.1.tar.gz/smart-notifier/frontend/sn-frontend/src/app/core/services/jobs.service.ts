import { Injectable, inject } from '@angular/core'
import { Observable } from 'rxjs'
import { ApiService } from './api.service'

export interface Job {
  job_id: string
  tenant_id: string
  name: string
  description: string
  status: 'active'|'paused'|'draft'
  connector_id: string
  criteria: { logic: 'AND'|'OR'; conditions: Criterion[] }
  tone: string
  channel: string
  recipients: { to: string; cc: string; bcc: string }
  template: { subject: string; body_hint: string; body_draft: string }
  schedule: { type: string; cron: string; timezone: string }
  approval_mode: 'draft'|'manual'|'auto'
  options: { include_data_table: boolean; attach_pdf: boolean; digest_mode: string }
  run_count: number
  last_run_at: string | null
  created_at: string
}

export interface Criterion {
  field: string
  op: string
  value?: string | number
}

@Injectable({ providedIn: 'root' })
export class JobsService {
  private api = inject(ApiService)

  list(status?: string): Observable<{ data: Job[]; total: number }> {
    const qs = status ? `?status=${status}` : ''
    return this.api.get(`/api/v1/jobs${qs}`)
  }

  get(id: string): Observable<Job> {
    return this.api.get(`/api/v1/jobs/${id}`)
  }

  create(job: Partial<Job>): Observable<Job> {
    return this.api.post('/api/v1/jobs', job)
  }

  update(id: string, job: Partial<Job>): Observable<Job> {
    return this.api.put(`/api/v1/jobs/${id}`, job)
  }

  delete(id: string): Observable<void> {
    return this.api.delete(`/api/v1/jobs/${id}`)
  }

  trigger(id: string, dryRun = false): Observable<{ run_id: string; status: string }> {
    return this.api.post(`/api/v1/jobs/${id}/trigger`, { dry_run: dryRun })
  }

  clone(id: string): Observable<Job> {
    return this.api.post(`/api/v1/jobs/${id}/clone`, {})
  }
}
