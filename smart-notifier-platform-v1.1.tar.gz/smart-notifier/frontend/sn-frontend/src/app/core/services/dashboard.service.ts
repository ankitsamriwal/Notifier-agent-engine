import { Injectable, inject } from '@angular/core'
import { Observable } from 'rxjs'
import { ApiService } from './api.service'

export interface DashboardData {
  kpis: {
    total_sent: number
    total_failed: number
    delivery_rate: number
    response_rate: number
    outcome_rate: number
  }
  volume_chart: { day: string; sent: number; failed: number }[]
  tone_breakdown: { tone: string; runs: number; cta_clicks: number }[]
  computed_at: string
}

@Injectable({ providedIn: 'root' })
export class DashboardService {
  private api = inject(ApiService)

  getDashboard(): Observable<DashboardData> {
    return this.api.get('/api/v1/admin/dashboard')
  }

  getChannelHealth(): Observable<{ data: any[] }> {
    return this.api.get('/api/v1/admin/channels/health')
  }
}
