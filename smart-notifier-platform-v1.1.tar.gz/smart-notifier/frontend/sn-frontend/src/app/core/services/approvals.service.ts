import { Injectable, inject } from '@angular/core'
import { Observable, Subject } from 'rxjs'
import { ApiService } from './api.service'
import { environment } from '../../../environments/environment'

export interface Approval {
  approval_id: string
  run_id: string
  tenant_id: string
  status: 'pending_review'|'approved'|'rejected'|'modified'|'dispatched'
  composed_subject: string
  composed_html: string
  match_count: number
  channel: string
  expires_at: string
  created_at: string
}

@Injectable({ providedIn: 'root' })
export class ApprovalsService {
  private api = inject(ApiService)
  private ws: WebSocket | null = null
  readonly approvalEvents$ = new Subject<{ type: string; run_id: string }>()

  connectWebSocket(): void {
    const wsUrl = environment.apiUrl.replace('http', 'ws') + '/api/v1/approvals/ws'
    this.ws = new WebSocket(wsUrl)
    this.ws.onmessage = (e) => {
      try { this.approvalEvents$.next(JSON.parse(e.data)) } catch {}
    }
    this.ws.onclose = () => {
      // Reconnect after 3s
      setTimeout(() => this.connectWebSocket(), 3000)
    }
  }

  list(status?: string): Observable<{ data: Approval[] }> {
    return this.api.get(`/api/v1/approvals${status ? '?status='+status : ''}`)
  }

  get(runId: string): Observable<Approval> {
    return this.api.get(`/api/v1/approvals/${runId}`)
  }

  approve(runId: string, note?: string): Observable<any> {
    return this.api.post(`/api/v1/approvals/${runId}/approve`, { note })
  }

  reject(runId: string, reason?: string): Observable<any> {
    return this.api.post(`/api/v1/approvals/${runId}/reject`, { reason })
  }

  modify(runId: string, overrides: { subject_override?: string; html_override?: string }): Observable<any> {
    return this.api.put(`/api/v1/approvals/${runId}/modify`, overrides)
  }
}
