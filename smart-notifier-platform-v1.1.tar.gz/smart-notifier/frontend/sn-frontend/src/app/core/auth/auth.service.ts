import { Injectable, signal, computed } from '@angular/core'

export interface AuthUser {
  sub: string
  tenant_id: string
  roles: string[]
  email?: string
  display_name?: string
}

const TOKEN_KEY = 'sn_access_token'

@Injectable({ providedIn: 'root' })
export class AuthService {
  private _user = signal<AuthUser | null>(null)

  readonly user     = this._user.asReadonly()
  readonly isLoggedIn = computed(() => !!this._user())
  readonly isAdmin  = computed(() => this._user()?.roles.includes('tenant_admin') || this._user()?.roles.includes('super_admin'))

  getToken(): string | null {
    return sessionStorage.getItem(TOKEN_KEY)
  }

  setToken(token: string): void {
    sessionStorage.setItem(TOKEN_KEY, token)
    const payload = this.decodePayload(token)
    if (payload) this._user.set(payload)
  }

  logout(): void {
    sessionStorage.removeItem(TOKEN_KEY)
    this._user.set(null)
  }

  // Dev helper: set a mock token for development without a running auth server
  setDevToken(tenantId: string, userId: string, roles: string[]): void {
    this._user.set({ sub: userId, tenant_id: tenantId, roles })
  }

  private decodePayload(token: string): AuthUser | null {
    try {
      const [, payload] = token.split('.')
      const decoded = atob(payload.replace(/-/g, '+').replace(/_/g, '/'))
      return JSON.parse(decoded) as AuthUser
    } catch {
      return null
    }
  }
}
