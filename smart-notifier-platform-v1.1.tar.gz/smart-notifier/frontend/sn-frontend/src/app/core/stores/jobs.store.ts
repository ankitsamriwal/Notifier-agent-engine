import { signalStore, withState, withMethods, withComputed, patchState } from '@ngrx/signals'
import { inject, computed } from '@angular/core'
import { rxMethod } from '@ngrx/signals/rxjs-interop'
import { tapResponse } from '@ngrx/operators'
import { pipe, switchMap, tap } from 'rxjs'
import { ApiService } from '../http/api.service'
import type { Job } from '../models/job.model'

interface JobsState {
  jobs: Job[]
  selectedJob: Job | null
  loading: boolean
  error: string | null
  filter: string
  drawerOpen: boolean
}

export const JobsStore = signalStore(
  { providedIn: 'root' },
  withState<JobsState>({ jobs: [], selectedJob: null, loading: false, error: null, filter: '', drawerOpen: false }),

  withComputed(({ jobs, filter }) => ({
    filteredJobs:  computed(() => { const f = filter(); return f ? jobs().filter(j => j.status === f) : jobs() }),
    activeCount:   computed(() => jobs().filter(j => j.status === 'active').length),
    draftCount:    computed(() => jobs().filter(j => j.status === 'draft').length),
    pausedCount:   computed(() => jobs().filter(j => j.status === 'paused').length),
  })),

  withMethods((store, api = inject(ApiService)) => ({
    loadJobs: rxMethod<string | undefined>(pipe(
      tap(() => patchState(store, { loading: true, error: null })),
      switchMap(status => api.listJobs(status).pipe(
        tapResponse({
          next: r => patchState(store, { jobs: r.data ?? [], loading: false }),
          error: e => patchState(store, { error: String(e), loading: false }),
        })
      ))
    )),
    setFilter(f: string) { patchState(store, { filter: f }) },
    selectJob(job: Job | null) { patchState(store, { selectedJob: job, drawerOpen: !!job }) },
    openDrawer() { patchState(store, { selectedJob: null, drawerOpen: true }) },
    closeDrawer() { patchState(store, { drawerOpen: false, selectedJob: null }) },
    triggerJob: rxMethod<string>(pipe(
      switchMap(id => api.triggerJob(id).pipe(tapResponse({ next: () => {}, error: e => patchState(store, { error: String(e) }) })))
    )),
    deleteJob: rxMethod<string>(pipe(
      switchMap(id => api.deleteJob(id).pipe(
        tapResponse({ next: () => patchState(store, { jobs: store.jobs().filter(j => j.job_id !== id) }), error: e => patchState(store, { error: String(e) }) })
      ))
    )),
    cloneJob: rxMethod<string>(pipe(
      switchMap(id => api.cloneJob(id).pipe(
        tapResponse({ next: cloned => patchState(store, { jobs: [cloned, ...store.jobs()] }), error: e => patchState(store, { error: String(e) }) })
      ))
    )),
  }))
)
