import { signalStore, withState, withMethods, withComputed, patchState } from '@ngrx/signals'
import { inject, computed } from '@angular/core'
import { rxMethod } from '@ngrx/signals/rxjs-interop'
import { tapResponse } from '@ngrx/operators'
import { pipe, switchMap, tap } from 'rxjs'
import { ApiService } from '../http/api.service'

interface ApprovalsState { approvals: any[]; loading: boolean; error: string | null }

export const ApprovalsStore = signalStore(
  { providedIn: 'root' },
  withState<ApprovalsState>({ approvals: [], loading: false, error: null }),
  withComputed(({ approvals }) => ({
    pendingCount:    computed(() => approvals().filter(a => a.status === 'pending_review').length),
    pendingApprovals:computed(() => approvals().filter(a => a.status === 'pending_review')),
  })),
  withMethods((store, api = inject(ApiService)) => ({
    loadApprovals: rxMethod<string | undefined>(pipe(
      tap(() => patchState(store, { loading: true })),
      switchMap(status => api.listApprovals(status).pipe(
        tapResponse({ next: r => patchState(store, { approvals: r.data ?? [], loading: false }), error: e => patchState(store, { error: String(e), loading: false }) })
      ))
    )),
    approveRun: rxMethod<{ runId: string; note?: string }>(pipe(
      switchMap(({ runId, note }) => api.approveRun(runId, note).pipe(
        tapResponse({
          next: () => patchState(store, { approvals: store.approvals().map(a => a.run_id === runId ? { ...a, status: 'approved' } : a) }),
          error: e => patchState(store, { error: String(e) }),
        })
      ))
    )),
    rejectRun: rxMethod<{ runId: string; reason?: string }>(pipe(
      switchMap(({ runId, reason }) => api.rejectRun(runId, reason).pipe(
        tapResponse({
          next: () => patchState(store, { approvals: store.approvals().map(a => a.run_id === runId ? { ...a, status: 'rejected' } : a) }),
          error: e => patchState(store, { error: String(e) }),
        })
      ))
    )),
  }))
)
