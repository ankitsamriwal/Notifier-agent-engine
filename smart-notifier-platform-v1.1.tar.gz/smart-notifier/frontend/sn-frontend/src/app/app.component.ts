import { Component } from '@angular/core'
import { RouterOutlet } from '@angular/router'
import { SidebarComponent } from './layout/sidebar.component'
import { SnToastHostComponent } from './shared/components/toast/sn-toast.component'

@Component({
  selector: 'sn-root',
  standalone: true,
  imports: [RouterOutlet, SidebarComponent, SnToastHostComponent],
  template: `
    <div class="app-shell">
      <sn-sidebar></sn-sidebar>
      <main class="app-main" id="main-content" role="main" tabindex="-1">
        <router-outlet></router-outlet>
      </main>
    </div>
    <sn-toast-host></sn-toast-host>
  `,
  styles: [`
    .app-shell { display:flex; min-height:100vh; }
    .app-main { flex:1; overflow:auto; background:var(--sn-surface-2); min-width:0; }
  `]
})
export class AppComponent {}
