import { Routes } from '@angular/router'

export const routes: Routes = [
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: 'dashboard',     loadComponent: () => import('./features/dashboard/dashboard.component').then(m => m.DashboardComponent) },
  { path: 'jobs',          loadComponent: () => import('./features/jobs/jobs.component').then(m => m.JobsComponent) },
  { path: 'runs',          loadComponent: () => import('./features/runs/runs.component').then(m => m.RunsComponent) },
  { path: 'approvals',     loadComponent: () => import('./features/approvals/approvals.component').then(m => m.ApprovalsComponent) },
  { path: 'effectiveness', loadComponent: () => import('./features/effectiveness/effectiveness.component').then(m => m.EffectivenessComponent) },
  { path: '**', redirectTo: 'dashboard' }
]
