import { Component, Input, ChangeDetectionStrategy } from '@angular/core'
export type BadgeVariant = 'default'|'primary'|'success'|'warning'|'danger'|'info'|'purple'
@Component({
  selector: 'sn-badge', standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `<span [class]="'sn-badge sn-badge--'+variant"><ng-content/></span>`,
  styles: [`.sn-badge{display:inline-flex;align-items:center;padding:2px 8px;border-radius:999px;font-size:11px;font-weight:500}.sn-badge--default{background:var(--sn-offwhite);color:var(--sn-text-secondary)}.sn-badge--primary{background:var(--sn-blue-light);color:var(--sn-blue)}.sn-badge--success{background:var(--sn-success-bg);color:var(--sn-success)}.sn-badge--warning{background:var(--sn-warning-bg);color:var(--sn-warning)}.sn-badge--danger{background:var(--sn-danger-bg);color:var(--sn-danger)}.sn-badge--info{background:var(--sn-info-bg);color:var(--sn-info)}.sn-badge--purple{background:#EEEDFE;color:#3C3489}`],
})
export class SnBadgeComponent { @Input() variant: BadgeVariant = 'default' }
