import { Component, Input, ChangeDetectionStrategy } from '@angular/core'
import { CommonModule } from '@angular/common'
@Component({
  selector: 'sn-kpi-card', standalone: true, imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `<div class="kpi"><div class="kpi__label">{{label}}</div><div class="kpi__val" [style.color]="color||'var(--sn-text-primary)'">{{value}}</div><div *ngIf="delta" class="kpi__delta" [class.up]="!delta.startsWith('-')">{{delta}}</div></div>`,
  styles: [`.kpi{background:var(--sn-white);border:1px solid var(--sn-border);border-radius:var(--sn-radius-md);padding:14px 16px}.kpi__label{font-size:11px;font-weight:500;color:var(--sn-text-secondary);text-transform:uppercase;letter-spacing:.04em;margin-bottom:6px}.kpi__val{font-size:24px;font-weight:600}.kpi__delta{font-size:11px;margin-top:4px;color:var(--sn-danger)}.kpi__delta.up{color:var(--sn-success)}`],
})
export class SnKpiCardComponent {
  @Input() label = ''
  @Input() value: string|number = ''
  @Input() delta = ''
  @Input() color = ''
}
