import { Component, Input, ChangeDetectionStrategy } from '@angular/core'
@Component({
  selector: 'sn-spinner', standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `<div [class]="'sn-spin sn-spin--'+size" role="status" [attr.aria-label]="label"><svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" stroke="var(--sn-border)" stroke-width="2"/><path d="M12 2a10 10 0 0 1 10 10" stroke="var(--sn-blue)" stroke-width="2" stroke-linecap="round"><animateTransform attributeName="transform" type="rotate" from="0 12 12" to="360 12 12" dur=".8s" repeatCount="indefinite"/></path></svg></div>`,
  styles: [`.sn-spin svg{display:block}.sn-spin--sm svg{width:16px;height:16px}.sn-spin--md svg{width:24px;height:24px}.sn-spin--lg svg{width:40px;height:40px}`],
})
export class SnSpinnerComponent {
  @Input() size: 'sm'|'md'|'lg' = 'md'
  @Input() label = 'Loading...'
}
