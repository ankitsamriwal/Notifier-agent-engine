import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core'
import { CommonModule } from '@angular/common'
export type ButtonVariant = 'primary'|'secondary'|'ghost'|'danger'|'success'|'warning'
export type ButtonSize = 'sm'|'md'|'lg'
@Component({
  selector: 'sn-button', standalone: true, imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `<button [class]="'sn-btn sn-btn--'+variant+' sn-btn--'+size" [disabled]="disabled||loading" [attr.type]="type" (click)="clicked.emit($event)"><ng-content/></button>`,
  styles: [`:host{display:inline-flex}.sn-btn{display:inline-flex;align-items:center;gap:6px;border-radius:var(--sn-radius-md);font-weight:500;transition:all var(--sn-trans-fast);border:1.5px solid transparent;cursor:pointer}.sn-btn:disabled{opacity:.5;cursor:not-allowed}.sn-btn--sm{padding:5px 10px;font-size:12px}.sn-btn--md{padding:8px 16px;font-size:13px}.sn-btn--lg{padding:11px 20px;font-size:14px}.sn-btn--primary{background:var(--sn-blue);color:#fff}.sn-btn--primary:hover:not(:disabled){background:#0C447C}.sn-btn--secondary{background:var(--sn-white);color:var(--sn-text-primary);border-color:var(--sn-border)}.sn-btn--secondary:hover:not(:disabled){background:var(--sn-offwhite)}.sn-btn--ghost{background:transparent;color:var(--sn-blue)}.sn-btn--ghost:hover:not(:disabled){background:var(--sn-blue-light)}.sn-btn--danger{background:var(--sn-danger);color:#fff}.sn-btn--danger:hover:not(:disabled){background:#791F1F}.sn-btn--success{background:var(--sn-success);color:#fff}.sn-btn--success:hover:not(:disabled){background:#27500A}.sn-btn--warning{background:var(--sn-warning);color:#fff}`],
})
export class SnButtonComponent {
  @Input() variant: ButtonVariant = 'primary'
  @Input() size: ButtonSize = 'md'
  @Input() disabled = false
  @Input() loading = false
  @Input() type: 'button'|'submit'|'reset' = 'button'
  @Output() clicked = new EventEmitter<MouseEvent>()
}
