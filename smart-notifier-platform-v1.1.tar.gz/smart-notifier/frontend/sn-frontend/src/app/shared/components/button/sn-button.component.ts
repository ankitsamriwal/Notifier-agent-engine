import { Component, Input, HostBinding, ChangeDetectionStrategy } from '@angular/core'
import { CommonModule } from '@angular/common'
export type ButtonVariant = 'primary'|'secondary'|'danger'|'ghost'|'success'
export type ButtonSize = 'sm'|'md'|'lg'

@Component({
  selector: 'button[snButton], a[snButton]',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `<span class="inner"><ng-content></ng-content></span>`,
  styles: [`
    :host { display:inline-flex; align-items:center; justify-content:center;
      border:1px solid transparent; border-radius:var(--sn-radius-md);
      font-family:var(--sn-font-sans); font-weight:500; cursor:pointer;
      transition:background var(--sn-transition), color var(--sn-transition), border-color var(--sn-transition);
      white-space:nowrap; user-select:none; text-decoration:none; outline:none; }
    :host:focus-visible { box-shadow:0 0 0 3px rgba(24,95,165,0.35); }
    :host[disabled] { opacity:0.45; pointer-events:none; }
    :host.sn-sm { padding:5px 10px; font-size:12px; }
    :host.sn-md { padding:8px 16px; font-size:13px; }
    :host.sn-lg { padding:11px 22px; font-size:15px; }
    :host.sn-primary { background:var(--sn-blue); color:#fff; border-color:var(--sn-blue); }
    :host.sn-primary:hover { background:#0C447C; border-color:#0C447C; }
    :host.sn-secondary { background:var(--sn-surface); color:var(--sn-text-primary); border-color:var(--sn-border-strong); }
    :host.sn-secondary:hover { background:var(--sn-surface-3); }
    :host.sn-danger { background:var(--sn-danger); color:#fff; border-color:var(--sn-danger); }
    :host.sn-danger:hover { background:#791F1F; }
    :host.sn-success { background:var(--sn-success); color:#fff; border-color:var(--sn-success); }
    :host.sn-success:hover { background:#27500A; }
    :host.sn-ghost { background:transparent; color:var(--sn-text-secondary); border-color:transparent; }
    :host.sn-ghost:hover { background:var(--sn-surface-3); color:var(--sn-text-primary); }
    .inner { display:flex; align-items:center; gap:6px; }
  `]
})
export class SnButtonComponent {
  @Input() variant: ButtonVariant = 'secondary'
  @Input() size: ButtonSize = 'md'
  @HostBinding('class') get cls() { return `sn-${this.variant} sn-${this.size}` }
}
