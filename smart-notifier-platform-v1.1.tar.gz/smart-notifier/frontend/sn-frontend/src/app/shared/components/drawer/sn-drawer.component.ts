import {
  Component, Input, Output, EventEmitter, ChangeDetectionStrategy,
  HostListener, ElementRef
} from '@angular/core'
import { CommonModule } from '@angular/common'
import { animate, style, transition, trigger } from '@angular/animations'

@Component({
  selector: 'sn-drawer',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [
    trigger('slideIn', [
      transition(':enter', [
        style({ transform: 'translateX(100%)', opacity: 0 }),
        animate('220ms cubic-bezier(0.4,0,0.2,1)', style({ transform: 'translateX(0)', opacity: 1 }))
      ]),
      transition(':leave', [
        animate('180ms cubic-bezier(0.4,0,0.2,1)', style({ transform: 'translateX(100%)', opacity: 0 }))
      ])
    ]),
    trigger('fadeIn', [
      transition(':enter', [style({ opacity: 0 }), animate('200ms ease', style({ opacity: 1 }))]),
      transition(':leave', [animate('180ms ease', style({ opacity: 0 }))]),
    ])
  ],
  template: `
    @if (open) {
      <!-- Backdrop -->
      <div class="drawer-backdrop" @fadeIn (click)="backdropClick()" aria-hidden="true"></div>

      <!-- Panel -->
      <aside class="drawer-panel" @slideIn role="dialog" [attr.aria-label]="title"
             [style.width]="width">
        <header class="drawer-header">
          <h2 class="drawer-title">{{ title }}</h2>
          <button class="drawer-close" (click)="closed.emit()" aria-label="Close drawer">
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none" stroke="currentColor" stroke-width="1.5">
              <path d="M4 4l10 10M14 4L4 14"/>
            </svg>
          </button>
        </header>

        <div class="drawer-body">
          <ng-content></ng-content>
        </div>

        @if (hasFooter) {
          <footer class="drawer-footer">
            <ng-content select="[snDrawerFooter]"></ng-content>
          </footer>
        }
      </aside>
    }
  `,
  styles: [`
    .drawer-backdrop {
      position: fixed; inset: 0;
      background: rgba(0,0,0,0.35);
      z-index: 300;
    }
    .drawer-panel {
      position: fixed; top: 0; right: 0; bottom: 0;
      background: var(--sn-surface);
      border-left: 1px solid var(--sn-border);
      z-index: 301;
      display: flex; flex-direction: column;
      box-shadow: var(--sn-shadow-lg);
      max-width: 100vw;
    }
    .drawer-header {
      display: flex; align-items: center; justify-content: space-between;
      padding: 18px 24px;
      border-bottom: 1px solid var(--sn-border);
      flex-shrink: 0;
    }
    .drawer-title {
      font-size: 15px; font-weight: 500; color: var(--sn-text-primary);
    }
    .drawer-close {
      width: 32px; height: 32px; border: none; background: transparent;
      color: var(--sn-text-secondary); border-radius: var(--sn-radius-md);
      display: flex; align-items: center; justify-content: center;
      cursor: pointer; transition: background var(--sn-transition);
    }
    .drawer-close:hover { background: var(--sn-surface-3); color: var(--sn-text-primary); }
    .drawer-body { flex: 1; overflow-y: auto; padding: 24px; }
    .drawer-footer {
      flex-shrink: 0; padding: 16px 24px;
      border-top: 1px solid var(--sn-border);
      display: flex; gap: 10px; justify-content: flex-end;
      background: var(--sn-surface-3);
    }
  `]
})
export class SnDrawerComponent {
  @Input() open = false
  @Input() title = ''
  @Input() width = '560px'
  @Input() hasFooter = true
  @Input() closeOnBackdrop = true
  @Output() closed = new EventEmitter<void>()

  @HostListener('document:keydown.escape')
  onEsc() { if (this.open) this.closed.emit() }

  backdropClick() {
    if (this.closeOnBackdrop) this.closed.emit()
  }
}
