import {
  Component, Input, Output, EventEmitter, OnInit, OnChanges,
  ChangeDetectionStrategy, inject, signal
} from '@angular/core'
import { CommonModule } from '@angular/common'
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms'
import { SnDrawerComponent } from '../drawer/sn-drawer.component'
import { SnInputComponent } from '../input/sn-input.component'
import { SnSelectComponent, SelectOption } from '../select/sn-select.component'
import { SnButtonComponent } from '../button/sn-button.component'
import { CriteriaBuilderComponent } from '../criteria-builder/criteria-builder.component'
import { EmailPreviewComponent } from '../email-preview/email-preview.component'
import { ApiService } from '../../../core/http/api.service'
import type { Job, CreateJobRequest, JobCriteria } from '../../../core/models/job.model'

const TONES: SelectOption[]    = ['Professional','Urgent','Friendly','Formal','Firm','Concise'].map(v => ({label:v,value:v}))
const CHANNELS: SelectOption[] = ['gmail','outlook','whatsapp','teams','slack','webhook'].map(v => ({label:v.charAt(0).toUpperCase()+v.slice(1),value:v}))
const APPROVALS: SelectOption[] = [{label:'Manual approval',value:'manual'},{label:'Auto-send',value:'auto'},{label:'Save as draft',value:'draft'}]
const SCHEDULES: SelectOption[] = [{label:'Manual (trigger only)',value:'manual'},{label:'CRON (custom)',value:'cron'},{label:'Polling',value:'polling'}]

@Component({
  selector: 'sn-job-form',
  standalone: true,
  imports: [
    CommonModule, ReactiveFormsModule,
    SnDrawerComponent, SnInputComponent, SnSelectComponent,
    SnButtonComponent, CriteriaBuilderComponent, EmailPreviewComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <sn-drawer [open]="open" [title]="job ? 'Edit job' : 'New notification job'"
               (closed)="cancel()">

      <div class="job-form">
        <form [formGroup]="form" (ngSubmit)="submit()">

          <!-- Step indicator -->
          <div class="steps" role="tablist" aria-label="Form sections">
            @for (s of steps; track s.id; let i = $index) {
              <button type="button" class="step" role="tab"
                      [class.active]="currentStep() === i"
                      [class.done]="currentStep() > i"
                      (click)="currentStep.set(i)"
                      [attr.aria-selected]="currentStep()===i">
                <span class="step-num">{{ currentStep() > i ? '✓' : i+1 }}</span>
                {{ s.label }}
              </button>
            }
          </div>

          <!-- Step 1: Basics -->
          @if (currentStep() === 0) {
            <div class="step-panel" role="tabpanel">
              <sn-input formControlName="name" label="Job name" placeholder="e.g. AR Overdue — Daily Digest" [required]="true"></sn-input>
              <sn-input formControlName="description" label="Description" placeholder="What does this job notify about?"></sn-input>
              <sn-select formControlName="channel" label="Channel" [options]="channels" placeholder="Select channel…"></sn-select>
              <sn-select formControlName="tone" label="Tone" [options]="tones"></sn-select>
              <sn-select formControlName="approval_mode" label="Approval mode" [options]="approvals"></sn-select>
            </div>
          }

          <!-- Step 2: Criteria -->
          @if (currentStep() === 1) {
            <div class="step-panel" role="tabpanel">
              <p class="step-desc">Define which rows from your data source should trigger a notification.</p>
              <sn-criteria-builder
                [value]="criteriaValue()"
                [schemaFields]="schemaFields()"
                (valueChange)="onCriteriaChange($event)">
              </sn-criteria-builder>
            </div>
          }

          <!-- Step 3: Template -->
          @if (currentStep() === 2) {
            <div class="step-panel" role="tabpanel">
              <sn-input formControlName="subject" label="Subject template"
                placeholder="e.g. [AR OVERDUE] {{match_count}} accounts — {{today}}"></sn-input>
              <div class="field">
                <label class="field-label">Body instruction</label>
                <textarea formControlName="body_hint" class="body-hint" rows="4"
                  placeholder="Describe what the email body should say. AI will draft it."></textarea>
                <p class="field-hint">Claude will draft the full email from this instruction. Use specific language about tone, urgency, and expected action.</p>
              </div>
              <sn-input formControlName="recipients_to" label="Recipients (To)" placeholder="finance@company.com, ar@company.com"></sn-input>
              <sn-input formControlName="recipients_cc" label="CC (optional)" placeholder="manager@company.com"></sn-input>
            </div>
          }

          <!-- Step 4: Schedule + Preview -->
          @if (currentStep() === 3) {
            <div class="step-panel" role="tabpanel">
              <sn-select formControlName="schedule_type" label="Schedule type" [options]="schedules"></sn-select>
              @if (form.value.schedule_type === 'cron') {
                <sn-input formControlName="cron" label="CRON expression" placeholder="0 8 * * 1-5 (Mon–Fri at 08:00)"></sn-input>
                <sn-input formControlName="timezone" label="Timezone" placeholder="Asia/Dubai"></sn-input>
              }
              <div class="preview-section">
                <h3 class="preview-title">Email preview</h3>
                <p class="preview-desc">Preview based on your template. Actual content will be AI-generated on each run.</p>
                <sn-email-preview
                  [subject]="form.value.subject"
                  [to]="form.value.recipients_to"
                  [htmlContent]="previewHtml"
                  [ctaButtons]="previewCta">
                </sn-email-preview>
              </div>
            </div>
          }
        </form>
      </div>

      <!-- Drawer footer -->
      <div snDrawerFooter>
        <button snButton variant="ghost" size="md" type="button" (click)="cancel()">Cancel</button>
        @if (currentStep() > 0) {
          <button snButton variant="secondary" size="md" type="button" (click)="prevStep()">← Back</button>
        }
        @if (currentStep() < steps.length - 1) {
          <button snButton variant="primary" size="md" type="button" (click)="nextStep()" [disabled]="!canProceed()">
            Next →
          </button>
        } @else {
          <button snButton variant="success" size="md" type="button" (click)="submit()" [disabled]="saving()">
            {{ saving() ? 'Saving…' : (job ? 'Update job' : 'Create job') }}
          </button>
        }
      </div>
    </sn-drawer>
  `,
  styles: [`
    .job-form { display:flex; flex-direction:column; gap:16px; }
    .steps { display:flex; gap:0; border:1px solid var(--sn-border); border-radius:var(--sn-radius-md); overflow:hidden; margin-bottom:4px; }
    .step { flex:1; padding:8px 4px; font-size:11px; font-weight:500; border:none; background:var(--sn-surface); color:var(--sn-text-secondary); cursor:pointer; transition:background var(--sn-transition); border-right:1px solid var(--sn-border); display:flex; align-items:center; justify-content:center; gap:5px; }
    .step:last-child { border-right:none; }
    .step.active { background:var(--sn-blue-light); color:var(--sn-blue); }
    .step.done { background:var(--sn-success-bg); color:var(--sn-success); }
    .step-num { width:18px; height:18px; border-radius:50%; background:currentColor; color:#fff; font-size:10px; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
    .step.active .step-num { background:var(--sn-blue); }
    .step.done .step-num { background:var(--sn-success); }

    .step-panel { display:flex; flex-direction:column; gap:14px; animation:fadeIn 150ms ease; }
    @keyframes fadeIn { from { opacity:0; transform:translateY(4px); } to { opacity:1; transform:none; } }
    .step-desc { font-size:12px; color:var(--sn-text-secondary); }

    .field { display:flex; flex-direction:column; gap:5px; }
    .field-label { font-size:12px; font-weight:500; color:var(--sn-text-primary); }
    .field-hint { font-size:11px; color:var(--sn-text-secondary); }
    .body-hint { padding:8px 11px; border:1px solid var(--sn-border-strong); border-radius:var(--sn-radius-md); font-size:13px; font-family:var(--sn-font-sans); background:var(--sn-surface); color:var(--sn-text-primary); resize:vertical; width:100%; }
    .body-hint:focus { outline:none; border-color:var(--sn-blue); box-shadow:0 0 0 3px rgba(24,95,165,0.18); }

    .preview-section { display:flex; flex-direction:column; gap:8px; margin-top:8px; }
    .preview-title { font-size:13px; font-weight:500; color:var(--sn-text-primary); }
    .preview-desc { font-size:11px; color:var(--sn-text-secondary); }
  `]
})
export class JobFormComponent implements OnInit, OnChanges {
  @Input() open = false
  @Input() job: Job | null = null
  @Input() connectors: { connector_id: string; name: string; type: string }[] = []
  @Output() closed   = new EventEmitter<void>()
  @Output() saved    = new EventEmitter<Job>()

  private fb  = inject(FormBuilder)
  private api = inject(ApiService)

  readonly tones    = TONES
  readonly channels = CHANNELS
  readonly approvals = APPROVALS
  readonly schedules = SCHEDULES

  form!: FormGroup
  currentStep = signal(0)
  saving = signal(false)
  criteriaValue = signal<JobCriteria>({ logic: 'AND', conditions: [] })
  schemaFields  = signal<string[]>([])

  readonly steps = [
    { id: 0, label: 'Basics' },
    { id: 1, label: 'Criteria' },
    { id: 2, label: 'Template' },
    { id: 3, label: 'Schedule' },
  ]

  readonly previewHtml = `
    <div style="font-family:Arial,sans-serif;padding:20px">
      <p>Dear {{recipient_name}},</p>
      <p style="margin-top:12px">This is a preview of the AI-drafted email body. The actual content will be generated using your data when the job runs.</p>
      <p style="margin-top:12px">The email will include a data table with matched rows and contextual CTA buttons for recipients to respond with one click.</p>
      <p style="margin-top:20px;font-size:12px;color:#666">— Smart Notifier · {{today}}</p>
    </div>
  `
  readonly previewCta = [
    { label: 'Payment made', key: 'payment_made' },
    { label: 'Will pay by Friday', key: 'will_pay_friday' },
    { label: 'Query raised', key: 'query_raised' },
  ]

  ngOnInit() { this.buildForm() }
  ngOnChanges() { if (this.job) this.patchForm(this.job) }

  buildForm() {
    this.form = this.fb.group({
      name:           ['', Validators.required],
      description:    [''],
      connector_id:   [''],
      channel:        ['gmail', Validators.required],
      tone:           ['Professional'],
      approval_mode:  ['manual'],
      subject:        [''],
      body_hint:      [''],
      recipients_to:  ['', Validators.required],
      recipients_cc:  [''],
      schedule_type:  ['manual'],
      cron:           [''],
      timezone:       ['Asia/Dubai'],
    })
  }

  patchForm(job: Job) {
    this.form?.patchValue({
      name:          job.name,
      description:   job.description,
      connector_id:  job.connector_id,
      channel:       job.channel,
      tone:          job.tone,
      approval_mode: job.approval_mode,
      subject:       job.template.subject,
      body_hint:     job.template.body_hint,
      recipients_to: job.recipients.to,
      recipients_cc: job.recipients.cc,
      schedule_type: job.schedule.type,
      cron:          job.schedule.cron ?? '',
      timezone:      job.schedule.timezone ?? 'Asia/Dubai',
    })
    this.criteriaValue.set(job.criteria)
  }

  onCriteriaChange(criteria: JobCriteria) {
    this.criteriaValue.set(criteria)
  }

  canProceed(): boolean {
    if (this.currentStep() === 0) {
      return this.form.get('name')!.valid && this.form.get('channel')!.valid
    }
    return true
  }

  nextStep() {
    if (this.currentStep() < this.steps.length - 1) {
      this.currentStep.update(s => s + 1)
    }
  }

  prevStep() {
    if (this.currentStep() > 0) {
      this.currentStep.update(s => s - 1)
    }
  }

  submit() {
    if (this.form.invalid) return
    this.saving.set(true)

    const v = this.form.value
    const payload: CreateJobRequest = {
      name:          v.name,
      description:   v.description,
      connector_id:  v.connector_id || '00000000-0000-0000-0000-000000000000',
      criteria:      this.criteriaValue(),
      tone:          v.tone,
      channel:       v.channel,
      recipients:    { to: v.recipients_to, cc: v.recipients_cc, bcc: '' },
      template:      { subject: v.subject, body_hint: v.body_hint, body_draft: '' },
      schedule:      { type: v.schedule_type, cron: v.cron, timezone: v.timezone },
      approval_mode: v.approval_mode,
      options:       { include_data_table: true, attach_pdf: false, attach_files: [], digest_mode: 'digest' },
      status:        'draft',
    }

    const req$ = this.job
      ? this.api.updateJob(this.job.job_id, payload)
      : this.api.createJob(payload)

    req$.subscribe({
      next: job => { this.saving.set(false); this.saved.emit(job) },
      error: () => this.saving.set(false),
    })
  }

  cancel() {
    this.currentStep.set(0)
    this.buildForm()
    this.closed.emit()
  }
}
