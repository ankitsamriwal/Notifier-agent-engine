import { Component, Input, forwardRef, ChangeDetectionStrategy } from '@angular/core'
import { ControlValueAccessor, NG_VALUE_ACCESSOR, ReactiveFormsModule, FormsModule } from '@angular/forms'
import { CommonModule } from '@angular/common'

@Component({
  selector: 'sn-input',
  standalone: true,
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => SnInputComponent), multi: true }],
  template: `
    <div class="sn-field">
      @if (label) {
        <label class="sn-label" [for]="fieldId">
          {{ label }}
          @if (required) { <span class="required" aria-label="required">*</span> }
        </label>
      }
      <input
        [id]="fieldId" [type]="type" [placeholder]="placeholder"
        [disabled]="disabled" [(ngModel)]="value"
        class="sn-input" [class.sn-input--error]="hasError"
        [attr.aria-invalid]="hasError" [attr.aria-describedby]="hint ? fieldId+'-hint' : null"
        (blur)="onTouched()">
      @if (hint) {
        <span class="sn-hint" [id]="fieldId+'-hint'">{{ hint }}</span>
      }
      @if (hasError && errorMsg) {
        <span class="sn-error" role="alert">{{ errorMsg }}</span>
      }
    </div>
  `,
  styles: [`
    .sn-field { display:flex; flex-direction:column; gap:5px; }
    .sn-label { font-size:12px; font-weight:500; color:var(--sn-text-primary); }
    .required { color:var(--sn-danger); margin-left:2px; }
    .sn-input {
      padding:8px 11px; border:1px solid var(--sn-border-strong);
      border-radius:var(--sn-radius-md); font-size:13px;
      background:var(--sn-surface); color:var(--sn-text-primary);
      transition:border-color var(--sn-transition), box-shadow var(--sn-transition);
      width:100%;
    }
    .sn-input:focus { outline:none; border-color:var(--sn-blue); box-shadow:0 0 0 3px rgba(24,95,165,0.18); }
    .sn-input::placeholder { color:var(--sn-text-tertiary); }
    .sn-input:disabled { opacity:0.5; cursor:not-allowed; background:var(--sn-surface-3); }
    .sn-input--error { border-color:var(--sn-danger); }
    .sn-input--error:focus { box-shadow:0 0 0 3px rgba(163,45,45,0.18); }
    .sn-hint { font-size:11px; color:var(--sn-text-secondary); }
    .sn-error { font-size:11px; color:var(--sn-danger); }
  `]
})
export class SnInputComponent implements ControlValueAccessor {
  @Input() label = ''
  @Input() type = 'text'
  @Input() placeholder = ''
  @Input() hint = ''
  @Input() errorMsg = ''
  @Input() required = false
  @Input() hasError = false
  @Input() fieldId = `sn-input-${Math.random().toString(36).slice(2,7)}`

  disabled = false
  value = ''

  onChange  = (_: string) => {}
  onTouched = () => {}

  writeValue(v: string)    { this.value = v ?? '' }
  registerOnChange(fn: any)  { this.onChange = fn }
  registerOnTouched(fn: any) { this.onTouched = fn }
  setDisabledState(d: boolean) { this.disabled = d }
}
