import { Component, Input, ChangeDetectionStrategy } from '@angular/core'
import { CommonModule } from '@angular/common'
@Component({
  selector:'sn-kpi-card', standalone:true, imports:[CommonModule],
  changeDetection:ChangeDetectionStrategy.OnPush,
  template:`<div class="kpi"><div class="kpi__label">{{label}}</div><div class="kpi__value">{{value}}</div><div *ngIf="delta" class="kpi__delta" [class.up]="deltaPositive" [class.dn]="deltaPositive===false">{{delta}}</div></div>`,
  styles:[`.kpi{background:var(--sn-surface-3);border-radius:var(--sn-radius-md);padding:var(--sn-space-4)}
  .kpi__label{font-size:11px;font-weight:500;color:var(--sn-text-secondary);text-transform:uppercase;letter-spacing:.05em;margin-bottom:6px}
  .kpi__value{font-size:24px;font-weight:500;color:var(--sn-text-primary)}
  .kpi__delta{font-size:11px;margin-top:4px;color:var(--sn-text-tertiary)}
  .up{color:var(--sn-success)}.dn{color:var(--sn-danger)}`]
})
export class SnKpiCardComponent {
  @Input() label='' @Input() value:string|number=''
  @Input() delta?:string @Input() deltaPositive?:boolean
}
