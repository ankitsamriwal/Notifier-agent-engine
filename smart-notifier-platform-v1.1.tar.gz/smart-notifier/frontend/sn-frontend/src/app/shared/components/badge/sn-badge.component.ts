import { Component, Input, ChangeDetectionStrategy } from '@angular/core'
import { CommonModule } from '@angular/common'
export type BadgeVariant = 'success'|'warning'|'danger'|'info'|'neutral'|'purple'

@Component({
  selector: 'sn-badge', standalone:true, imports:[CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `<span class="b" [class]="'b--'+variant"><ng-content></ng-content></span>`,
  styles: [`.b{display:inline-flex;align-items:center;padding:2px 8px;border-radius:var(--sn-radius-pill);font-size:11px;font-weight:500;white-space:nowrap}
  .b--success{background:var(--sn-success-bg);color:var(--sn-success)}
  .b--warning{background:var(--sn-warning-bg);color:var(--sn-warning)}
  .b--danger{background:var(--sn-danger-bg);color:var(--sn-danger)}
  .b--info{background:var(--sn-info-bg);color:var(--sn-info)}
  .b--purple{background:var(--sn-purple-bg);color:var(--sn-purple)}
  .b--neutral{background:var(--sn-surface-3);color:var(--sn-text-secondary)}`]
})
export class SnBadgeComponent { @Input() variant: BadgeVariant = 'neutral' }
