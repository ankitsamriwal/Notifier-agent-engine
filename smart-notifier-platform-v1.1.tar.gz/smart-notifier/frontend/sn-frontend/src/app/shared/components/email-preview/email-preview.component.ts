import { Component, Input, ChangeDetectionStrategy } from '@angular/core'
import { CommonModule } from '@angular/common'
import { DomSanitizer, SafeHtml } from '@angular/platform-browser'
import { inject } from '@angular/core'

@Component({
  selector: 'sn-email-preview',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="preview-frame" role="region" aria-label="Email preview">
      <div class="preview-chrome">
        <div class="chrome-dots" aria-hidden="true">
          <span></span><span></span><span></span>
        </div>
        <div class="preview-subject">{{ subject || '(No subject)' }}</div>
      </div>
      <div class="preview-meta">
        <span class="meta-to">To: <strong>{{ to || 'recipient@example.com' }}</strong></span>
      </div>
      @if (htmlContent) {
        <div class="preview-body" [innerHTML]="safeHtml" aria-label="Email body preview"></div>
      } @else {
        <div class="preview-empty">
          <p>Email preview will appear here after AI composition.</p>
        </div>
      }
      @if (ctaButtons?.length) {
        <div class="preview-cta" aria-label="Call-to-action buttons">
          <p class="cta-label">CTA buttons (one-click — no form required):</p>
          <div class="cta-row">
            @for (btn of ctaButtons; track btn.key) {
              <span class="cta-btn cta-btn--preview">{{ btn.label }}</span>
            }
          </div>
        </div>
      }
    </div>
  `,
  styles: [`
    .preview-frame { border:1px solid var(--sn-border); border-radius:var(--sn-radius-lg); overflow:hidden; }
    .preview-chrome { display:flex; align-items:center; gap:12px; padding:10px 14px; background:var(--sn-surface-3); border-bottom:1px solid var(--sn-border); }
    .chrome-dots { display:flex; gap:5px; }
    .chrome-dots span { width:10px; height:10px; border-radius:50%; background:var(--sn-border-strong); }
    .preview-subject { font-size:12px; font-weight:500; color:var(--sn-text-primary); flex:1; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
    .preview-meta { padding:8px 14px; border-bottom:1px solid var(--sn-border); font-size:11px; color:var(--sn-text-secondary); background:var(--sn-surface); }
    .meta-to strong { color:var(--sn-text-primary); }
    .preview-body { padding:16px; font-size:12px; line-height:1.7; background:#fff; min-height:150px; color:#1a1a1a; max-height:400px; overflow-y:auto; }
    .preview-empty { padding:40px; text-align:center; color:var(--sn-text-tertiary); font-size:12px; background:var(--sn-surface-2); }
    .preview-cta { padding:12px 14px; border-top:1px solid var(--sn-border); background:var(--sn-surface-3); }
    .cta-label { font-size:10px; color:var(--sn-text-secondary); margin-bottom:8px; }
    .cta-row { display:flex; gap:6px; flex-wrap:wrap; }
    .cta-btn--preview {
      padding:5px 12px; border-radius:100px; font-size:11px; font-weight:500;
      background:var(--sn-blue); color:#fff; cursor:default;
    }
    .cta-btn--preview:nth-child(2) { background:var(--sn-success); }
    .cta-btn--preview:nth-child(3) { background:var(--sn-purple); }
    .cta-btn--preview:nth-child(4) { background:var(--sn-warning); }
  `]
})
export class EmailPreviewComponent {
  private sanitizer = inject(DomSanitizer)

  @Input() subject = ''
  @Input() to = ''
  @Input() ctaButtons: { label: string; key: string }[] = []

  @Input() set htmlContent(v: string) {
    this._html = v
    this.safeHtml = v ? this.sanitizer.bypassSecurityTrustHtml(v) : null
  }
  get htmlContent() { return this._html }

  private _html = ''
  safeHtml: SafeHtml | null = null
}
