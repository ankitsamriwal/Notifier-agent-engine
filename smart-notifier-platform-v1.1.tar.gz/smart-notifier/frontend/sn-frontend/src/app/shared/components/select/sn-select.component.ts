import { Component, Input, forwardRef, ChangeDetectionStrategy } from '@angular/core'
import { ControlValueAccessor, NG_VALUE_ACCESSOR, FormsModule } from '@angular/forms'
import { CommonModule } from '@angular/common'

export interface SelectOption { label: string; value: string }

@Component({
  selector: 'sn-select',
  standalone: true,
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: forwardRef(() => SnSelectComponent), multi: true }],
  template: `
    <div class="sn-field">
      @if (label) { <label class="sn-label" [for]="fieldId">{{ label }}</label> }
      <div class="sn-select-wrap">
        <select [id]="fieldId" class="sn-select" [disabled]="disabled" [(ngModel)]="value" (blur)="onTouched()">
          @if (placeholder) { <option value="" disabled>{{ placeholder }}</option> }
          @for (opt of options; track opt.value) {
            <option [value]="opt.value">{{ opt.label }}</option>
          }
        </select>
        <span class="sn-select-arrow" aria-hidden="true">▾</span>
      </div>
    </div>
  `,
  styles: [`
    .sn-field { display:flex; flex-direction:column; gap:5px; }
    .sn-label { font-size:12px; font-weight:500; color:var(--sn-text-primary); }
    .sn-select-wrap { position:relative; }
    .sn-select {
      width:100%; padding:8px 32px 8px 11px; border:1px solid var(--sn-border-strong);
      border-radius:var(--sn-radius-md); font-size:13px; appearance:none;
      background:var(--sn-surface); color:var(--sn-text-primary); cursor:pointer;
      transition:border-color var(--sn-transition), box-shadow var(--sn-transition);
    }
    .sn-select:focus { outline:none; border-color:var(--sn-blue); box-shadow:0 0 0 3px rgba(24,95,165,0.18); }
    .sn-select:disabled { opacity:0.5; cursor:not-allowed; }
    .sn-select-arrow { position:absolute; right:10px; top:50%; transform:translateY(-50%); pointer-events:none; font-size:11px; color:var(--sn-text-secondary); }
  `]
})
export class SnSelectComponent implements ControlValueAccessor {
  @Input() label = ''
  @Input() placeholder = ''
  @Input() options: SelectOption[] = []
  @Input() fieldId = `sn-select-${Math.random().toString(36).slice(2,7)}`

  disabled = false
  value = ''
  onChange  = (_: string) => {}
  onTouched = () => {}
  writeValue(v: string)    { this.value = v ?? '' }
  registerOnChange(fn: any)  { this.onChange = fn }
  registerOnTouched(fn: any) { this.onTouched = fn }
  setDisabledState(d: boolean) { this.disabled = d }
}
