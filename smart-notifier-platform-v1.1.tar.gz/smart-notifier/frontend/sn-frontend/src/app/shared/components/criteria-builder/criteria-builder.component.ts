import {
  Component, Input, Output, EventEmitter,
  ChangeDetectionStrategy, signal, computed
} from '@angular/core'
import { CommonModule } from '@angular/common'
import { FormsModule } from '@angular/forms'
import { CdkDragDrop, CdkDropList, CdkDrag, moveItemInArray } from '@angular/cdk/drag-drop'
import type { JobCriteria, Criterion } from '../../../core/models/job.model'

const OPERATORS = [
  { label: 'is greater than',    value: 'greater_than' },
  { label: 'is less than',       value: 'less_than' },
  { label: 'equals',             value: 'equals' },
  { label: 'does not equal',     value: 'not_equals' },
  { label: 'contains',          value: 'contains' },
  { label: 'does not contain',  value: 'not_contains' },
  { label: 'is empty',           value: 'is_empty' },
  { label: 'is not empty',       value: 'is_not_empty' },
  { label: 'matches regex',      value: 'regex' },
  { label: 'is before date',     value: 'date_before' },
  { label: 'is after date',      value: 'date_after' },
]

const NO_VALUE_OPS = new Set(['is_empty', 'is_not_empty'])

@Component({
  selector: 'sn-criteria-builder',
  standalone: true,
  imports: [CommonModule, FormsModule, CdkDropList, CdkDrag],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="cb" role="group" aria-label="Notification criteria builder">

      <!-- Logic toggle -->
      <div class="cb__logic" role="group" aria-label="Logic operator">
        <span class="cb__logic-label">Match</span>
        <div class="logic-toggle">
          <button type="button" class="logic-btn" [class.active]="criteria().logic === 'AND'"
                  (click)="setLogic('AND')" aria-label="Match ALL conditions">
            ALL
          </button>
          <button type="button" class="logic-btn" [class.active]="criteria().logic === 'OR'"
                  (click)="setLogic('OR')" aria-label="Match ANY condition">
            ANY
          </button>
        </div>
        <span class="cb__logic-label">of the following conditions:</span>
      </div>

      <!-- Conditions list (CDK DragDrop for reordering) -->
      <div cdkDropList class="cb__list" (cdkDropListDropped)="onDrop($event)"
           [attr.aria-label]="criteria().conditions.length + ' conditions'">

        @for (condition of criteria().conditions; track $index; let i = $index) {
          <div cdkDrag class="condition-row" [attr.aria-label]="'Condition ' + (i+1)">

            <!-- Drag handle -->
            <button type="button" cdkDragHandle class="drag-handle" aria-label="Drag to reorder">
              <svg width="14" height="14" viewBox="0 0 14 14" fill="currentColor" aria-hidden="true">
                <circle cx="5" cy="3.5" r="1.2"/><circle cx="9" cy="3.5" r="1.2"/>
                <circle cx="5" cy="7" r="1.2"/><circle cx="9" cy="7" r="1.2"/>
                <circle cx="5" cy="10.5" r="1.2"/><circle cx="9" cy="10.5" r="1.2"/>
              </svg>
            </button>

            <!-- Field selector -->
            <select class="cb-select" [(ngModel)]="condition.field"
                    (ngModelChange)="emit()" [attr.aria-label]="'Field for condition ' + (i+1)">
              <option value="">Select field…</option>
              @for (f of schemaFields; track f) {
                <option [value]="f">{{ f }}</option>
              }
            </select>

            <!-- Operator -->
            <select class="cb-select cb-select--op" [(ngModel)]="condition.op"
                    (ngModelChange)="emit()" [attr.aria-label]="'Operator for condition ' + (i+1)">
              @for (op of operators; track op.value) {
                <option [value]="op.value">{{ op.label }}</option>
              }
            </select>

            <!-- Value (hidden for is_empty / is_not_empty) -->
            @if (!noValueOps.has(condition.op)) {
              <input type="text" class="cb-input" [(ngModel)]="condition.value"
                     (ngModelChange)="emit()" placeholder="Value…"
                     [attr.aria-label]="'Value for condition ' + (i+1)">
            }

            <!-- Remove condition -->
            <button type="button" class="remove-btn" (click)="removeCondition(i)"
                    [attr.aria-label]="'Remove condition ' + (i+1)">
              <svg width="13" height="13" viewBox="0 0 13 13" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true">
                <path d="M2 2l9 9M11 2L2 11"/>
              </svg>
            </button>
          </div>
        } @empty {
          <div class="cb__empty">
            <p>No conditions yet. Add a condition to filter your data.</p>
          </div>
        }
      </div>

      <!-- Add condition button -->
      <button type="button" class="cb__add" (click)="addCondition()">
        <svg width="13" height="13" viewBox="0 0 13 13" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true">
          <path d="M6.5 1v11M1 6.5h11"/>
        </svg>
        Add condition
      </button>

      <!-- Live summary -->
      @if (criteria().conditions.length > 0) {
        <div class="cb__summary" aria-live="polite">
          Will match rows where
          <strong>{{ criteria().conditions.length }} condition{{ criteria().conditions.length > 1 ? 's' : '' }}</strong>
          are met ({{ criteria().logic === 'AND' ? 'all' : 'any' }}).
        </div>
      }
    </div>
  `,
  styles: [`
    .cb { display:flex; flex-direction:column; gap:10px; }
    .cb__logic { display:flex; align-items:center; gap:10px; flex-wrap:wrap; }
    .cb__logic-label { font-size:12px; color:var(--sn-text-secondary); }
    .logic-toggle { display:flex; border:1px solid var(--sn-border-strong); border-radius:var(--sn-radius-md); overflow:hidden; }
    .logic-btn { padding:5px 14px; font-size:12px; font-weight:500; border:none; background:var(--sn-surface); color:var(--sn-text-secondary); cursor:pointer; transition:background var(--sn-transition); }
    .logic-btn.active { background:var(--sn-blue); color:#fff; }

    .cb__list { display:flex; flex-direction:column; gap:6px; min-height:40px; }
    .condition-row {
      display:flex; align-items:center; gap:8px;
      padding:10px 12px; background:var(--sn-surface);
      border:1px solid var(--sn-border); border-radius:var(--sn-radius-md);
      transition:border-color var(--sn-transition), box-shadow var(--sn-transition);
    }
    .condition-row:hover { border-color:var(--sn-border-strong); }
    .cdk-drag-preview { border:1px solid var(--sn-blue); box-shadow:var(--sn-shadow-md); border-radius:var(--sn-radius-md); }
    .cdk-drag-placeholder { opacity:0.4; background:var(--sn-surface-3); }
    .cdk-drag-animating { transition:transform 200ms ease; }
    .drag-handle { background:transparent; border:none; color:var(--sn-text-tertiary); cursor:grab; padding:2px; display:flex; align-items:center; flex-shrink:0; }
    .drag-handle:active { cursor:grabbing; }

    .cb-select, .cb-input {
      padding:6px 10px; border:1px solid var(--sn-border-strong);
      border-radius:var(--sn-radius-sm); font-size:12px;
      background:var(--sn-surface); color:var(--sn-text-primary);
      transition:border-color var(--sn-transition);
    }
    .cb-select:focus, .cb-input:focus { outline:none; border-color:var(--sn-blue); }
    .cb-select { min-width:120px; }
    .cb-select--op { min-width:160px; }
    .cb-input { flex:1; min-width:80px; }

    .remove-btn { background:transparent; border:none; color:var(--sn-text-tertiary); cursor:pointer; padding:4px; display:flex; align-items:center; flex-shrink:0; border-radius:var(--sn-radius-sm); transition:color var(--sn-transition), background var(--sn-transition); }
    .remove-btn:hover { color:var(--sn-danger); background:var(--sn-danger-bg); }

    .cb__empty { padding:20px; text-align:center; color:var(--sn-text-secondary); font-size:12px; background:var(--sn-surface-3); border-radius:var(--sn-radius-md); }
    .cb__add { display:flex; align-items:center; gap:6px; padding:7px 14px; font-size:12px; font-weight:500; color:var(--sn-blue); background:var(--sn-blue-light); border:1px dashed rgba(24,95,165,0.4); border-radius:var(--sn-radius-md); cursor:pointer; transition:all var(--sn-transition); align-self:flex-start; }
    .cb__add:hover { background:var(--sn-blue); color:#fff; border-style:solid; }
    .cb__summary { font-size:11px; color:var(--sn-text-secondary); padding:6px 10px; background:var(--sn-surface-3); border-radius:var(--sn-radius-sm); }
  `]
})
export class CriteriaBuilderComponent {
  @Input() set value(v: JobCriteria) {
    this._criteria.set(v ?? { logic: 'AND', conditions: [] })
  }
  @Input() schemaFields: string[] = []
  @Output() valueChange = new EventEmitter<JobCriteria>()

  private _criteria = signal<JobCriteria>({ logic: 'AND', conditions: [] })
  criteria = this._criteria.asReadonly()

  readonly operators = OPERATORS
  readonly noValueOps = NO_VALUE_OPS

  setLogic(logic: 'AND' | 'OR') {
    this._criteria.update(c => ({ ...c, logic }))
    this.emit()
  }

  addCondition() {
    this._criteria.update(c => ({
      ...c,
      conditions: [...c.conditions, { field: '', op: 'greater_than', value: '' }]
    }))
    this.emit()
  }

  removeCondition(index: number) {
    this._criteria.update(c => ({
      ...c,
      conditions: c.conditions.filter((_, i) => i !== index)
    }))
    this.emit()
  }

  onDrop(event: CdkDragDrop<Criterion[]>) {
    const conditions = [...this._criteria().conditions]
    moveItemInArray(conditions, event.previousIndex, event.currentIndex)
    this._criteria.update(c => ({ ...c, conditions }))
    this.emit()
  }

  emit() {
    this.valueChange.emit({ ...this._criteria() })
  }
}
