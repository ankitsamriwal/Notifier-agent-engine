import {
  Component, OnDestroy, ChangeDetectionStrategy, ChangeDetectorRef, inject
} from '@angular/core'
import { CommonModule } from '@angular/common'
import { animate, style, transition, trigger } from '@angular/animations'

export interface Toast {
  id: string
  message: string
  variant: 'success' | 'error' | 'info' | 'warning'
  duration?: number
}

import { Injectable, signal } from '@angular/core'

@Injectable({ providedIn: 'root' })
export class ToastService {
  readonly toasts = signal<Toast[]>([])

  show(message: string, variant: Toast['variant'] = 'info', duration = 4000) {
    const id = Math.random().toString(36).slice(2)
    this.toasts.update(t => [...t, { id, message, variant, duration }])
    if (duration > 0) setTimeout(() => this.dismiss(id), duration)
    return id
  }

  success(msg: string) { return this.show(msg, 'success') }
  error(msg: string)   { return this.show(msg, 'error', 6000) }
  info(msg: string)    { return this.show(msg, 'info') }
  warning(msg: string) { return this.show(msg, 'warning') }

  dismiss(id: string) {
    this.toasts.update(t => t.filter(toast => toast.id !== id))
  }
}

@Component({
  selector: 'sn-toast-host',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [
    trigger('slideUp', [
      transition(':enter', [
        style({ transform: 'translateY(20px)', opacity: 0 }),
        animate('200ms ease', style({ transform: 'none', opacity: 1 }))
      ]),
      transition(':leave', [
        animate('160ms ease', style({ transform: 'translateY(-10px)', opacity: 0 }))
      ])
    ])
  ],
  template: `
    <div class="toast-host" role="region" aria-label="Notifications" aria-live="polite">
      @for (toast of toastSvc.toasts(); track toast.id) {
        <div class="toast" [class]="'toast--' + toast.variant" @slideUp role="alert">
          <span class="toast-icon" aria-hidden="true">
            {{ toast.variant === 'success' ? '✓' : toast.variant === 'error' ? '✕' : toast.variant === 'warning' ? '!' : 'i' }}
          </span>
          <span class="toast-msg">{{ toast.message }}</span>
          <button class="toast-close" (click)="toastSvc.dismiss(toast.id)" aria-label="Dismiss notification">✕</button>
        </div>
      }
    </div>
  `,
  styles: [`
    .toast-host { position:fixed; bottom:24px; right:24px; display:flex; flex-direction:column; gap:8px; z-index:500; max-width:380px; }
    .toast { display:flex; align-items:center; gap:10px; padding:12px 14px; border-radius:var(--sn-radius-md); box-shadow:var(--sn-shadow-md); font-size:13px; }
    .toast--success { background:var(--sn-success-bg); color:var(--sn-success); border:1px solid rgba(59,109,17,0.2); }
    .toast--error { background:var(--sn-danger-bg); color:var(--sn-danger); border:1px solid rgba(163,45,45,0.2); }
    .toast--info { background:var(--sn-info-bg); color:var(--sn-info); border:1px solid rgba(24,95,165,0.2); }
    .toast--warning { background:var(--sn-warning-bg); color:var(--sn-warning); border:1px solid rgba(133,79,11,0.2); }
    .toast-icon { font-size:14px; font-weight:600; flex-shrink:0; }
    .toast-msg { flex:1; line-height:1.4; }
    .toast-close { background:transparent; border:none; cursor:pointer; color:currentColor; opacity:0.6; font-size:12px; flex-shrink:0; padding:2px; }
    .toast-close:hover { opacity:1; }
  `]
})
export class SnToastHostComponent {
  toastSvc = inject(ToastService)
}
