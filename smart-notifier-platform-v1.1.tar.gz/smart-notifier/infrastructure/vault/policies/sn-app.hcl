path "secret/data/connectors/*" {
  capabilities = ["read", "list"]
}
path "secret/data/channels/*" {
  capabilities = ["read", "list", "create", "update"]
}
path "transit/sign/sn-jwt-key" {
  capabilities = ["create", "update"]
}
path "transit/verify/sn-jwt-key" {
  capabilities = ["create", "update"]
}
