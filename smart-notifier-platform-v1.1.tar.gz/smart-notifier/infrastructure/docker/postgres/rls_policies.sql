-- ═══════════════════════════════════════════════════════════════════
--  Row Level Security Policies — Tenant Isolation
--  All tenant-scoped tables enforce isolation at the DB layer.
--  Application sets: SET LOCAL app.tenant_id = '...' in each transaction.
--  super_admin bypass: SET LOCAL app.role = 'super_admin'
-- ═══════════════════════════════════════════════════════════════════

-- ── Enable RLS on all tenant-scoped tables ─────────────────────

ALTER TABLE users                ENABLE ROW LEVEL SECURITY;
ALTER TABLE connectors           ENABLE ROW LEVEL SECURITY;
ALTER TABLE jobs                 ENABLE ROW LEVEL SECURITY;
ALTER TABLE notification_runs    ENABLE ROW LEVEL SECURITY;
ALTER TABLE approval_events      ENABLE ROW LEVEL SECURITY;
ALTER TABLE cta_signals          ENABLE ROW LEVEL SECURITY;
ALTER TABLE effectiveness_metrics ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_prompt_logs       ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_events         ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_insights          ENABLE ROW LEVEL SECURITY;
ALTER TABLE channel_credentials  ENABLE ROW LEVEL SECURITY;

-- ── Helper function: get current tenant from session ───────────

CREATE OR REPLACE FUNCTION current_tenant_id() RETURNS UUID AS $$
BEGIN
    RETURN NULLIF(current_setting('app.tenant_id', TRUE), '')::UUID;
EXCEPTION
    WHEN OTHERS THEN RETURN NULL;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER;

CREATE OR REPLACE FUNCTION is_super_admin() RETURNS BOOLEAN AS $$
BEGIN
    RETURN COALESCE(current_setting('app.role', TRUE), '') = 'super_admin';
EXCEPTION
    WHEN OTHERS THEN RETURN FALSE;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER;

-- ── RLS Policies ────────────────────────────────────────────────

-- Users
CREATE POLICY users_tenant_isolation ON users
    USING (is_super_admin() OR tenant_id = current_tenant_id());

CREATE POLICY users_insert_isolation ON users
    FOR INSERT WITH CHECK (tenant_id = current_tenant_id());

-- Connectors
CREATE POLICY connectors_tenant_isolation ON connectors
    USING (is_super_admin() OR tenant_id = current_tenant_id());

CREATE POLICY connectors_insert_isolation ON connectors
    FOR INSERT WITH CHECK (tenant_id = current_tenant_id());

-- Jobs
CREATE POLICY jobs_tenant_isolation ON jobs
    USING (is_super_admin() OR tenant_id = current_tenant_id());

CREATE POLICY jobs_insert_isolation ON jobs
    FOR INSERT WITH CHECK (tenant_id = current_tenant_id());

-- Notification Runs
CREATE POLICY runs_tenant_isolation ON notification_runs
    USING (is_super_admin() OR tenant_id = current_tenant_id());

CREATE POLICY runs_insert_isolation ON notification_runs
    FOR INSERT WITH CHECK (tenant_id = current_tenant_id());

-- Approval Events
CREATE POLICY approval_events_isolation ON approval_events
    USING (is_super_admin() OR tenant_id = current_tenant_id());

CREATE POLICY approval_events_insert_isolation ON approval_events
    FOR INSERT WITH CHECK (tenant_id = current_tenant_id());

-- CTA Signals
CREATE POLICY cta_signals_isolation ON cta_signals
    USING (is_super_admin() OR tenant_id = current_tenant_id());

CREATE POLICY cta_signals_insert_isolation ON cta_signals
    FOR INSERT WITH CHECK (tenant_id = current_tenant_id());

-- Effectiveness Metrics
CREATE POLICY effectiveness_isolation ON effectiveness_metrics
    USING (is_super_admin() OR tenant_id = current_tenant_id());

-- AI Prompt Logs
CREATE POLICY ai_logs_isolation ON ai_prompt_logs
    USING (is_super_admin() OR tenant_id = current_tenant_id());

-- Audit Events (all tenants can insert their own; super_admin can read all)
CREATE POLICY audit_read_isolation ON audit_events
    FOR SELECT USING (
        is_super_admin()
        OR tenant_id = current_tenant_id()
        OR tenant_id IS NULL  -- platform events visible to super_admin only
    );

CREATE POLICY audit_insert_isolation ON audit_events
    FOR INSERT WITH CHECK (
        tenant_id = current_tenant_id()
        OR tenant_id IS NULL
    );

-- AI Insights
CREATE POLICY insights_isolation ON ai_insights
    USING (is_super_admin() OR tenant_id = current_tenant_id());

-- Channel Credentials
CREATE POLICY channel_creds_isolation ON channel_credentials
    USING (is_super_admin() OR tenant_id = current_tenant_id());
