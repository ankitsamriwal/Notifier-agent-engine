-- ═══════════════════════════════════════════════════════════════════
--  Smart Notifier Platform — PostgreSQL 16 Schema
--  DESC/NESA compliant: RLS, audit triggers, append-only audit log
--  Run order: 01_init.sql → 03_audit_trigger.sql → 04_rls_policies.sql
-- ═══════════════════════════════════════════════════════════════════

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgvector";
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ─────────────────────────────────────────────────────────────────
--  TENANTS
-- ─────────────────────────────────────────────────────────────────

CREATE TABLE tenants (
    tenant_id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name               TEXT NOT NULL,
    slug               TEXT NOT NULL UNIQUE,
    status             TEXT NOT NULL DEFAULT 'active'
                           CHECK (status IN ('active', 'suspended', 'trial')),
    -- Branding (white-label)
    branding           JSONB NOT NULL DEFAULT '{
        "logoUrl": null,
        "primaryColor": "#185FA5",
        "fontFamily": "Inter, sans-serif",
        "companyName": null
    }',
    -- Channel config per tenant
    enabled_channels   TEXT[] NOT NULL DEFAULT ARRAY['gmail'],
    -- LLM config per tenant (overrides platform default)
    llm_config         JSONB NOT NULL DEFAULT '{
        "backend": "anthropic",
        "model": "claude-sonnet-4-20250514"
    }',
    -- Compliance & data governance
    data_residency     TEXT NOT NULL DEFAULT 'uae',
    retention_days     INTEGER NOT NULL DEFAULT 730,
    -- Allowed email domains for tenant users
    allowed_domains    TEXT[] DEFAULT NULL,
    -- DESC/NESA compliance flags
    desc_compliant     BOOLEAN NOT NULL DEFAULT FALSE,
    nesa_compliant     BOOLEAN NOT NULL DEFAULT FALSE,
    mfa_required       BOOLEAN NOT NULL DEFAULT FALSE,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─────────────────────────────────────────────────────────────────
--  USERS
-- ─────────────────────────────────────────────────────────────────

CREATE TABLE users (
    user_id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id          UUID NOT NULL REFERENCES tenants(tenant_id) ON DELETE CASCADE,
    email              TEXT NOT NULL,
    display_name       TEXT NOT NULL,
    -- Role: super_admin | tenant_admin | operator | viewer | auditor
    roles              TEXT[] NOT NULL DEFAULT ARRAY['viewer'],
    status             TEXT NOT NULL DEFAULT 'active'
                           CHECK (status IN ('active', 'suspended', 'pending_mfa')),
    -- Auth
    password_hash      TEXT,            -- Argon2id hash (NULL for SSO users)
    mfa_secret         TEXT,            -- TOTP secret (encrypted in app layer)
    mfa_enabled        BOOLEAN NOT NULL DEFAULT FALSE,
    -- Login tracking (DESC ISR 9.3)
    last_login_at      TIMESTAMPTZ,
    failed_login_count INTEGER NOT NULL DEFAULT 0,
    locked_until       TIMESTAMPTZ,
    -- Token management
    token_version      INTEGER NOT NULL DEFAULT 0,  -- increment to invalidate JWTs
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(tenant_id, email)
);

CREATE INDEX idx_users_tenant ON users(tenant_id);
CREATE INDEX idx_users_email ON users(email);

-- ─────────────────────────────────────────────────────────────────
--  CONNECTORS (source data adapters)
-- ─────────────────────────────────────────────────────────────────

CREATE TABLE connectors (
    connector_id       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id          UUID NOT NULL REFERENCES tenants(tenant_id) ON DELETE CASCADE,
    name               TEXT NOT NULL,
    -- Type: file_upload | google_drive | sharepoint | file_server |
    --       d365_fo | d365_ce | salesforce | hubspot |
    --       postgresql | mysql | mssql | cosmosdb | rest_api | graphql
    connector_type     TEXT NOT NULL,
    status             TEXT NOT NULL DEFAULT 'active'
                           CHECK (status IN ('active', 'error', 'needs_reauth', 'disabled')),
    -- Connector-specific config (non-sensitive only — no credentials here)
    config             JSONB NOT NULL DEFAULT '{}',
    -- Vault path for credentials (never stored in DB)
    credential_ref     TEXT,
    -- Cached schema from last fetch
    schema_cache       JSONB,
    schema_cached_at   TIMESTAMPTZ,
    -- Health tracking
    last_fetched_at    TIMESTAMPTZ,
    last_error         TEXT,
    fetch_count        INTEGER NOT NULL DEFAULT 0,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_connectors_tenant ON connectors(tenant_id);
CREATE INDEX idx_connectors_type ON connectors(connector_type);

-- ─────────────────────────────────────────────────────────────────
--  JOBS (notification job configurations)
-- ─────────────────────────────────────────────────────────────────

CREATE TABLE jobs (
    job_id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id          UUID NOT NULL REFERENCES tenants(tenant_id) ON DELETE CASCADE,
    connector_id       UUID REFERENCES connectors(connector_id) ON DELETE SET NULL,
    name               TEXT NOT NULL,
    description        TEXT,
    status             TEXT NOT NULL DEFAULT 'draft'
                           CHECK (status IN ('active', 'paused', 'draft', 'archived')),
    -- Criteria rules stored as JSON tree
    -- {"logic": "AND", "conditions": [{"field": "...", "op": "...", "value": "..."}]}
    criteria           JSONB NOT NULL DEFAULT '{"logic":"AND","conditions":[]}',
    -- Tone: Professional | Urgent | Friendly | Formal | Firm | Concise
    tone               TEXT NOT NULL DEFAULT 'Professional',
    -- Channel: gmail | outlook | whatsapp | teams | slack | webhook
    channel            TEXT NOT NULL DEFAULT 'gmail',
    -- Recipients: {"to": "{{Email}}", "cc": "finance@co.ae", "bcc": null}
    recipients         JSONB NOT NULL DEFAULT '{"to":"","cc":null,"bcc":null}',
    -- Email template
    template           JSONB NOT NULL DEFAULT '{
        "subject": "",
        "bodyHint": "",
        "bodyDraft": null
    }',
    -- Schedule: {"type": "cron|polling|webhook|manual", "cron": "0 8 * * *", "timezone": "Asia/Dubai"}
    schedule           JSONB NOT NULL DEFAULT '{"type":"manual","timezone":"Asia/Dubai"}',
    -- Approval: draft | manual | auto
    approval_mode      TEXT NOT NULL DEFAULT 'manual'
                           CHECK (approval_mode IN ('draft', 'manual', 'auto')),
    -- Options
    options            JSONB NOT NULL DEFAULT '{
        "includeDataTable": true,
        "attachPDF": false,
        "attachFiles": [],
        "digestMode": "digest",
        "ctaButtons": []
    }',
    -- Run tracking
    last_run_at        TIMESTAMPTZ,
    last_run_status    TEXT,
    total_runs         INTEGER NOT NULL DEFAULT 0,
    created_by         UUID REFERENCES users(user_id),
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_jobs_tenant ON jobs(tenant_id);
CREATE INDEX idx_jobs_status ON jobs(status);
CREATE INDEX idx_jobs_channel ON jobs(channel);
CREATE INDEX idx_jobs_connector ON jobs(connector_id);

-- ─────────────────────────────────────────────────────────────────
--  NOTIFICATION RUNS
-- ─────────────────────────────────────────────────────────────────

CREATE TABLE notification_runs (
    run_id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    job_id             UUID NOT NULL REFERENCES jobs(job_id) ON DELETE CASCADE,
    tenant_id          UUID NOT NULL REFERENCES tenants(tenant_id) ON DELETE CASCADE,
    -- Trigger info
    triggered_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    trigger_type       TEXT NOT NULL
                           CHECK (trigger_type IN ('cron', 'manual', 'webhook', 'polling')),
    triggered_by       UUID REFERENCES users(user_id),
    -- Execution state machine
    -- pending_fetch → fetching → pending_rules → evaluating →
    -- pending_compose → composing → pending_approval → approved/rejected →
    -- dispatching → sent/failed/skipped
    status             TEXT NOT NULL DEFAULT 'pending_fetch',
    -- Data
    match_count        INTEGER,
    total_rows         INTEGER,
    -- Email preview (stored for approval UI)
    composed_subject   TEXT,
    composed_html      TEXT,   -- Stored encrypted in production
    composed_text      TEXT,
    -- Approval
    approval_mode      TEXT,
    approval_status    TEXT,
    approved_by        UUID REFERENCES users(user_id),
    approved_at        TIMESTAMPTZ,
    -- Delivery
    draft_id           TEXT,   -- Gmail/Outlook draft ID
    provider_ref       TEXT,   -- Provider message ID after send
    sent_at            TIMESTAMPTZ,
    -- Error handling
    error_message      TEXT,
    retry_count        INTEGER NOT NULL DEFAULT 0,
    -- Timing
    fetch_duration_ms  INTEGER,
    rules_duration_ms  INTEGER,
    compose_duration_ms INTEGER,
    total_duration_ms  INTEGER,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_runs_job ON notification_runs(job_id);
CREATE INDEX idx_runs_tenant ON notification_runs(tenant_id);
CREATE INDEX idx_runs_status ON notification_runs(status);
CREATE INDEX idx_runs_triggered_at ON notification_runs(triggered_at DESC);

-- ─────────────────────────────────────────────────────────────────
--  APPROVAL EVENTS (full state machine history per run)
-- ─────────────────────────────────────────────────────────────────

CREATE TABLE approval_events (
    event_id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    run_id             UUID NOT NULL REFERENCES notification_runs(run_id) ON DELETE CASCADE,
    tenant_id          UUID NOT NULL,
    -- Action: review_started | approved | rejected | modified | dispatched | expired
    action             TEXT NOT NULL,
    actor_id           UUID REFERENCES users(user_id),
    -- Modifications made before approval
    modifications      JSONB,
    -- Signed approval token (Ed25519)
    approval_token     TEXT,
    note               TEXT,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_approval_run ON approval_events(run_id);

-- ─────────────────────────────────────────────────────────────────
--  CTA SIGNALS (one-click response tracking)
-- ─────────────────────────────────────────────────────────────────

CREATE TABLE cta_signals (
    signal_id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    run_id             UUID NOT NULL REFERENCES notification_runs(run_id) ON DELETE CASCADE,
    job_id             UUID NOT NULL REFERENCES jobs(job_id) ON DELETE CASCADE,
    tenant_id          UUID NOT NULL REFERENCES tenants(tenant_id) ON DELETE CASCADE,
    -- Recipient identifier (hashed email for privacy — DESC ISR 11.1)
    recipient_hash     TEXT NOT NULL,
    -- The CTA button that was clicked
    button_label       TEXT NOT NULL,
    -- Channel the notification was sent via
    channel            TEXT NOT NULL,
    -- Click metadata
    clicked_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    -- IP hashed with SHA-256 (GDPR/NESA privacy compliance)
    ip_hash            TEXT,
    user_agent_hash    TEXT,
    -- Outcome verification
    outcome_verified   BOOLEAN,
    verified_at        TIMESTAMPTZ,
    verification_data  JSONB,   -- What was checked in source system
    -- Dedup: prevent double-counting same click
    idempotency_key    TEXT NOT NULL UNIQUE,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_cta_run ON cta_signals(run_id);
CREATE INDEX idx_cta_job ON cta_signals(job_id);
CREATE INDEX idx_cta_tenant ON cta_signals(tenant_id);
CREATE INDEX idx_cta_clicked_at ON cta_signals(clicked_at DESC);
CREATE INDEX idx_cta_button_label ON cta_signals(button_label);
CREATE INDEX idx_cta_channel ON cta_signals(channel);

-- ─────────────────────────────────────────────────────────────────
--  EFFECTIVENESS METRICS (pre-computed — refreshed nightly)
-- ─────────────────────────────────────────────────────────────────

CREATE TABLE effectiveness_metrics (
    metric_id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id          UUID NOT NULL REFERENCES tenants(tenant_id) ON DELETE CASCADE,
    job_id             UUID REFERENCES jobs(job_id) ON DELETE SET NULL,
    -- Dimension: day_of_week | month_position | tone | channel |
    --            hour_of_day | job_type | frequency
    dimension          TEXT NOT NULL,
    dimension_value    TEXT NOT NULL,
    -- Aggregated counts
    sends              INTEGER NOT NULL DEFAULT 0,
    opens              INTEGER NOT NULL DEFAULT 0,
    cta_responses      INTEGER NOT NULL DEFAULT 0,
    outcomes_verified  INTEGER NOT NULL DEFAULT 0,
    -- Computed rates (0.00 – 1.00)
    open_rate          NUMERIC(5,4),
    cta_rate           NUMERIC(5,4),
    outcome_rate       NUMERIC(5,4),
    -- Period
    period_start       DATE NOT NULL,
    period_end         DATE NOT NULL,
    computed_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(tenant_id, dimension, dimension_value, period_start)
);

CREATE INDEX idx_effectiveness_tenant ON effectiveness_metrics(tenant_id);
CREATE INDEX idx_effectiveness_dimension ON effectiveness_metrics(dimension, dimension_value);

-- ─────────────────────────────────────────────────────────────────
--  AI PROMPT LOGS (30-day retention, schema only — not full content)
-- ─────────────────────────────────────────────────────────────────

CREATE TABLE ai_prompt_logs (
    log_id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id          UUID NOT NULL REFERENCES tenants(tenant_id) ON DELETE CASCADE,
    run_id             UUID REFERENCES notification_runs(run_id) ON DELETE SET NULL,
    -- Log type: analysis | compose | insights | cta_labels
    log_type           TEXT NOT NULL,
    -- Schema sent (no PII — PII redacted before this is stored)
    schema_sent        JSONB,
    pii_fields_redacted TEXT[],
    -- LLM metadata
    model_used         TEXT NOT NULL,
    prompt_tokens      INTEGER,
    completion_tokens  INTEGER,
    latency_ms         INTEGER,
    -- Validation result
    validation_passed  BOOLEAN NOT NULL DEFAULT TRUE,
    validation_error   TEXT,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Auto-expire after 30 days (requires pg_partman or application-level cleanup)
CREATE INDEX idx_ai_logs_created ON ai_prompt_logs(created_at DESC);
CREATE INDEX idx_ai_logs_tenant ON ai_prompt_logs(tenant_id);

-- ─────────────────────────────────────────────────────────────────
--  AUDIT LOG — APPEND ONLY (DESC ISR 12.4 compliant)
--  The trigger in 03_audit_trigger.sql enforces append-only.
-- ─────────────────────────────────────────────────────────────────

CREATE TABLE audit_events (
    event_id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id          UUID,   -- NULL for platform-level events
    actor_id           TEXT NOT NULL,  -- user UUID or 'system'
    actor_ip_hash      TEXT,           -- SHA-256 hashed IP (privacy)
    -- Action taxonomy
    action             TEXT NOT NULL,
    resource_type      TEXT NOT NULL,
    resource_id        TEXT,
    -- Outcome
    outcome            TEXT NOT NULL CHECK (outcome IN ('success', 'failure', 'partial')),
    -- Details (action-specific context — no raw PII)
    details            JSONB NOT NULL DEFAULT '{}',
    -- Distributed trace correlation
    correlation_id     TEXT,
    service_name       TEXT NOT NULL,
    -- Immutable timestamp (set by DB, not application)
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Optimised for compliance queries
CREATE INDEX idx_audit_tenant ON audit_events(tenant_id, created_at DESC);
CREATE INDEX idx_audit_actor ON audit_events(actor_id, created_at DESC);
CREATE INDEX idx_audit_action ON audit_events(action);
CREATE INDEX idx_audit_resource ON audit_events(resource_type, resource_id);
CREATE INDEX idx_audit_created ON audit_events(created_at DESC);

-- ─────────────────────────────────────────────────────────────────
--  AI INSIGHTS (Claude-generated weekly recommendations)
-- ─────────────────────────────────────────────────────────────────

CREATE TABLE ai_insights (
    insight_id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id          UUID NOT NULL REFERENCES tenants(tenant_id) ON DELETE CASCADE,
    job_id             UUID REFERENCES jobs(job_id) ON DELETE SET NULL,
    -- Type: timing | tone | channel | frequency | new_job | cta_label
    insight_type       TEXT NOT NULL,
    -- Priority: high | medium | low
    priority           TEXT NOT NULL DEFAULT 'medium',
    title              TEXT NOT NULL,
    body               TEXT NOT NULL,
    evidence           JSONB NOT NULL DEFAULT '{}',  -- Supporting data points
    confidence         NUMERIC(3,2),  -- 0.00 – 1.00
    -- Lifecycle
    status             TEXT NOT NULL DEFAULT 'active'
                           CHECK (status IN ('active', 'dismissed', 'applied')),
    dismissed_by       UUID REFERENCES users(user_id),
    dismissed_at       TIMESTAMPTZ,
    generated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at         TIMESTAMPTZ NOT NULL DEFAULT NOW() + INTERVAL '14 days'
);

CREATE INDEX idx_insights_tenant ON ai_insights(tenant_id);
CREATE INDEX idx_insights_status ON ai_insights(status);

-- ─────────────────────────────────────────────────────────────────
--  CHANNEL CREDENTIALS (metadata only — actual creds in Vault)
-- ─────────────────────────────────────────────────────────────────

CREATE TABLE channel_credentials (
    cred_id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id          UUID NOT NULL REFERENCES tenants(tenant_id) ON DELETE CASCADE,
    channel            TEXT NOT NULL,
    display_name       TEXT NOT NULL,
    -- Vault path where actual credential is stored
    vault_path         TEXT NOT NULL,
    status             TEXT NOT NULL DEFAULT 'connected'
                           CHECK (status IN ('connected', 'disconnected', 'needs_reauth', 'error')),
    -- Email account this credential belongs to
    account_email      TEXT,
    last_verified_at   TIMESTAMPTZ,
    last_error         TEXT,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(tenant_id, channel, account_email)
);

CREATE INDEX idx_channel_creds_tenant ON channel_credentials(tenant_id);

-- ─────────────────────────────────────────────────────────────────
--  UPDATED_AT TRIGGER FUNCTION
-- ─────────────────────────────────────────────────────────────────

CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply to all tables with updated_at
CREATE TRIGGER trg_tenants_updated_at
    BEFORE UPDATE ON tenants
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_users_updated_at
    BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_connectors_updated_at
    BEFORE UPDATE ON connectors
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_jobs_updated_at
    BEFORE UPDATE ON jobs
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_channel_creds_updated_at
    BEFORE UPDATE ON channel_credentials
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();
