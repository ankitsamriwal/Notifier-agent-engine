-- ═══════════════════════════════════════════════════════════════════
--  Audit Log — Append-Only Enforcement (DESC ISR 12.4)
--  This trigger makes audit_events physically immutable.
--  No application code, compromised admin, or ORM can alter records.
-- ═══════════════════════════════════════════════════════════════════

CREATE OR REPLACE FUNCTION enforce_audit_append_only()
RETURNS TRIGGER AS $$
BEGIN
    RAISE EXCEPTION
        'audit_events is append-only. UPDATE and DELETE are forbidden. (DESC ISR 12.4)'
        USING ERRCODE = 'insufficient_privilege';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Block UPDATE on audit_events
CREATE TRIGGER trg_audit_no_update
    BEFORE UPDATE ON audit_events
    FOR EACH ROW EXECUTE FUNCTION enforce_audit_append_only();

-- Block DELETE on audit_events
CREATE TRIGGER trg_audit_no_delete
    BEFORE DELETE ON audit_events
    FOR EACH ROW EXECUTE FUNCTION enforce_audit_append_only();

-- Block TRUNCATE on audit_events
CREATE OR REPLACE RULE audit_no_truncate AS
    ON DELETE TO audit_events DO INSTEAD NOTHING;

-- ─────────────────────────────────────────────────────────────────
--  Hash chain for tamper detection
--  Each audit event records the SHA-256 hash of the previous event.
--  Breaks in the chain are detectable by the audit verification job.
-- ─────────────────────────────────────────────────────────────────

ALTER TABLE audit_events ADD COLUMN IF NOT EXISTS
    prev_hash TEXT;  -- SHA-256 of previous event_id + created_at

ALTER TABLE audit_events ADD COLUMN IF NOT EXISTS
    row_hash TEXT;   -- SHA-256 of this row's content (computed on insert)

CREATE OR REPLACE FUNCTION compute_audit_hash()
RETURNS TRIGGER AS $$
DECLARE
    v_prev_hash TEXT;
    v_content   TEXT;
BEGIN
    -- Get hash of most recent previous event for this tenant
    SELECT row_hash INTO v_prev_hash
    FROM audit_events
    WHERE tenant_id = NEW.tenant_id OR (NEW.tenant_id IS NULL AND tenant_id IS NULL)
    ORDER BY created_at DESC
    LIMIT 1;

    NEW.prev_hash = COALESCE(v_prev_hash, 'GENESIS');

    -- Compute hash of this row's immutable content
    v_content := CONCAT(
        NEW.event_id::TEXT, '|',
        COALESCE(NEW.tenant_id::TEXT, 'NULL'), '|',
        NEW.actor_id, '|',
        NEW.action, '|',
        NEW.resource_type, '|',
        COALESCE(NEW.resource_id, 'NULL'), '|',
        NEW.outcome, '|',
        NEW.created_at::TEXT, '|',
        NEW.prev_hash
    );

    NEW.row_hash = encode(digest(v_content, 'sha256'), 'hex');
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER trg_audit_hash_chain
    BEFORE INSERT ON audit_events
    FOR EACH ROW EXECUTE FUNCTION compute_audit_hash();

-- ─────────────────────────────────────────────────────────────────
--  Revoke dangerous permissions from application role
-- ─────────────────────────────────────────────────────────────────

-- Application role can only INSERT on audit_events, never UPDATE/DELETE
DO $$
BEGIN
    -- Create app role if it doesn't exist
    IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'sn_app') THEN
        CREATE ROLE sn_app;
    END IF;
END $$;

REVOKE UPDATE, DELETE, TRUNCATE ON audit_events FROM PUBLIC;
REVOKE UPDATE, DELETE, TRUNCATE ON audit_events FROM sn_app;
GRANT INSERT, SELECT ON audit_events TO sn_app;
