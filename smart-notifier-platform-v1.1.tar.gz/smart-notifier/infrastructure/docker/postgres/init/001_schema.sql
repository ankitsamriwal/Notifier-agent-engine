-- ═══════════════════════════════════════════════════════════════════════════
--  Smart Notifier Platform — PostgreSQL Schema v1.0
--  DESC/NESA compliant: RLS, append-only audit, tamper-evident design
--  Runs on first container init via docker-entrypoint-initdb.d
-- ═══════════════════════════════════════════════════════════════════════════

-- Enable extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "vector";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";  -- for full-text search on logs

-- ─────────────────────────────────────────────────────────────────────────────
--  TENANTS & USERS
-- ─────────────────────────────────────────────────────────────────────────────

CREATE TABLE tenants (
  tenant_id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name             TEXT NOT NULL,
  slug             TEXT NOT NULL UNIQUE,
  status           TEXT NOT NULL DEFAULT 'active'
                     CHECK (status IN ('active','suspended','deleted')),
  branding         JSONB NOT NULL DEFAULT '{}',
  -- {"logo_url": "", "primary_color": "#185FA5", "font": "Inter"}
  enabled_channels TEXT[] NOT NULL DEFAULT ARRAY['gmail','outlook'],
  llm_backend      TEXT NOT NULL DEFAULT 'anthropic',
  llm_model        TEXT NOT NULL DEFAULT 'claude-sonnet-4-20250514',
  retention_days   INTEGER NOT NULL DEFAULT 730,
  allowed_domains  TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE users (
  user_id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id        UUID NOT NULL REFERENCES tenants(tenant_id) ON DELETE CASCADE,
  email            TEXT NOT NULL,
  display_name     TEXT NOT NULL,
  password_hash    TEXT,             -- Argon2id hash (NULL for SSO-only users)
  roles            TEXT[] NOT NULL DEFAULT ARRAY['viewer'],
  -- roles: super_admin | tenant_admin | operator | viewer | auditor
  mfa_secret       TEXT,             -- TOTP secret (encrypted at app layer)
  mfa_enabled      BOOLEAN NOT NULL DEFAULT false,
  is_sso_only      BOOLEAN NOT NULL DEFAULT false,
  last_login_at    TIMESTAMPTZ,
  failed_login_count INTEGER NOT NULL DEFAULT 0,
  locked_until     TIMESTAMPTZ,
  status           TEXT NOT NULL DEFAULT 'active'
                     CHECK (status IN ('active','suspended','deleted')),
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(tenant_id, email)
);

-- Session / token revocation list (JWT jti tracking)
CREATE TABLE revoked_tokens (
  jti          TEXT PRIMARY KEY,
  user_id      UUID NOT NULL REFERENCES users(user_id),
  revoked_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at   TIMESTAMPTZ NOT NULL
);
-- Cleanup old entries automatically
CREATE INDEX idx_revoked_tokens_expires ON revoked_tokens(expires_at);

-- ─────────────────────────────────────────────────────────────────────────────
--  CONNECTORS
-- ─────────────────────────────────────────────────────────────────────────────

CREATE TABLE connectors (
  connector_id     UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id        UUID NOT NULL REFERENCES tenants(tenant_id) ON DELETE CASCADE,
  type             TEXT NOT NULL,
  -- file_upload | google_drive | sharepoint | file_server |
  -- d365_fo | d365_ce | salesforce | postgresql | mysql | mssql |
  -- cosmos_db | custom_rest | custom_graphql
  name             TEXT NOT NULL,
  status           TEXT NOT NULL DEFAULT 'active'
                     CHECK (status IN ('active','error','needs_reauth','deleted')),
  config           JSONB NOT NULL DEFAULT '{}',
  -- Non-sensitive config: paths, endpoints, field mappings
  -- Sensitive: stored in Vault at secret/connectors/{tenant_id}/{connector_id}
  credential_ref   TEXT,            -- Vault path
  schema_cache     JSONB,           -- cached SchemaDefinition
  schema_cached_at TIMESTAMPTZ,
  last_fetched_at  TIMESTAMPTZ,
  last_error       TEXT,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─────────────────────────────────────────────────────────────────────────────
--  JOBS
-- ─────────────────────────────────────────────────────────────────────────────

CREATE TABLE jobs (
  job_id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id        UUID NOT NULL REFERENCES tenants(tenant_id) ON DELETE CASCADE,
  name             TEXT NOT NULL,
  description      TEXT NOT NULL DEFAULT '',
  status           TEXT NOT NULL DEFAULT 'draft'
                     CHECK (status IN ('active','paused','draft')),
  connector_id     UUID NOT NULL REFERENCES connectors(connector_id),
  criteria         JSONB NOT NULL DEFAULT '{"logic":"AND","conditions":[]}',
  tone             TEXT NOT NULL DEFAULT 'Professional'
                     CHECK (tone IN ('Professional','Urgent','Friendly','Formal','Firm','Concise')),
  channel          TEXT NOT NULL
                     CHECK (channel IN ('gmail','outlook','whatsapp','teams','slack','webhook')),
  recipients       JSONB NOT NULL DEFAULT '{"to":"","cc":"","bcc":""}',
  template         JSONB NOT NULL DEFAULT '{"subject":"","body_hint":"","body_draft":""}',
  schedule         JSONB NOT NULL DEFAULT '{"type":"manual","cron":"","timezone":"Asia/Dubai"}',
  approval_mode    TEXT NOT NULL DEFAULT 'manual'
                     CHECK (approval_mode IN ('draft','manual','auto')),
  options          JSONB NOT NULL DEFAULT '{
    "include_data_table": true,
    "attach_pdf": false,
    "attach_files": [],
    "digest_mode": "digest"
  }',
  last_run_at      TIMESTAMPTZ,
  next_run_at      TIMESTAMPTZ,
  run_count        INTEGER NOT NULL DEFAULT 0,
  version          INTEGER NOT NULL DEFAULT 1,
  created_by       UUID REFERENCES users(user_id),
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_jobs_tenant ON jobs(tenant_id);
CREATE INDEX idx_jobs_status ON jobs(tenant_id, status);
CREATE INDEX idx_jobs_next_run ON jobs(next_run_at) WHERE status = 'active';

-- ─────────────────────────────────────────────────────────────────────────────
--  NOTIFICATION RUNS
-- ─────────────────────────────────────────────────────────────────────────────

CREATE TABLE notification_runs (
  run_id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id           UUID NOT NULL REFERENCES jobs(job_id) ON DELETE CASCADE,
  tenant_id        UUID NOT NULL REFERENCES tenants(tenant_id) ON DELETE CASCADE,
  trigger_type     TEXT NOT NULL
                     CHECK (trigger_type IN ('cron','manual','webhook','polling')),
  status           TEXT NOT NULL DEFAULT 'triggered'
                     CHECK (status IN (
                       'triggered','fetching','evaluating','composing',
                       'pending_approval','approved','dispatching','sent',
                       'draft_saved','rejected','failed','skipped'
                     )),
  match_count      INTEGER NOT NULL DEFAULT 0,
  matched_rows     JSONB,           -- serialised DataFrame (limited columns for PII safety)
  composed_subject TEXT,
  composed_html    TEXT,
  composed_text    TEXT,
  channel          TEXT NOT NULL,
  recipient_to     TEXT,
  recipient_cc     TEXT,
  delivery_id      TEXT,            -- provider reference (Gmail message ID, etc.)
  draft_id         TEXT,            -- provider draft ID
  error_message    TEXT,
  triggered_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  fetched_at       TIMESTAMPTZ,
  evaluated_at     TIMESTAMPTZ,
  composed_at      TIMESTAMPTZ,
  dispatched_at    TIMESTAMPTZ,
  completed_at     TIMESTAMPTZ
);

CREATE INDEX idx_runs_job ON notification_runs(job_id);
CREATE INDEX idx_runs_tenant ON notification_runs(tenant_id);
CREATE INDEX idx_runs_status ON notification_runs(tenant_id, status);
CREATE INDEX idx_runs_triggered ON notification_runs(triggered_at DESC);

-- ─────────────────────────────────────────────────────────────────────────────
--  APPROVAL GATE
-- ─────────────────────────────────────────────────────────────────────────────

CREATE TABLE approvals (
  approval_id      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  run_id           UUID NOT NULL UNIQUE REFERENCES notification_runs(run_id),
  tenant_id        UUID NOT NULL REFERENCES tenants(tenant_id),
  status           TEXT NOT NULL DEFAULT 'pending_review'
                     CHECK (status IN (
                       'pending_review','approved','rejected','modified','dispatched','expired'
                     )),
  subject_override TEXT,
  html_override    TEXT,
  cc_override      TEXT,
  reviewed_by      UUID REFERENCES users(user_id),
  reviewed_at      TIMESTAMPTZ,
  review_note      TEXT,
  approval_token   TEXT UNIQUE,     -- signed token for email-based approval
  expires_at       TIMESTAMPTZ NOT NULL,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_approvals_tenant ON approvals(tenant_id, status);
CREATE INDEX idx_approvals_expires ON approvals(expires_at) WHERE status = 'pending_review';

-- ─────────────────────────────────────────────────────────────────────────────
--  CTA SIGNALS
-- ─────────────────────────────────────────────────────────────────────────────

CREATE TABLE cta_signals (
  signal_id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  run_id           UUID NOT NULL REFERENCES notification_runs(run_id),
  job_id           UUID NOT NULL REFERENCES jobs(job_id),
  tenant_id        UUID NOT NULL REFERENCES tenants(tenant_id),
  button_label     TEXT NOT NULL,
  button_key       TEXT NOT NULL,   -- URL-safe key e.g. "payment_made"
  channel          TEXT NOT NULL,
  recipient_hash   TEXT,            -- SHA-256 of recipient email (PII protection)
  ip_hash          TEXT,            -- SHA-256 of client IP
  user_agent_hash  TEXT,
  clicked_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  outcome_verified BOOLEAN,
  verified_at      TIMESTAMPTZ,
  verification_source TEXT,         -- 'd365', 'sharepoint', 'manual'
  idempotency_key  TEXT UNIQUE      -- prevents duplicate click recording
);

CREATE INDEX idx_cta_run ON cta_signals(run_id);
CREATE INDEX idx_cta_tenant ON cta_signals(tenant_id);
CREATE INDEX idx_cta_clicked ON cta_signals(clicked_at DESC);
CREATE INDEX idx_cta_outcome ON cta_signals(tenant_id, outcome_verified);

-- Verification schedule (checked at T+24h and T+72h after click)
CREATE TABLE cta_verification_queue (
  queue_id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  signal_id        UUID NOT NULL REFERENCES cta_signals(signal_id),
  run_at           TIMESTAMPTZ NOT NULL,
  attempt          INTEGER NOT NULL DEFAULT 1,
  processed        BOOLEAN NOT NULL DEFAULT false,
  processed_at     TIMESTAMPTZ
);

CREATE INDEX idx_verif_queue ON cta_verification_queue(run_at) WHERE processed = false;

-- ─────────────────────────────────────────────────────────────────────────────
--  EFFECTIVENESS METRICS (pre-computed, updated hourly)
-- ─────────────────────────────────────────────────────────────────────────────

CREATE TABLE effectiveness_metrics (
  metric_id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id        UUID NOT NULL REFERENCES tenants(tenant_id),
  dimension        TEXT NOT NULL,
  -- 'day_of_week' | 'hour_of_day' | 'month_position' | 'tone' |
  -- 'channel' | 'job_type' | 'frequency'
  dimension_value  TEXT NOT NULL,
  job_type         TEXT,            -- optional job-type filter
  period_start     DATE NOT NULL,
  period_end       DATE NOT NULL,
  sends            INTEGER NOT NULL DEFAULT 0,
  opens            INTEGER NOT NULL DEFAULT 0,
  cta_responses    INTEGER NOT NULL DEFAULT 0,
  outcomes_verified INTEGER NOT NULL DEFAULT 0,
  open_rate        NUMERIC(5,4),    -- computed: opens/sends
  cta_rate         NUMERIC(5,4),    -- computed: cta_responses/sends
  outcome_rate     NUMERIC(5,4),    -- computed: outcomes_verified/sends
  computed_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(tenant_id, dimension, dimension_value, job_type, period_start)
);

CREATE INDEX idx_eff_tenant ON effectiveness_metrics(tenant_id, dimension);
CREATE INDEX idx_eff_period ON effectiveness_metrics(period_start DESC);

-- AI insights cache
CREATE TABLE ai_insights (
  insight_id       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id        UUID NOT NULL REFERENCES tenants(tenant_id),
  insight_type     TEXT NOT NULL,   -- 'recommendation' | 'anomaly' | 'suggestion'
  severity         TEXT NOT NULL DEFAULT 'info'
                     CHECK (severity IN ('info','warning','high','critical')),
  title            TEXT NOT NULL,
  body             TEXT NOT NULL,
  supporting_data  JSONB,
  confidence       TEXT,            -- 'high' | 'medium' | 'low'
  applied          BOOLEAN NOT NULL DEFAULT false,
  dismissed        BOOLEAN NOT NULL DEFAULT false,
  generated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at       TIMESTAMPTZ
);

CREATE INDEX idx_insights_tenant ON ai_insights(tenant_id, generated_at DESC);

-- LLM prompt/response log (30-day TTL, DESC data governance)
CREATE TABLE llm_prompt_log (
  log_id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id        UUID NOT NULL REFERENCES tenants(tenant_id),
  run_id           UUID REFERENCES notification_runs(run_id),
  operation        TEXT NOT NULL,   -- 'analyse' | 'compose' | 'cta_labels' | 'insights'
  model            TEXT NOT NULL,
  prompt_hash      TEXT NOT NULL,   -- SHA-256 of prompt (not stored for PII)
  tokens_in        INTEGER,
  tokens_out       INTEGER,
  latency_ms       INTEGER,
  pii_fields_redacted TEXT[],
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at       TIMESTAMPTZ NOT NULL
                     DEFAULT (NOW() + INTERVAL '30 days')
);

CREATE INDEX idx_llm_log_tenant ON llm_prompt_log(tenant_id, created_at DESC);
CREATE INDEX idx_llm_log_expires ON llm_prompt_log(expires_at);

-- ─────────────────────────────────────────────────────────────────────────────
--  AUDIT LOG (DESC ISR 12.4 — append-only, tamper-evident)
-- ─────────────────────────────────────────────────────────────────────────────

CREATE TABLE audit_events (
  event_id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id        UUID,            -- NULL for platform-level events
  actor_id         TEXT NOT NULL,   -- user UUID or 'system' or service name
  actor_ip_hash    TEXT,            -- SHA-256 of IP
  action           TEXT NOT NULL,
  -- Namespaced: resource_type.verb
  -- auth.login_success | auth.login_failed | auth.mfa_success |
  -- job.created | job.updated | job.deleted | job.triggered |
  -- approval.approved | approval.rejected | approval.modified |
  -- notification.sent | notification.failed | notification.draft_saved |
  -- connector.created | connector.credential_accessed |
  -- tenant.created | tenant.suspended |
  -- user.created | user.role_changed | user.locked |
  -- data.exported | config.changed
  resource_type    TEXT NOT NULL,
  resource_id      TEXT,
  outcome          TEXT NOT NULL CHECK (outcome IN ('success','failure')),
  details          JSONB NOT NULL DEFAULT '{}',
  correlation_id   TEXT,            -- distributed trace ID
  service_name     TEXT NOT NULL,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Append-only enforcement: trigger prevents UPDATE/DELETE (DESC ISR 12.4)
CREATE OR REPLACE FUNCTION audit_immutability_guard()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION
    'SECURITY: audit_events is append-only. '
    'UPDATE/DELETE operations are prohibited (DESC ISR 12.4).';
END;
$$;

CREATE TRIGGER enforce_audit_immutability
  BEFORE UPDATE OR DELETE ON audit_events
  FOR EACH ROW EXECUTE FUNCTION audit_immutability_guard();

-- Indexes for audit log queries (no impact on immutability)
CREATE INDEX idx_audit_tenant ON audit_events(tenant_id, created_at DESC);
CREATE INDEX idx_audit_action ON audit_events(action, created_at DESC);
CREATE INDEX idx_audit_actor ON audit_events(actor_id, created_at DESC);
CREATE INDEX idx_audit_correlation ON audit_events(correlation_id);

-- ─────────────────────────────────────────────────────────────────────────────
--  ROW-LEVEL SECURITY (DESC ISR — tenant isolation)
-- ─────────────────────────────────────────────────────────────────────────────

-- Enable RLS on all tenant-scoped tables
ALTER TABLE connectors          ENABLE ROW LEVEL SECURITY;
ALTER TABLE jobs                ENABLE ROW LEVEL SECURITY;
ALTER TABLE notification_runs   ENABLE ROW LEVEL SECURITY;
ALTER TABLE approvals           ENABLE ROW LEVEL SECURITY;
ALTER TABLE cta_signals         ENABLE ROW LEVEL SECURITY;
ALTER TABLE effectiveness_metrics ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_insights         ENABLE ROW LEVEL SECURITY;
ALTER TABLE llm_prompt_log      ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_events        ENABLE ROW LEVEL SECURITY;
ALTER TABLE users               ENABLE ROW LEVEL SECURITY;

-- RLS policies — tenant isolation via app.tenant_id session variable
-- Services set: SET LOCAL app.tenant_id = '<uuid>';
-- super_admin bypass: SET LOCAL app.role = 'super_admin';

CREATE POLICY tenant_isolation ON connectors
  USING (tenant_id = current_setting('app.tenant_id', true)::UUID
         OR current_setting('app.role', true) = 'super_admin');

CREATE POLICY tenant_isolation ON jobs
  USING (tenant_id = current_setting('app.tenant_id', true)::UUID
         OR current_setting('app.role', true) = 'super_admin');

CREATE POLICY tenant_isolation ON notification_runs
  USING (tenant_id = current_setting('app.tenant_id', true)::UUID
         OR current_setting('app.role', true) = 'super_admin');

CREATE POLICY tenant_isolation ON approvals
  USING (tenant_id = current_setting('app.tenant_id', true)::UUID
         OR current_setting('app.role', true) = 'super_admin');

CREATE POLICY tenant_isolation ON cta_signals
  USING (tenant_id = current_setting('app.tenant_id', true)::UUID
         OR current_setting('app.role', true) = 'super_admin');

CREATE POLICY tenant_isolation ON effectiveness_metrics
  USING (tenant_id = current_setting('app.tenant_id', true)::UUID
         OR current_setting('app.role', true) = 'super_admin');

CREATE POLICY tenant_isolation ON ai_insights
  USING (tenant_id = current_setting('app.tenant_id', true)::UUID
         OR current_setting('app.role', true) = 'super_admin');

CREATE POLICY tenant_isolation ON llm_prompt_log
  USING (tenant_id = current_setting('app.tenant_id', true)::UUID
         OR current_setting('app.role', true) = 'super_admin');

-- Audit log: tenant can only see own events; super_admin sees all
CREATE POLICY audit_isolation ON audit_events
  USING (tenant_id IS NULL
         OR tenant_id = current_setting('app.tenant_id', true)::UUID
         OR current_setting('app.role', true) = 'super_admin');

CREATE POLICY user_isolation ON users
  USING (tenant_id = current_setting('app.tenant_id', true)::UUID
         OR current_setting('app.role', true) = 'super_admin');

-- ─────────────────────────────────────────────────────────────────────────────
--  UPDATED_AT TRIGGER (all mutable tables)
-- ─────────────────────────────────────────────────────────────────────────────

CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_tenants_updated_at
  BEFORE UPDATE ON tenants FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_users_updated_at
  BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_connectors_updated_at
  BEFORE UPDATE ON connectors FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_jobs_updated_at
  BEFORE UPDATE ON jobs FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_approvals_updated_at
  BEFORE UPDATE ON approvals FOR EACH ROW EXECUTE FUNCTION update_updated_at();

