-- ═══════════════════════════════════════════════════════════════════════════
--  Smart Notifier Platform — Seed Data (dev environment only)
-- ═══════════════════════════════════════════════════════════════════════════

-- Bypass RLS for seeding (superuser context)
SET app.role = 'super_admin';

-- Platform tenant (system)
INSERT INTO tenants (tenant_id, name, slug, branding, llm_backend, llm_model, retention_days)
VALUES (
  '00000000-0000-0000-0000-000000000001',
  'TechnoEdge Solutions LLC',
  'technoedge',
  '{"primary_color": "#185FA5", "font": "Inter", "logo_url": ""}',
  'anthropic',
  'claude-sonnet-4-20250514',
  730
);

-- Demo tenant (EDC)
INSERT INTO tenants (tenant_id, name, slug, branding, enabled_channels, retention_days)
VALUES (
  '00000000-0000-0000-0000-000000000002',
  'Emirates Driving Company',
  'edc',
  '{"primary_color": "#028090", "font": "Inter", "logo_url": ""}',
  ARRAY['gmail','outlook'],
  730
);

-- Super admin user (password: Admin@1234! — change immediately)
-- Hash: argon2id of 'Admin@1234!'
INSERT INTO users (user_id, tenant_id, email, display_name, roles, mfa_enabled, status)
VALUES (
  '00000000-0000-0000-0000-000000000010',
  '00000000-0000-0000-0000-000000000001',
  'admin@smartnotifier.io',
  'Platform Admin',
  ARRAY['super_admin'],
  false,
  'active'
);

-- Demo operator (Ankit)
INSERT INTO users (user_id, tenant_id, email, display_name, roles, status)
VALUES (
  '00000000-0000-0000-0000-000000000011',
  '00000000-0000-0000-0000-000000000002',
  'ankitsamriwal@gmail.com',
  'Ankit Samriwal',
  ARRAY['tenant_admin','operator'],
  'active'
);

-- Demo connector (file upload)
INSERT INTO connectors (connector_id, tenant_id, type, name, status, config)
VALUES (
  '00000000-0000-0000-0000-000000000020',
  '00000000-0000-0000-0000-000000000002',
  'file_upload',
  'AR Ageing Report — Apr 2026',
  'active',
  '{"bucket": "sn-uploads", "key": "edc/ar_ageing_apr2026.xlsx"}'
);

-- Demo job (AR overdue)
INSERT INTO jobs (
  job_id, tenant_id, name, description, status,
  connector_id, criteria, tone, channel, recipients, template, schedule, approval_mode
) VALUES (
  '00000000-0000-0000-0000-000000000030',
  '00000000-0000-0000-0000-000000000002',
  'AR Overdue Escalation',
  'Daily digest of AR invoices past due by more than 30 days',
  'active',
  '00000000-0000-0000-0000-000000000020',
  '{"logic": "AND", "conditions": [{"field": "Days Past Due", "op": "greater_than", "value": 30}]}',
  'Urgent',
  'gmail',
  '{"to": "ankitsamriwal@gmail.com", "cc": "", "bcc": ""}',
  '{
    "subject": "[AR OVERDUE] Finance Ageing Alert — {{match_count}} Accounts | {{today}}",
    "body_hint": "Reference invoice details, amount due, and exact days overdue. Firm tone. Escalate 61+ day accounts. Include payment CTA buttons.",
    "body_draft": ""
  }',
  '{"type": "cron", "cron": "0 8 * * 1-5", "timezone": "Asia/Dubai"}',
  'manual'
);

-- Initial audit event (platform bootstrap)
INSERT INTO audit_events (actor_id, action, resource_type, resource_id, outcome, details, service_name)
VALUES (
  'system',
  'platform.bootstrapped',
  'platform',
  '00000000-0000-0000-0000-000000000001',
  'success',
  '{"version": "1.0.0", "environment": "development"}',
  'sn-init'
);

