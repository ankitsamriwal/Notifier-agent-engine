-- ═══════════════════════════════════════════════════════════════════
--  Seed Data — Development & Demo Environment
--  DO NOT RUN IN PRODUCTION without scrubbing credentials
-- ═══════════════════════════════════════════════════════════════════

-- Temporarily bypass RLS for seed data
SET LOCAL app.role = 'super_admin';

-- ── Platform tenant (super admin tenant) ──────────────────────
INSERT INTO tenants (
    tenant_id, name, slug, status,
    branding, enabled_channels, data_residency,
    retention_days, desc_compliant, nesa_compliant, mfa_required
) VALUES (
    '00000000-0000-0000-0000-000000000001',
    'TechnoEdge Solutions LLC',
    'technoedge',
    'active',
    '{"logoUrl": null, "primaryColor": "#185FA5", "fontFamily": "Inter, sans-serif", "companyName": "TechnoEdge Solutions LLC"}',
    ARRAY['gmail', 'outlook'],
    'uae',
    730,
    TRUE,
    TRUE,
    FALSE
) ON CONFLICT DO NOTHING;

-- ── Demo tenant ───────────────────────────────────────────────
INSERT INTO tenants (
    tenant_id, name, slug, status,
    branding, enabled_channels, data_residency, retention_days
) VALUES (
    '00000000-0000-0000-0000-000000000002',
    'Emirates Driving Company',
    'edc',
    'active',
    '{"logoUrl": null, "primaryColor": "#028090", "fontFamily": "Inter, sans-serif", "companyName": "Emirates Driving Company"}',
    ARRAY['gmail', 'outlook'],
    'uae',
    365
) ON CONFLICT DO NOTHING;

-- ── Super admin user ──────────────────────────────────────────
-- Password: Admin@123! (Argon2id hash — CHANGE IN PRODUCTION)
INSERT INTO users (
    user_id, tenant_id, email, display_name,
    roles, status, mfa_enabled
) VALUES (
    '00000000-0000-0000-0000-000000000010',
    '00000000-0000-0000-0000-000000000001',
    'admin@smartnotifier.io',
    'Platform Admin',
    ARRAY['super_admin'],
    'active',
    FALSE
) ON CONFLICT DO NOTHING;

-- ── Demo tenant admin ─────────────────────────────────────────
INSERT INTO users (
    user_id, tenant_id, email, display_name,
    roles, status, mfa_enabled
) VALUES (
    '00000000-0000-0000-0000-000000000011',
    '00000000-0000-0000-0000-000000000002',
    'ankitsamriwal@gmail.com',
    'Ankit Samriwal',
    ARRAY['tenant_admin', 'operator'],
    'active',
    FALSE
) ON CONFLICT DO NOTHING;

-- ── Demo connectors ───────────────────────────────────────────
INSERT INTO connectors (
    connector_id, tenant_id, name, connector_type, status, config
) VALUES (
    '00000000-0000-0000-0000-000000000020',
    '00000000-0000-0000-0000-000000000002',
    'EDC AR Ageing Report',
    'file_upload',
    'active',
    '{"uploadBucket": "sn-uploads", "allowedTypes": ["xlsx", "csv"]}'
) ON CONFLICT DO NOTHING;

INSERT INTO connectors (
    connector_id, tenant_id, name, connector_type, status, config
) VALUES (
    '00000000-0000-0000-0000-000000000021',
    '00000000-0000-0000-0000-000000000002',
    'EDC AP Ageing Report',
    'file_upload',
    'active',
    '{"uploadBucket": "sn-uploads", "allowedTypes": ["xlsx", "csv"]}'
) ON CONFLICT DO NOTHING;

-- ── Demo jobs ─────────────────────────────────────────────────
INSERT INTO jobs (
    job_id, tenant_id, connector_id, name, description,
    status, criteria, tone, channel, recipients, template,
    schedule, approval_mode, options
) VALUES (
    '00000000-0000-0000-0000-000000000030',
    '00000000-0000-0000-0000-000000000002',
    '00000000-0000-0000-0000-000000000020',
    'AR Overdue Escalation',
    'Daily digest of AR invoices past due by more than 30 days',
    'active',
    '{"logic":"AND","conditions":[{"field":"Days Past Due","op":"greater_than","value":30}]}',
    'Urgent',
    'gmail',
    '{"to":"ankitsamriwal@gmail.com","cc":null,"bcc":null}',
    '{
        "subject":"[AR OVERDUE] Finance Ageing Alert — {{MATCH_COUNT}} Accounts | {{TODAY}}",
        "bodyHint":"Reference invoice details, amount due, exact days overdue. Firm but professional. Escalate 61+ day accounts. Include action deadline.",
        "bodyDraft":null
    }',
    '{"type":"cron","cron":"0 8 * * 1-5","timezone":"Asia/Dubai"}',
    'draft',
    '{
        "includeDataTable":true,
        "attachPDF":false,
        "attachFiles":[],
        "digestMode":"digest",
        "ctaButtons":["Payment made","Will pay by Friday","Query raised","Escalate","Dispute"]
    }'
) ON CONFLICT DO NOTHING;

INSERT INTO jobs (
    job_id, tenant_id, connector_id, name, description,
    status, criteria, tone, channel, recipients, template,
    schedule, approval_mode, options
) VALUES (
    '00000000-0000-0000-0000-000000000031',
    '00000000-0000-0000-0000-000000000002',
    '00000000-0000-0000-0000-000000000021',
    'AP Due Soon Reminder',
    'Daily reminder for AP invoices due within 7 days',
    'active',
    '{"logic":"AND","conditions":[{"field":"Days Past Due","op":"equals","value":0},{"field":"Due Date","op":"less_than","value":"7 days"}]}',
    'Professional',
    'outlook',
    '{"to":"ankitsamriwal@gmail.com","cc":null,"bcc":null}',
    '{
        "subject":"[AP DUE SOON] Payments Due Within 7 Days — {{TODAY}}",
        "bodyHint":"Friendly reminder that AP invoices are due within 7 days. Include vendor, amount and exact due date.",
        "bodyDraft":null
    }',
    '{"type":"cron","cron":"0 9 * * 1-5","timezone":"Asia/Dubai"}',
    'draft',
    '{
        "includeDataTable":true,
        "attachPDF":false,
        "attachFiles":[],
        "digestMode":"digest",
        "ctaButtons":["Scheduled for payment","Requires approval","Query raised","Defer payment"]
    }'
) ON CONFLICT DO NOTHING;

-- Seed effectiveness metrics (demo data for dashboard)
INSERT INTO effectiveness_metrics (
    tenant_id, dimension, dimension_value,
    sends, opens, cta_responses, outcomes_verified,
    open_rate, cta_rate, outcome_rate,
    period_start, period_end
) VALUES
    ('00000000-0000-0000-0000-000000000002', 'day_of_week', 'Monday',    42, 27, 18, 12, 0.6429, 0.4286, 0.2857, '2026-03-01', '2026-03-31'),
    ('00000000-0000-0000-0000-000000000002', 'day_of_week', 'Tuesday',   58, 47, 34, 22, 0.8103, 0.5862, 0.3793, '2026-03-01', '2026-03-31'),
    ('00000000-0000-0000-0000-000000000002', 'day_of_week', 'Wednesday', 61, 50, 37, 25, 0.8197, 0.6066, 0.4098, '2026-03-01', '2026-03-31'),
    ('00000000-0000-0000-0000-000000000002', 'day_of_week', 'Thursday',  55, 44, 31, 21, 0.8000, 0.5636, 0.3818, '2026-03-01', '2026-03-31'),
    ('00000000-0000-0000-0000-000000000002', 'day_of_week', 'Friday',    49, 34, 22, 14, 0.6939, 0.4490, 0.2857, '2026-03-01', '2026-03-31'),
    ('00000000-0000-0000-0000-000000000002', 'day_of_week', 'Saturday',  8,  3,  1,  0,  0.3750, 0.1250, 0.0000, '2026-03-01', '2026-03-31'),
    ('00000000-0000-0000-0000-000000000002', 'day_of_week', 'Sunday',    4,  1,  0,  0,  0.2500, 0.0000, 0.0000, '2026-03-01', '2026-03-31'),
    ('00000000-0000-0000-0000-000000000002', 'tone', 'Urgent',       188, 147, 112, 78, 0.7819, 0.5957, 0.4149, '2026-03-01', '2026-03-31'),
    ('00000000-0000-0000-0000-000000000002', 'tone', 'Professional', 142, 103,  74, 48, 0.7254, 0.5211, 0.3380, '2026-03-01', '2026-03-31'),
    ('00000000-0000-0000-0000-000000000002', 'tone', 'Friendly',      89,  52,  29, 16, 0.5843, 0.3258, 0.1798, '2026-03-01', '2026-03-31'),
    ('00000000-0000-0000-0000-000000000002', 'channel', 'gmail',   242, 182, 124, 82, 0.7521, 0.5124, 0.3388, '2026-03-01', '2026-03-31'),
    ('00000000-0000-0000-0000-000000000002', 'channel', 'outlook', 138,  94,  59, 38, 0.6812, 0.4275, 0.2754, '2026-03-01', '2026-03-31'),
    ('00000000-0000-0000-0000-000000000002', 'month_position', '1-7',   68, 31, 18, 11, 0.4559, 0.2647, 0.1618, '2026-03-01', '2026-03-31'),
    ('00000000-0000-0000-0000-000000000002', 'month_position', '8-14',  71, 35, 21, 14, 0.4930, 0.2958, 0.1972, '2026-03-01', '2026-03-31'),
    ('00000000-0000-0000-0000-000000000002', 'month_position', '15-21', 68, 38, 24, 15, 0.5588, 0.3529, 0.2206, '2026-03-01', '2026-03-31'),
    ('00000000-0000-0000-0000-000000000002', 'month_position', '22-27', 61, 42, 31, 21, 0.6885, 0.5082, 0.3443, '2026-03-01', '2026-03-31'),
    ('00000000-0000-0000-0000-000000000002', 'month_position', '28-31', 42, 37, 31, 26, 0.8810, 0.7381, 0.6190, '2026-03-01', '2026-03-31')
ON CONFLICT DO NOTHING;
