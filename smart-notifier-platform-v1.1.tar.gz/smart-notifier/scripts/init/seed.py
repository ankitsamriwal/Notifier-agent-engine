#!/usr/bin/env python3
"""
Smart Notifier Platform — Init Seeder
Runs once after all infrastructure containers are healthy.
Seeds: MinIO buckets, RabbitMQ (already seeded via definitions.json),
       Vault KV/transit secrets, verifies PostgreSQL connectivity.
"""
import os, sys, time, json, logging

logging.basicConfig(level=logging.INFO, format="%(asctime)s [seed] %(message)s")
log = logging.getLogger(__name__)

def wait(name, fn, retries=20, delay=3):
    for i in range(retries):
        try:
            fn()
            log.info(f"✓ {name} ready")
            return
        except Exception as e:
            log.info(f"  {name} not ready ({e}), retry {i+1}/{retries}...")
            time.sleep(delay)
    log.error(f"✗ {name} failed after {retries} retries")
    sys.exit(1)

# ── PostgreSQL ───────────────────────────────────────────────────────────────
def check_postgres():
    import psycopg2
    conn = psycopg2.connect(
        host=os.environ["POSTGRES_HOST"],
        port=int(os.environ["POSTGRES_PORT"]),
        dbname=os.environ["POSTGRES_DB"],
        user=os.environ["POSTGRES_USER"],
        password=os.environ["POSTGRES_PASSWORD"],
        connect_timeout=5,
    )
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM tenants")
    count = cur.fetchone()[0]
    log.info(f"  PostgreSQL: {count} tenants in DB")
    conn.close()

wait("PostgreSQL", check_postgres)

# ── RabbitMQ ─────────────────────────────────────────────────────────────────
def check_rabbitmq():
    import pika
    creds = pika.PlainCredentials(
        os.environ["RABBITMQ_USER"],
        os.environ["RABBITMQ_PASSWORD"],
    )
    params = pika.ConnectionParameters(
        host=os.environ["RABBITMQ_HOST"],
        port=int(os.environ["RABBITMQ_PORT"]),
        virtual_host=os.environ["RABBITMQ_VHOST"],
        credentials=creds,
        connection_attempts=1,
        socket_timeout=5,
    )
    conn = pika.BlockingConnection(params)
    ch = conn.channel()
    # Verify key queues exist
    ch.queue_declare(queue="sn.data.fetch", durable=True, passive=True)
    ch.queue_declare(queue="sn.audit.write", durable=True, passive=True)
    conn.close()

wait("RabbitMQ", check_rabbitmq)

# ── MinIO ────────────────────────────────────────────────────────────────────
def seed_minio():
    from minio import Minio
    from minio.error import S3Error

    endpoint = os.environ["MINIO_ENDPOINT"].replace("http://", "").replace("https://", "")
    client = Minio(
        endpoint,
        access_key=os.environ["MINIO_ROOT_USER"],
        secret_key=os.environ["MINIO_ROOT_PASSWORD"],
        secure=False,
    )
    buckets = ["sn-uploads", "sn-reports", "sn-attachments", "sn-audit-export"]
    for bucket in buckets:
        if not client.bucket_exists(bucket):
            client.make_bucket(bucket)
            log.info(f"  Created bucket: {bucket}")
        else:
            log.info(f"  Bucket exists: {bucket}")

wait("MinIO", seed_minio)

# ── Vault ────────────────────────────────────────────────────────────────────
def seed_vault():
    import hvac
    client = hvac.Client(
        url=os.environ["VAULT_ADDR"],
        token=os.environ["VAULT_TOKEN"],
    )
    assert client.is_authenticated(), "Vault auth failed"

    # Enable KV v2 secrets engine if not already enabled
    mounts = client.sys.list_mounted_secrets_engines()
    if "secret/" not in mounts:
        client.sys.enable_secrets_engine(backend_type="kv", path="secret", options={"version": "2"})
        log.info("  Enabled KV v2 secrets engine at secret/")

    # Enable Transit engine for JWT signing
    if "transit/" not in mounts:
        client.sys.enable_secrets_engine(backend_type="transit", path="transit")
        log.info("  Enabled Transit secrets engine at transit/")

    # Create JWT signing key (Ed25519)
    try:
        client.secrets.transit.create_key(name="sn-jwt-key", key_type="ed25519")
        log.info("  Created Ed25519 JWT signing key: sn-jwt-key")
    except Exception:
        log.info("  JWT signing key already exists")

    # Seed placeholder connector credentials for demo tenant
    try:
        client.secrets.kv.v2.create_or_update_secret(
            path="connectors/00000000-0000-0000-0000-000000000002/00000000-0000-0000-0000-000000000020",
            secret={"type": "file_upload", "note": "demo connector - no auth required"},
        )
    except Exception as e:
        log.info(f"  Vault seed (non-fatal): {e}")

wait("Vault", seed_vault)

log.info("")
log.info("═══════════════════════════════════════════════════════")
log.info("  Smart Notifier Platform — initialisation complete")
log.info("  Services ready to start")
log.info("═══════════════════════════════════════════════════════")
