# Smart Notifier Platform

AI-powered enterprise notification engine with outcome learning loop.

## Quick start (local dev)

```bash
# 1. Copy and fill environment variables
cp .env.example .env

# 2. Start everything
make dev

# 3. Open admin console
open http://localhost:4200
```

## Service ports

| Service          | Port  | Description                         |
|------------------|-------|-------------------------------------|
| API Gateway      | 8080  | Public entry point (JWT auth)        |
| Admin Console    | 4200  | Angular frontend                    |
| RabbitMQ UI      | 15672 | Queue management                    |
| MinIO Console    | 9001  | Object storage UI                   |
| Grafana          | 3000  | Metrics + logs dashboard            |
| Vault UI         | 8200  | Secret management                   |
| Jaeger UI        | 16686 | Distributed tracing                 |

## Production deployment

```bash
# AWS EKS
helm upgrade --install sn ./infrastructure/helm \
  -f infrastructure/helm/values.yaml \
  -f infrastructure/helm/values.aws.yaml \
  --namespace smart-notifier --create-namespace

# Azure AKS  
helm upgrade --install sn ./infrastructure/helm \
  -f infrastructure/helm/values.yaml \
  -f infrastructure/helm/values.azure.yaml

# On-premises
helm upgrade --install sn ./infrastructure/helm \
  -f infrastructure/helm/values.yaml \
  -f infrastructure/helm/values.onprem.yaml
```

## Architecture

15 microservices across 4 language runtimes:
- **Rust** (Axum): Gateway, Scheduler, CTA Processor — high-perf, security-critical
- **Python** (FastAPI): Connector, Rules Engine, AI Service, Audit, Effectiveness, Channel adapters
- **TypeScript** (Fastify): Job Registry, Approval Gate, Notification Log, Admin API
- **Angular 17** (CDK): Admin Console frontend

## Security & Compliance

- DESC ISR and NESA UAE IA Standards compliant
- Append-only audit log (PostgreSQL trigger prevents modification)
- HMAC-SHA256 CTA URLs (constant-time via Rust `ring` crate)
- PII redaction before every LLM call
- Row-level security on all tenant-scoped tables
- Vault-backed secret storage (never in PostgreSQL)
- Network zone isolation (DMZ / Application / Data / Management)

## Adding a connector

```python
from src.connectors.base import SourceConnector, ConnectorConfig, SchemaDefinition, DataQuery, HealthStatus
from src.connectors.registry import register
import pandas as pd

@register
class MyConnector(SourceConnector):
    @classmethod
    def connector_type(cls) -> str: return "my_source"

    async def authenticate(self, cfg: ConnectorConfig) -> bool: ...
    async def fetch(self, cfg: ConnectorConfig, query: DataQuery) -> pd.DataFrame: ...
    async def schema(self, cfg: ConnectorConfig) -> SchemaDefinition: ...
    async def health_check(self, cfg: ConnectorConfig) -> HealthStatus: ...
```

## Licence

MIT — core platform. Commercial licence for enterprise extensions.

© 2026 TechnoEdge Solutions LLC, Dubai UAE
